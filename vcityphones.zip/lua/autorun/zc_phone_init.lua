ZCPhone = ZCPhone or {}

local shared = { "zc_phone/sh_config.lua", "zc_phone/sh_photo.lua" }
local client = { "zc_phone/cl_core.lua", "zc_phone/cl_screen.lua", "zc_phone/cl_snake.lua", "zc_phone/cl_mines.lua", "zc_phone/cl_gallery_video.lua", "zc_phone/cl_camera.lua", "zc_phone/cl_photo_ir.lua", "zc_phone/cl_phonepose.lua", "zc_phone/cl_video.lua", "zc_phone/cl_hand.lua", "zc_phone/cl_interact.lua", "zc_phone/cl_debug.lua", "zc_phone/cl_tune.lua", "zc_phone/cl_scanner.lua" }

if SERVER then
	for _, f in ipairs(shared) do AddCSLuaFile(f) end
	if file.Exists("zc_phone/config_export.lua", "LUA") then AddCSLuaFile("zc_phone/config_export.lua") end
	for _, f in ipairs(client) do AddCSLuaFile(f) end
end

for _, f in ipairs(shared) do include(f) end

if SERVER then
	local snd = ZCPhone.Sounds
	for _, path in ipairs({ snd.tapStart, snd.tapEnd, snd.sms }) do
		if path then resource.AddFile("sound/" .. path) end
	end
	for _, r in ipairs(snd.rings) do resource.AddFile("sound/" .. r.path) end
end

if SERVER then
	include("zc_phone/sv_phone.lua")
	include("zc_phone/sv_phonepose.lua")
	include("zc_phone/sv_scanner.lua")
	include("zc_phone/sv_course.lua")
else
	for _, f in ipairs(client) do include(f) end
end
