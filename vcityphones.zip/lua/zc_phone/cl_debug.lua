ZCPhone = ZCPhone or {}
local debugCV = CreateClientConVar("zcphone_debug", "0", true, false, "Draw phone key zones and screen bounds")
local throughCV = CreateClientConVar("zcphone_debug_xray", "0", true, false, "Draw tuning zones through model")
local labels = {menu = "MENU", ok = "OK", red = "END", green = "CALL"}

-- All geometry is in model-local coordinates; Scale affects model, screen and zones together.
function ZCPhone.DrawDebug(pos, ang, mins, maxs)
 local cfg = ZCPhone.Config
 local scale = math.max(0.01, cfg.Scale)
 local size = cfg.Keys.boxSize or Vector(0.35, 0.7, 0.6)
 local half = size * (scale * 0.5)
 local _, boxAng = LocalToWorld(vector_origin, cfg.Keys.boxAng or angle_zero, pos, ang)
 for _, key in ipairs(ZCPhone.KeyOrder) do
  local p = LocalToWorld(ZCPhone.KeyLocal(key) * scale, angle_zero, pos, ang)
  local selected = ZCPhone.PreviewKey == key
  local color = selected and Color(255, 210, 40) or Color(50, 220, 255)
  render.DrawWireframeBox(p, boxAng, -half, half, color, throughCV:GetBool())
  render.DrawWireframeSphere(p, 0.06 * scale, 6, 4, color, throughCV:GetBool())
  local a = (EyePos() - p):Angle()
  a:RotateAroundAxis(a:Up(), -90)
  a:RotateAroundAxis(a:Forward(), 90)
  cam.Start3D2D(p, a, 0.012 * scale)
  draw.SimpleText(labels[key] or key, "DermaDefaultBold", 0, 0, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
  cam.End3D2D()
 end
 local sc = cfg.Screen
 local sp, sa = LocalToWorld(sc.pos * scale, sc.ang, pos, ang)
 local corners = {vector_origin, Vector(sc.w * scale, 0, 0), Vector(sc.w * scale, -sc.h * scale, 0), Vector(0, -sc.h * scale, 0)}
 for i = 1, 4 do
  local p1 = LocalToWorld(corners[i], angle_zero, sp, sa)
  local p2 = LocalToWorld(corners[i % 4 + 1], angle_zero, sp, sa)
  render.DrawLine(p1, p2, Color(110, 255, 100), not throughCV:GetBool())
 end
 local cc = cfg.Camera
 if cc then
  local lp, la
  if ZCPhone.ResolveLensLocal then lp, la = ZCPhone.ResolveLensLocal(cc, mins, maxs) end
  if not lp then lp, la = cc.pos, cc.ang end
  local cp, ca = LocalToWorld(lp * scale, la, pos, ang)
  local tip = cp + ca:Forward() * 4 * scale
  render.DrawLine(cp, tip, Color(255, 80, 220), not throughCV:GetBool())
  render.DrawWireframeSphere(cp, 0.12 * scale, 6, 4, Color(255, 80, 220), not throughCV:GetBool())
 end
 for _, axis in ipairs({{Vector(3,0,0), Color(255,70,70)}, {Vector(0,3,0), Color(70,255,70)}, {Vector(0,0,3), Color(70,120,255)}}) do
  local endpoint = LocalToWorld(axis[1] * scale, angle_zero, pos, ang)
  render.DrawLine(pos, endpoint, axis[2], not throughCV:GetBool())
 end
end

hook.Add("PostDrawTranslucentRenderables", "ZCPhone_DebugZones", function(depth, sky)
 if depth or sky or ZCPhone.RenderingCamera or not debugCV:GetBool() then return end
 local ply = LocalPlayer()
 local x = IsValid(ply) and ply.zcPhoneWorld
 if not x or x.frame < FrameNumber() - 2 or not ZCPhone.IsOut(ply) then return end
 ZCPhone.DrawDebug(x.pos, x.ang, x.mins, x.maxs)
end)

hook.Add("PostDrawTranslucentRenderables", "ZCPhone_DebugThumbTarget", function(depth, sky)
 if depth or sky or ZCPhone.RenderingCamera or not debugCV:GetBool() or not ZCPhone.ThumbTarget then return end
 render.DrawWireframeSphere(ZCPhone.ThumbTarget, 0.15, 6, 4, Color(255, 60, 60), true)
end)
