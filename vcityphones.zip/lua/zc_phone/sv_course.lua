-- Учебный курс «Штаба» по SMS. Новому игроку (без записи в zcphone_course) приходит серия сообщений
-- с паузой. Прогресс хранится в базе, курс можно пройти заново, ответив «курс» на номер Штаба.
-- Сообщения не длиннее 120 символов: влезают на экран телефона.
ZCPhone = ZCPhone or {}
local S = ZCPhone.Settings
sql.Query("CREATE TABLE IF NOT EXISTS zcphone_course (sid TEXT PRIMARY KEY, step INTEGER)")

ZCPhone.CourseFirstDelay = 8   -- секунд после появления телефона до первого сообщения
ZCPhone.CourseInterval = 45    -- секунд между сообщениями

-- Последний пункт всегда остаётся финальным; хук ZCPhone_CourseExtra вставляет свои строки перед ним.
ZCPhone.Course = {
	"Привет! Я Штаб :) Это короткий курс по телефону. Сообщения приходят раз в минуту, читай не спеша.",
	"Контакты: Меню - Контакты - Добавить. Номер 4 цифры, имя до 14 знаков. Букву набирай повторными нажатиями :)",
	"Звонить и писать можно только тем, кто есть в контактах. Позвонить: зелёная (G). Сбросить: красная (Backspace) :0",
	"Сеть - полоски вверху. Нет полосок - нет звонков и СМС. В зданиях хуже, рядом с глушилкой пропадает совсем :0",
	"Вышки связи: чем дальше от ближайшей, тем слабее сеть. Разбитая вышка - мёртвая зона. Чинит её связист :)",
	"Деньги: СМС «перевод 500» на номер из контактов отправит 500 игроку, если он в сети :)",
	"Камера снимает кошмарно, так задумано :) Фото из галереи можно отправить по ИК-порту, телефоны держи рядом.",
	"Карта: клавиша M. Телефон в руке занимает M, тогда назначь bind на команду zcmap. Ты видишь только себя :0",
	"Метки отряда на карте: Shift+ЛКМ. Ставят сержанты, офицеры и связисты, видит вся твоя сторона :)",
	"Связист со сканером ловит звонки и СМС вокруг и даёт пеленг. Держи цель в прицеле 3 сек - начнётся перехват :0",
	"Шифр: Меню - Настройки - Шифр (связисты и сержанты). Зашифрованный звонок не слышно, виден только пеленг :)",
	"Погибший оставляет телефон. Подбери на E: контакты и СМС лежат в меню «Трофеи». Это разведданные :0",
	"Скучно между боями? В меню есть Змейка и Сапёр :) Напиши мне «курс», чтобы пройти обучение заново. Удачи!",
}

local function sid(ply) return sql.SQLStr(ply:SteamID64() or ply:SteamID()) end

local function Lines()
	local list = table.Copy(ZCPhone.Course)
	local extra = hook.Run("ZCPhone_CourseExtra")
	if istable(extra) and #extra > 0 then
		local finale = table.remove(list)
		for _, t in ipairs(extra) do list[#list + 1] = tostring(t) end
		list[#list + 1] = finale
	end
	return list
end

local function GetStep(ply)
	local r = sql.Query("SELECT step FROM zcphone_course WHERE sid = " .. sid(ply))
	return r and r[1] and tonumber(r[1].step) or nil
end

local function SetStep(ply, n)
	sql.Query("INSERT OR REPLACE INTO zcphone_course (sid, step) VALUES (" .. sid(ply) .. ", " .. n .. ")")
end

local function Deliver(ply, text)
	local to = ply.zcPhoneNumber
	if not to then return end
	sql.Query(string.format("INSERT INTO zcphone_msgs (to_num, from_num, body, ts) VALUES (%d, %d, %s, %d)", to, ZCPhone.SystemNumber, sql.SQLStr(text), os.time()))
	sql.Query("DELETE FROM zcphone_msgs WHERE to_num = " .. to .. " AND id NOT IN (SELECT id FROM zcphone_msgs WHERE to_num = " .. to .. " ORDER BY id DESC LIMIT " .. S.MaxMessages .. ")")
	ZCPhone.Evt(ply, "sms", ZCPhone.SystemNumber, text)
	if not ply.zcPhoneSilent then ply:EmitSound(ZCPhone.Sounds.sms or S.MessageSound, 65, 100, 1) end
end

local function Stop(ply) timer.Remove("ZCPhone_Course_" .. ply:EntIndex()) end

local function Pump(ply, firstDelay)
	local name = "ZCPhone_Course_" .. ply:EntIndex()
	timer.Remove(name)
	timer.Simple(firstDelay, function()
		if not IsValid(ply) then return end
		local function step()
			if not IsValid(ply) or not ply.zcPhoneNumber then return true end
			if not ply:Alive() then return false end
			local list = Lines()
			local n = (GetStep(ply) or 0) + 1
			if n > #list then return true end
			Deliver(ply, list[n])
			SetStep(ply, n)
			return n >= #list
		end
		if step() then return end
		timer.Create(name, ZCPhone.CourseInterval, 0, function()
			if step() then timer.Remove(name) end
		end)
	end)
end

-- Запуск курса для новичка. Вызывается из Setup телефона.
function ZCPhone.CourseStart(ply)
	if not IsValid(ply) or not ply.zcPhoneNumber then return end
	local step = GetStep(ply)
	if step == nil then SetStep(ply, 0) step = 0 end
	if step < #Lines() then Pump(ply, step == 0 and ZCPhone.CourseFirstDelay or 20) end
end

-- Ответ игрока Штабу: «курс» начинает обучение заново.
function ZCPhone.SystemSms(ply, text)
	local word = string.Trim(text)
	-- string.lower не знает кириллицу: регистры «курс» перечислены явно
	if word == "курс" or word == "Курс" or word == "КУРС" or string.lower(word) == "kurs" or string.lower(word) == "course" then
		SetStep(ply, 0)
		Stop(ply)
		ZCPhone.Notice(ply, "Курс начат заново")
		Pump(ply, 4)
	else
		ZCPhone.Notice(ply, "Штаб: ответьте «курс»")
	end
end

hook.Add("PlayerDisconnected", "ZCPhone_CourseStop", function(ply) Stop(ply) end)
