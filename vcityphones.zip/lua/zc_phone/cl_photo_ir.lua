-- A paced, consent-based JPEG transfer. Exactly one chunk is in flight.
ZCPhone = ZCPhone or {}
local P, st = ZCPhone.Photo, ZCPhone.State
local pending, outgoing, incoming
local CHUNK_DELAY = 0.25

local function cancel()
    pending, outgoing, incoming = nil, nil, nil
    net.Start("ZCPhone_Act") net.WriteUInt(11, 4) net.SendToServer()
end

function ZCPhone.BeginJPEGTransfer(data)
    if not P.ValidJPEG(data) then return ZCPhone.Notice("Некорректное фото", 2) end
    if outgoing or incoming or st.ir.state ~= "idle" then return ZCPhone.Notice("ИК-порт занят", 2) end
    if pending and CurTime() - pending.started < 2 then return ZCPhone.Notice("Подождите", 1) end
    pending = {data = data, crc = util.CRC(data), started = CurTime()}
    net.Start("ZCPhone_IRStart2")
    net.WriteUInt(#data, 22)
    net.WriteString(pending.crc)
    net.SendToServer()
end

hook.Add("Think", "ZCPhone_JPEGTransfer", function()
    if pending and not outgoing and CurTime() - pending.started > 15 then pending = nil end
    local x = outgoing
    if not x or x.waiting or x.sent >= #x.data or CurTime() < x.nextSend then return end
    if not ZCPhone.IsOut() or st.ir.state ~= "active" then return end
    local chunk = x.data:sub(x.sent + 1, x.sent + P.ChunkBytes)
    x.index = x.index + 1
    x.sent = x.sent + #chunk
    x.waiting = true
    net.Start("ZCPhone_IRChunk2")
    net.WriteUInt(x.id, 32)
    net.WriteUInt(x.index, 16)
    net.WriteUInt(#chunk, 14)
    net.WriteData(chunk, #chunk)
    net.SendToServer()
end)

net.Receive("ZCPhone_IRStream2", function(bits)
    local op, id = net.ReadUInt(3), net.ReadUInt(32)
    if op == 0 then
        local isSender, size, crc = net.ReadBool(), net.ReadUInt(22), net.ReadString()
        if size < 32 or size > P.MaxBytes or not crc:match("^%d+$") or #crc > 10 then return cancel() end
        if isSender then
            if not pending or #pending.data ~= size or pending.crc ~= crc then return cancel() end
            outgoing = {id = id, data = pending.data, index = 0, sent = 0, nextSend = CurTime(), waiting = false}
            pending = nil
        else
            incoming = {id = id, size = size, crc = crc, received = 0, index = 0, parts = {}}
        end
        st.ir.progress = 0
    elseif op == 1 then
        if outgoing and outgoing.id == id then
            local index = net.ReadUInt(16)
            if not outgoing.waiting or index ~= outgoing.index then return cancel() end
            outgoing.waiting = false
            outgoing.nextSend = CurTime() + CHUNK_DELAY
            st.ir.progress = math.min(outgoing.sent / #outgoing.data, 0.99)
        elseif incoming and incoming.id == id then
            local index, n = net.ReadUInt(16), net.ReadUInt(14)
            local expected = math.min(P.ChunkBytes, incoming.size - incoming.received)
            if index ~= incoming.index + 1 or n ~= expected or n < 1 or bits < 3 + 32 + 16 + 14 + n * 8 then return cancel() end
            local data = net.ReadData(n)
            if not isstring(data) or #data ~= n then return cancel() end
            incoming.index, incoming.received = index, incoming.received + n
            incoming.parts[index] = data
            st.ir.progress = math.min(incoming.received / incoming.size, 0.99)
        end
    elseif op == 2 then
        if not incoming or incoming.id ~= id then return end
        local data = table.concat(incoming.parts)
        local valid = #data == incoming.size and util.CRC(data) == incoming.crc and P.ValidJPEG(data)
        local saved = valid and ZCPhone.SaveJPEG(data) or false
        incoming = nil
        net.Start("ZCPhone_IRResult2") net.WriteUInt(id, 32) net.WriteBool(saved and true or false) net.SendToServer()
        if saved then
            ZCPhone.Notice("Фото получено и сохранено на компьютер", 3)
            local ply = LocalPlayer()
            if IsValid(ply) then ply:EmitSound("buttons/blip1.wav", 55, 120, 0.6) end
        else
            ZCPhone.Notice("Не удалось сохранить фото", 3)
        end
    elseif op == 3 then
        if outgoing and outgoing.id == id then outgoing = nil end
        if incoming and incoming.id == id then incoming = nil end
        pending = nil
    end
end)
