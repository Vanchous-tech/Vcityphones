ZCPhone.DFFixes = ZCPhone.DFFixes or {}
local list, prog = {}, 0
local last = 0
local FADE = 120

net.Receive("ZCPhone_Scan", function()
	list = net.ReadTable()
	prog = net.ReadFloat()
	last = CurTime()
end)

net.Receive("ZCPhone_DF", function()
	local pos, az = net.ReadVector(), net.ReadFloat()
	local t = ZCPhone.DFFixes
	t[#t + 1] = { pos = pos, az = az, time = CurTime() }
	while #t > 40 do table.remove(t, 1) end
end)

timer.Create("ZCPhone_DFClean", 5, 0, function()
	local t = ZCPhone.DFFixes
	for i = #t, 1, -1 do
		if CurTime() - t[i].time > FADE then table.remove(t, i) end
	end
end)

local function Active()
	local w = LocalPlayer():GetActiveWeapon()
	return IsValid(w) and w:GetClass() == "weapon_zc_scanner"
end

surface.CreateFont("ZCScan", { font = "Consolas", size = 18, weight = 600 })

hook.Add("HUDPaint", "ZCPhone_ScannerHUD", function()
	if not Active() then return end
	local W, H = ScrW(), ScrH()
	local x, y = W - 330, H * 0.3
	draw.RoundedBox(4, x, y, 310, 40 + math.max(1, #list) * 22 + 24, Color(10, 20, 10, 210))
	draw.SimpleText("СКАНЕР СВЯЗИ", "ZCScan", x + 10, y + 8, Color(120, 255, 120))
	if CurTime() - last > 2 or #list == 0 then
		draw.SimpleText("эфир чист", "ZCScan", x + 10, y + 36, Color(90, 160, 90))
	else
		for i, e in ipairs(list) do
			local txt = string.format("%s  %03d°  ~%dм", e.kind == "call" and "ЗВОНОК" or "SMS", math.floor(e.az), math.floor(e.dist * 0.01905))
			if e.enc then txt = txt .. "  [ШИФР]" elseif e.locked then txt = txt .. "  [ПЕРЕХВАТ]" end
			draw.SimpleText(txt, "ZCScan", x + 10, y + 16 + i * 22, e.locked and Color(255, 220, 90) or Color(150, 255, 150))
			if e.nums then
				draw.SimpleText("№ " .. table.concat(e.nums, " ↔ "), "ZCScan", x + 10, y + 16 + i * 22 + 0, Color(255, 220, 90), TEXT_ALIGN_LEFT)
			end
		end
	end
	if prog > 0 then
		local by = y + 40 + math.max(1, #list) * 22
		surface.SetDrawColor(40, 90, 40) surface.DrawRect(x + 10, by, 290, 8)
		surface.SetDrawColor(120, 255, 120) surface.DrawRect(x + 10, by, 290 * prog, 8)
	end
	-- компас: пеленги
	local cx, cy, r = W - 175, H * 0.3 - 90, 70
	draw.RoundedBox(r, cx - r, cy - r, r * 2, r * 2, Color(10, 20, 10, 200))
	local heading = (-LocalPlayer():EyeAngles().y) % 360
	for _, e in ipairs(list) do
		local rel = math.rad(e.az - heading)
		local px, py = cx + math.sin(rel) * (r - 8), cy - math.cos(rel) * (r - 8)
		draw.RoundedBox(4, px - 4, py - 4, 8, 8, e.locked and Color(255, 220, 90) or Color(120, 255, 120))
	end
	draw.SimpleText("▲", "ZCScan", cx, cy - r + 2, Color(255, 255, 255), TEXT_ALIGN_CENTER)
end)
