-- Mouse-driven pose for the original button phone, shared with other players.
ZCPhone = ZCPhone or {}
local position, rotation = Vector(0,0,0), Angle(0,0,0)
local initialized, dirty, nextSend = false, false, 0
function ZCPhone.GetPhonePose(ply)
    if ply == LocalPlayer() and initialized then return position, rotation end
    return ply:GetNWVector("ZCPhone_ButtonOffset", vector_origin), ply:GetNWAngle("ZCPhone_ButtonRotation", angle_zero)
end
function ZCPhone.InitPhonePose()
    if initialized then return end
    local p,a = ZCPhone.GetPhonePose(LocalPlayer())
    position, rotation = Vector(p.x,p.y,p.z), Angle(a.p,a.y,a.r)
    initialized = true
end
local function wrap(n) return (n + 180) % 360 - 180 end
function ZCPhone.AdjustPhonePose(x,y)
    ZCPhone.InitPhonePose()
    local shift = input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT)
    local alt = input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT)
    if alt then
        if shift then rotation.r = wrap(rotation.r + x * 0.25)
        else rotation.y = wrap(rotation.y + x * 0.25) rotation.p = wrap(rotation.p + y * 0.25) end
    elseif shift then position.x = math.Clamp(position.x - y * 0.025, -12, 12)
    else
        position.y = math.Clamp(position.y - x * 0.025, -12, 12)
        position.z = math.Clamp(position.z - y * 0.025, -12, 12)
    end
    dirty = true
end
concommand.Add("zcphone_resetpose", function()
    position, rotation, initialized, dirty = Vector(0,0,0), Angle(0,0,0), true, true
    ZCPhone.Notice("Положение руки сброшено", 2)
end)
hook.Add("Think", "ZCPhone_ButtonPoseSync", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not dirty or not ZCPhone.IsOut(ply) or CurTime() < nextSend then return end
    nextSend, dirty = CurTime() + 0.12, false
    net.Start("ZCPhone_ButtonPose") net.WriteVector(position) net.WriteAngle(rotation) net.SendToServer()
end)
