ZCPhone = ZCPhone or {}
local S = ZCPhone.Settings

local NW = "ZCPhone_Out"

local st = {
	number = 0,
	contacts = {},
	messages = {},
	call = { state = "idle", peer = "", t = 0 },
	notice = "", noticeUntil = 0,
	unread = 0,
	ring = "",
	silent = false,
	ir = { state = "idle", label = "", t0 = 0, dur = 8 },
}
ZCPhone.State = st

local ui = { screen = "home", stack = {}, sel = 1, scroll = 0, mode = "browse", buf = {}, lastKey = nil, lastTime = 0, tapIdx = 0, layout = "ru", target = nil, newName = nil, caseMode = "Abc", pendingUntil = 0 }
ZCPhone.UI = ui

local TAP = {
	ru = {
		["1"] = { ".", ",", "?", "!", "-", "1" },
		["2"] = { "а", "б", "в", "г", "2" },
		["3"] = { "д", "е", "ж", "з", "3" },
		["4"] = { "и", "й", "к", "л", "4" },
		["5"] = { "м", "н", "о", "п", "5" },
		["6"] = { "р", "с", "т", "у", "6" },
		["7"] = { "ф", "х", "ц", "ч", "7" },
		["8"] = { "ш", "щ", "ъ", "ы", "8" },
		["9"] = { "ь", "э", "ю", "я", "9" },
		["0"] = { " ", "0" },
	},
	en = {
		["1"] = { ".", ",", "?", "!", "-", "1" },
		["2"] = { "a", "b", "c", "2" },
		["3"] = { "d", "e", "f", "3" },
		["4"] = { "g", "h", "i", "4" },
		["5"] = { "j", "k", "l", "5" },
		["6"] = { "m", "n", "o", "6" },
		["7"] = { "p", "q", "r", "s", "7" },
		["8"] = { "t", "u", "v", "8" },
		["9"] = { "w", "x", "y", "z", "9" },
		["0"] = { " ", "0" },
	},
}

local MENU = {
	{ "Контакты", "contacts", "browse" },
	{ "Позвонить", "contacts", "call" },
	{ "Набрать номер", "dial" },
	{ "Сообщения", "inbox" },
	{ "Написать", "contacts", "write" },
	{ "Мой номер", "mynumber" },
	{ "Камера", "camera" },
	{ "Галерея", "gallery" },
	{ "Змейка", "snake" },
	{ "Сапёр", "mines" },
	{ "Трофеи", "loot" },
	{ "Настройки", "settings" },
}
ZCPhone.MenuItems = MENU

function ZCPhone.BufText() return table.concat(ui.buf) end

function ZCPhone.Notice(text, dur)
	st.notice = text
	st.noticeUntil = CurTime() + (dur or 2)
end

local cvKeySound = CreateClientConVar("zcphone_keysound", "1", true, false, "Phone key click sounds")
local cvKeyVol = CreateClientConVar("zcphone_keyvolume", "1", true, false, "Key click volume 0..2")

local function PlayLocal(path, vol, level)
	local ply = LocalPlayer()
	if not path or not IsValid(ply) then return end
	vol = vol or 1
	ply:EmitSound(path, level or 60, 100, math.min(vol, 1))
	if vol > 1 then ply:EmitSound(path, level or 60, 100, math.min(vol - 1, 1), CHAN_ITEM) end
end

function ZCPhone.TapStart()
	if not cvKeySound:GetBool() then return end
	ZCPhone.Tapping = true
	PlayLocal(ZCPhone.Sounds.tapStart, cvKeyVol:GetFloat())
end

function ZCPhone.TapEnd()
	if not ZCPhone.Tapping then return end
	ZCPhone.Tapping = false
	PlayLocal(ZCPhone.Sounds.tapEnd, cvKeyVol:GetFloat())
end

local previewPath
function ZCPhone.PreviewRing(path)
	local ply = LocalPlayer()
	if previewPath then ply:StopSound(previewPath) end
	previewPath = path
	if path then ply:EmitSound(path, 60, 100, 1) end
end

function ZCPhone.SaveSettings()
	net.Start("ZCPhone_Act")
	net.WriteUInt(8, 4)
	net.WriteString(st.ring or "")
	net.WriteBool(st.silent or false)
	net.SendToServer()
end

local function Act(act, fn)
	net.Start("ZCPhone_Act")
	net.WriteUInt(act, 4)
	if fn then fn() end
	net.SendToServer()
end

local function FindContact(n)
	for _, c in ipairs(st.contacts) do
		if c.num == n then return c end
	end
end
ZCPhone.FindContact = FindContact

function ZCPhone.NameOf(n)
	local c = FindContact(n)
	return c and c.name or tostring(n)
end

local function Go(screen, keepStack)
	if ui.screen == "ringtones" then ZCPhone.PreviewRing(nil) end
	if not keepStack then ui.stack[#ui.stack + 1] = { ui.screen, ui.sel, ui.mode, ui.target } end
	ui.screen = screen
	ui.sel = 1
	ui.scroll = 0
	ui.buf = {}
	ui.lastKey = nil
end

local function Back()
	if ui.screen == "ringtones" then ZCPhone.PreviewRing(nil) end
	local prev = table.remove(ui.stack)
	if not prev then ui.screen, ui.sel, ui.mode, ui.target = "home", 1, "browse", nil return end
	ui.screen, ui.sel, ui.mode, ui.target = prev[1], prev[2], prev[3], prev[4]
	ui.buf = {}
	ui.lastKey = nil
end

local function Home()
	if ui.screen == "ringtones" then ZCPhone.PreviewRing(nil) end
	ui.stack = {}
	ui.screen, ui.sel, ui.mode, ui.target = "home", 1, "browse", nil
	ui.buf = {}
	ui.lastKey = nil
end
ZCPhone.Home = Home

function ZCPhone.ListLength()
	local s = ui.screen
	if s == "menu" then return #MENU end
	if s == "contacts" then return #st.contacts + (ui.mode == "browse" and 1 or 0) end
	if s == "contact_menu" then return 3 end
	if s == "inbox" then return #st.messages end
	if s == "settings" then return IsValid(LocalPlayer()) and LocalPlayer():GetNWBool("ZCPhone_CanEnc", false) and 4 or 3 end
	if s == "loot" then return #(st.loot or {}) end
	if s == "loot_dev" then return 2 end
	if s == "loot_contacts" then return ui.target and #ui.target.contacts or 0 end
	if s == "loot_msgs" then return ui.target and #ui.target.msgs or 0 end
	if s == "ringtones" then return math.max(1, #ZCPhone.Sounds.rings) end
	return 0
end

local function MoveSel(d)
	local n = ZCPhone.ListLength()
	if n <= 0 then return end
	ui.sel = (ui.sel - 1 + d) % n + 1
	local rows = 6
	if ui.sel <= ui.scroll then ui.scroll = ui.sel - 1 end
	if ui.sel > ui.scroll + rows then ui.scroll = ui.sel - rows end
end

local function IsTextScreen() return ui.screen == "add_name" or ui.screen == "compose" end
local function IsDigitScreen() return ui.screen == "add_number" or ui.screen == "dial" end

local CYR_UP = {}
local function Upper(ch)
	if #ch == 1 then return string.upper(ch) end
	local cp = utf8.codepoint(ch)
	if cp >= 0x430 and cp <= 0x44F then return utf8.char(cp - 32) end
	return ch
end

local CASES = { "Abc", "abc", "ABC", "123" }

local function WantUpper(upto)
	local m = ui.caseMode
	if m == "ABC" then return true end
	if m ~= "Abc" then return false end
	local i = upto
	while i >= 1 and ui.buf[i] == " " do i = i - 1 end
	if i < 1 then return true end
	if i == upto then return false end
	local c = ui.buf[i]
	return c == "." or c == "!" or c == "?"
end

local function CommitPending()
	ui.lastKey = nil
	ui.pendingUntil = 0
end
ZCPhone.CommitPending = CommitPending

function ZCPhone.IsPending()
	return ui.lastKey ~= nil and CurTime() < ui.pendingUntil
end

local TAP_TIMEOUT = 1.0

local function TypeChar(key)
	if IsDigitScreen() then
		if tonumber(key) and #ui.buf < S.NumberDigits then ui.buf[#ui.buf + 1] = key end
		return
	end
	if key == "*" then
		ui.layout = ui.layout == "ru" and "en" or "ru"
		ZCPhone.Notice(ui.layout == "ru" and "Раскладка: РУС" or "Layout: ENG", 1)
		CommitPending()
		return
	end
	if key == "#" then
		local idx = table.KeyFromValue(CASES, ui.caseMode) or 1
		ui.caseMode = CASES[idx % #CASES + 1]
		ZCPhone.Notice("Режим: " .. ui.caseMode, 1)
		CommitPending()
		return
	end
	local set = TAP[ui.layout][key]
	if not set then return end
	local max = ui.screen == "compose" and S.MaxMessageLength or S.MaxNameLength
	local now = CurTime()

	if ui.caseMode == "123" then
		if #ui.buf < max then ui.buf[#ui.buf + 1] = set[#set] == "1" and "1" or set[#set] end
		CommitPending()
		return
	end

	local function Place(ch, pos)
		if WantUpper(pos - 1) then ch = Upper(ch) end
		ui.buf[pos] = ch
	end

	if ui.lastKey == key and now < ui.pendingUntil and #ui.buf > 0 then
		ui.tapIdx = ui.tapIdx % #set + 1
		Place(set[ui.tapIdx], #ui.buf)
	else
		if #ui.buf >= max then CommitPending() return end
		ui.tapIdx = 1
		Place(set[1], #ui.buf + 1)
	end
	ui.lastKey = key
	ui.pendingUntil = now + TAP_TIMEOUT
end

local function Confirm()
	local s = ui.screen
	if s == "home" then return Go("menu") end
	if s == "menu" then
		local it = MENU[ui.sel]
		ui.mode = it[3] or "browse"
		return Go(it[2])
	end
	if s == "contacts" then
		if ui.mode == "browse" then
			if ui.sel == 1 then ui.newName = nil return Go("add_number") end
			ui.target = st.contacts[ui.sel - 1]
			return Go("contact_menu")
		end
		local c = st.contacts[ui.sel]
		if not c then return end
		ui.target = c
		if ui.mode == "call" then
			Act(3, function() net.WriteUInt(c.num, 16) end)
		else
			Go("compose")
		end
		return
	end
	if s == "contact_menu" then
		local c = ui.target
		if not c then return Back() end
		if ui.sel == 1 then Act(3, function() net.WriteUInt(c.num, 16) end)
		elseif ui.sel == 2 then Go("compose")
		else
			Act(2, function() net.WriteUInt(c.num, 16) end)
			Home()
		end
		return
	end
	if s == "add_number" then
		local n = tonumber(ZCPhone.BufText())
		if not n or #ui.buf ~= S.NumberDigits then return ZCPhone.Notice("Нужно " .. S.NumberDigits .. " цифры") end
		ui.newNumber = n
		local c = FindContact(n)
		Go("add_name", true)
		if c then for _, ch in utf8.codes(c.name) do ui.buf[#ui.buf + 1] = utf8.char(ch) end end
		return
	end
	if s == "dial" then
		local n = tonumber(ZCPhone.BufText())
		if not n or #ui.buf ~= S.NumberDigits then return ZCPhone.Notice("Нужно " .. S.NumberDigits .. " цифры") end
		Act(12, function() net.WriteUInt(n, 16) end)
		return Home()
	end
	if s == "add_name" then
		local n, name = ui.newNumber, ZCPhone.BufText()
		if not n then return Home() end
		Act(1, function() net.WriteString(name) net.WriteUInt(n, 16) end)
		ui.newNumber = nil
		return Home()
	end
	if s == "inbox" then
		local m = st.messages[ui.sel]
		if not m then return end
		m.read = true
		ui.target = m
		return Go("msg_view")
	end
	if s == "loot" then
		local d = (st.loot or {})[ui.sel]
		if not d then return end
		ui.target = d
		return Go("loot_dev")
	end
	if s == "loot_dev" then
		if not ui.target then return Back() end
		return Go(ui.sel == 1 and "loot_contacts" or "loot_msgs")
	end
	if s == "loot_contacts" then return end
	if s == "loot_msgs" then
		local m = ui.target and ui.target.msgs[ui.sel]
		if not m then return end
		m.loot = true
		ui.target = m
		return Go("msg_view")
	end
	if s == "msg_view" then
		local m = ui.target
		if not m then return Back() end
		if m.loot then return Back() end
		if FindContact(m.from) then
			ui.target = FindContact(m.from)
			return Go("compose", true)
		end
		ui.newNumber = m.from
		Go("add_name", true)
		return
	end
	if s == "settings" then
		if ui.sel == 1 then
			Go("ringtones")
			for i, r in ipairs(ZCPhone.Sounds.rings) do if r.id == st.ring then ui.sel = i end end
		elseif ui.sel == 2 then
			st.silent = not st.silent
			ZCPhone.SaveSettings()
		elseif ui.sel == 4 then
			local on = not LocalPlayer():GetNWBool("ZCPhone_Enc", false)
			Act(13, function() net.WriteBool(on) end)
		else
			RunConsoleCommand("zcphone_keysound", cvKeySound:GetBool() and "0" or "1")
		end
		return
	end
	if s == "ringtones" then
		local r = ZCPhone.Sounds.rings[ui.sel]
		if not r then return end
		st.ring = r.id
		ZCPhone.SaveSettings()
		ZCPhone.PreviewRing(r.path)
		ZCPhone.Notice("Мелодия выбрана", 1)
		return
	end
	if s == "compose" then
		local text = ZCPhone.BufText()
		local c = ui.target
		if not c or not c.num or text == "" then return end
		Act(6, function() net.WriteUInt(c.num, 16) net.WriteString(text) end)
		return Home()
	end
end

local function CallGreen()
	local c = st.call
	if c.state == "in" then Act(4) return end
	if ui.screen == "dial" then return Confirm() end
	if ui.screen == "contacts" and ui.mode ~= "write" then
		local con = st.contacts[ui.mode == "browse" and ui.sel - 1 or ui.sel]
		if con then Act(3, function() net.WriteUInt(con.num, 16) end) end
	end
end

local function CallRed()
	if st.call.state ~= "idle" then Act(5) return true end
	return false
end

function ZCPhone.Press(key)
	if not key then return end
	ZCPhone.LastPressKey = key
	ZCPhone.TapStart()

	if st.ir.state ~= "idle" then
		if key == "green" and st.ir.state == "offer" then
			net.Start("ZCPhone_Act") net.WriteUInt(10, 4) net.SendToServer()
		elseif key == "red" then
			net.Start("ZCPhone_Act") net.WriteUInt(11, 4) net.SendToServer()
		end
		return
	end
	ZCPhone.LastPressTime = CurTime()

	if key == "menu" then
		if st.call.state ~= "idle" then return end
		if ui.screen == "home" then return Go("menu") end
		return Home()
	end
	if key == "green" then return CallGreen() end
	if key == "red" then
		if CallRed() then return end
		if IsTextScreen() or IsDigitScreen() then
			if #ui.buf > 0 then ui.buf[#ui.buf] = nil CommitPending() return end
			return Back()
		end
		if ui.screen == "home" then return end
		return Back()
	end
	if st.call.state ~= "idle" then
		if key == "ok" and st.call.state == "in" then Act(4) end
		return
	end
	if ui.screen == "snake" then return ZCPhone.SnakeKey(key) end
	if ui.screen == "mines" then return ZCPhone.MinesKey(key) end
	if ui.screen == "camera" then return ZCPhone.CameraKey(key) end
	if ui.screen == "gallery" then return ZCPhone.GalleryKey(key) end
	if key == "ok" then return Confirm() end

	if IsTextScreen() or IsDigitScreen() then
		return TypeChar(key)
	end

	if key == "2" then MoveSel(-1)
	elseif key == "8" then MoveSel(1)
	elseif key == "4" then
		if ui.screen == "home" then return end
		Back()
	elseif key == "6" then
		if ui.screen == "home" then Go("menu") else Confirm() end
	end
end

net.Receive("ZCPhone_Loot", function()
	st.loot = net.ReadTable()
end)

net.Receive("ZCPhone_Sync", function()
	st.number = net.ReadUInt(16)
	st.contacts = net.ReadTable()
	local msgs = net.ReadTable()
	st.ring = net.ReadString()
	st.silent = net.ReadBool()
	local seen = {}
	for _, m in ipairs(st.messages) do seen[m.ts .. ":" .. m.from .. ":" .. m.text] = m.read end
	for _, m in ipairs(msgs) do m.read = seen[m.ts .. ":" .. m.from .. ":" .. m.text] end
	st.messages = msgs
	ui.sel = math.Clamp(ui.sel, 1, math.max(1, ZCPhone.ListLength()))
	ui.scroll = math.max(0, math.min(ui.scroll, ui.sel - 1))
end)

net.Receive("ZCPhone_Evt", function()
	local kind, a, b = net.ReadString(), net.ReadString(), net.ReadString()
	if kind == "notice" then
		ZCPhone.Notice(a)
	elseif kind == "call" then
		if a == "idle" then
			st.call = { state = "idle", peer = "", t = CurTime() }
			if b ~= "" then ZCPhone.Notice(b) end
			Home()
		else
			st.call = { state = a, peer = b, t = CurTime() }
		end
	elseif kind == "ir" then
		if a == "idle" then
			st.ir = { state = "idle", label = "", t0 = 0, dur = 8 }
			if b ~= "" then ZCPhone.Notice(b, 2) end
		else
			st.ir = { state = a, label = (a == "offer") and b or st.ir.label, t0 = CurTime(), dur = (a == "active") and tonumber(b) or 8 }
		end
	elseif kind == "sms" then
		local from = tonumber(a)
		table.insert(st.messages, 1, { from = from, text = b, ts = os.time(), read = false })
		while #st.messages > S.MaxMessages do table.remove(st.messages) end
		ZCPhone.Notice("Сообщение: " .. ZCPhone.NameOf(from), 3)
	end
end)

function ZCPhone.IsOut(ply)
	ply = ply or LocalPlayer()
	if not IsValid(ply) or not ply:Alive() then return false end
	local wep = ply:GetActiveWeapon()
	return IsValid(wep) and wep:GetClass() == ZCPhone.WeaponClass and ply:GetNWBool(NW, false)
end

local keyMap
local function BuildKeyMap()
	keyMap = {}
	for i = 0, 9 do
		keyMap[_G["KEY_" .. i]] = tostring(i)
		keyMap[_G["KEY_PAD_" .. i]] = tostring(i)
	end
	keyMap[KEY_PAD_MULTIPLY] = "*"
	keyMap[KEY_PAD_DIVIDE] = "#"
	keyMap[KEY_LBRACKET] = "*"
	keyMap[KEY_RBRACKET] = "#"
	for name, list in pairs(ZCPhone.Binds) do
		for _, k in ipairs(list) do keyMap[k] = name end
	end
end

local down = {}
hook.Add("Think", "ZCPhone_Input", function()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if not ZCPhone.IsOut(ply) then
		table.Empty(down)
		return
	end
	if not keyMap then BuildKeyMap() end
	local blocked = ply:IsTyping() or gui.IsGameUIVisible() or vgui.GetKeyboardFocus() ~= nil or vgui.CursorVisible()
	for code, name in pairs(keyMap) do
		local isDown = not blocked and input.IsKeyDown(code)
		if isDown and not down[code] then ZCPhone.Press(name) end
		if not isDown and down[code] and not ZCPhone.IsInteracting() then ZCPhone.TapEnd() end
		down[code] = isDown
	end
end)

hook.Add("PlayerBindPress", "ZCPhone_SwallowSlots", function(ply, bind)
	if not ZCPhone.IsOut(ply) or ply:IsTyping() or gui.IsGameUIVisible() or vgui.CursorVisible() or IsValid(vgui.GetKeyboardFocus()) then return end
	if string.sub(bind, 1, 4) == "slot" then return true end
end)

concommand.Add("zcphone_press", function(_, _, args)
	if args[1] then ZCPhone.Press(string.lower(args[1])) end
end)

concommand.Add("zcphone_number", function()
	print("[ZCPhone] ваш номер: " .. st.number)
end)

timer.Simple(5, function()
	net.Start("ZCPhone_Act")
	net.WriteUInt(7, 4)
	net.SendToServer()
end)
