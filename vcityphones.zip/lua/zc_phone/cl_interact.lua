ZCPhone = ZCPhone or {}

-- Virtual cursor: do not enable the VGUI screen clicker, which changes movement/input ownership.
local active = false
local cursorX, cursorY = 0, 0
local lockedAngle
local rightDown, leftDown = false, false
local cameraOrigin
local rayOrigin, rayDirection
local pressedAt = -10
local sensitivity = CreateClientConVar("zcphone_cursor_speed", "1", true, false, "Phone virtual cursor sensitivity")

function ZCPhone.IsInteracting() return active end

local function Stop()
 active = false
 lockedAngle = nil
 ZCPhone.HoverKey = nil
 rayOrigin, rayDirection = nil, nil
end
ZCPhone.StopInteraction = Stop

local function Blocked()
 local ply = LocalPlayer()
 return not IsValid(ply) or not ZCPhone.IsOut(ply) or ply:IsTyping()
  or gui.IsGameUIVisible() or vgui.CursorVisible() or IsValid(vgui.GetKeyboardFocus())
end

local function Toggle()
 if active then Stop() return end
 if Blocked() then return end
 active = true
 local a = LocalPlayer():EyeAngles()
 lockedAngle = Angle(a.p, a.y, a.r)
 cursorX, cursorY = ScrW() * 0.5, ScrH() * 0.5
 ZCPhone.PreviewKey = nil
end
concommand.Add("zcphone_interact", Toggle)

local function MoveCursor(cmd, x, y)
 if not active then return end
 if Blocked() then Stop() return end
 local speed = math.Clamp(sensitivity:GetFloat(), 0.05, 5)
 cursorX = math.Clamp(cursorX + x * speed, 0, ScrW() - 1)
 cursorY = math.Clamp(cursorY + y * speed, 0, ScrH() - 1)
 if lockedAngle then cmd:SetViewAngles(lockedAngle) end
 return true
end

hook.Add("InputMouseApply", "ZCPhone_CursorMouse", MoveCursor)
-- Z-City's fakeCameraAngles can consume the standard hook before ours runs.
-- In that path, consume its HG extension instead. A consumed standard hook
-- prevents the HG path from running, so deltas are not counted twice.
hook.Add("HG.InputMouseApply", "ZCPhone_CursorMouse", function(tbl)
 if not MoveCursor(tbl.cmd, tbl.x, tbl.y) then return end
 tbl.x, tbl.y = 0, 0
 tbl.angle = Angle(lockedAngle.p, lockedAngle.y, lockedAngle.r)
 tbl.override_angle = true
 return true
end)

hook.Add("CreateMove", "ZCPhone_LockPhoneView", function(cmd)
 if not active then return end
 if Blocked() then Stop() return end
 if lockedAngle then cmd:SetViewAngles(lockedAngle) end
 cmd:SetMouseX(0)
 cmd:SetMouseY(0)
 cmd:RemoveKey(IN_ATTACK)
 cmd:RemoveKey(IN_ATTACK2)
end)

-- Use actual render-camera origin (Z-City/third-person can differ from Player:EyePos).
hook.Add("RenderScene", "ZCPhone_CursorCamera", function(origin)
 cameraOrigin = Vector(origin.x, origin.y, origin.z)
end)

function ZCPhone.PickKey(origin, direction, world)
 local cfg = ZCPhone.Config
 local scale = math.max(0.01, cfg.Scale)
 local size = cfg.Keys.boxSize or Vector(0.35, 0.7, 0.6)
 local half = size * (scale * 0.5)
 local _, boxAngle = LocalToWorld(vector_origin, cfg.Keys.boxAng or angle_zero, world.pos, world.ang)
 local bestKey, bestDistance
 for _, key in ipairs(ZCPhone.KeyOrder) do
  local center = LocalToWorld(ZCPhone.KeyLocal(key) * scale, angle_zero, world.pos, world.ang)
  local hit = util.IntersectRayWithOBB(origin, direction * 512, center, boxAngle, -half, half)
  if hit then
   local distance = origin:DistToSqr(hit)
   if not bestDistance or distance < bestDistance then bestKey, bestDistance = key, distance end
  end
 end
 return bestKey
end

local cursorU, cursorV

function ZCPhone.CursorUV() return cursorU, cursorV end

local function Proj(world, scale, localPos)
 local p = LocalToWorld(localPos * scale, angle_zero, world.pos, world.ang):ToScreen()
 return p.x, p.y, p.visible
end

-- Screen-space picking: independent of the real camera origin (Z-City uses a custom camera).
local function Compute(world)
 local cfg = ZCPhone.Config
 local scale = math.max(0.01, cfg.Scale)
 local k = cfg.Keys
 local half = (k.boxSize or Vector(0.35, 0.7, 0.6)) * (scale * 0.5)
 local _, boxAng = LocalToWorld(vector_origin, k.boxAng or angle_zero, world.pos, world.ang)
 local best, bestD
 for _, key in ipairs(ZCPhone.KeyOrder) do
  local c = LocalToWorld(ZCPhone.KeyLocal(key) * scale, angle_zero, world.pos, world.ang)
  local minx, miny, maxx, maxy = math.huge, math.huge, -math.huge, -math.huge
  local ok = true
  for sx = -1, 1, 2 do for sy = -1, 1, 2 do for sz = -1, 1, 2 do
   local pt = LocalToWorld(Vector(half.x * sx, half.y * sy, half.z * sz), angle_zero, c, boxAng):ToScreen()
   if not pt.visible then ok = false end
   minx, miny = math.min(minx, pt.x), math.min(miny, pt.y)
   maxx, maxy = math.max(maxx, pt.x), math.max(maxy, pt.y)
  end end end
  if ok then
   local pad = 3
   if cursorX >= minx - pad and cursorX <= maxx + pad and cursorY >= miny - pad and cursorY <= maxy + pad then
    local cp = c:ToScreen()
    local d = (cp.x - cursorX) ^ 2 + (cp.y - cursorY) ^ 2
    if not bestD or d < bestD then best, bestD = key, d end
   end
  end
 end
 ZCPhone.HoverRect = nil
 local ox, oy, v1 = Proj(world, scale, k.origin)
 local ux, uy = Proj(world, scale, k.origin + k.colStep * 2)
 local vx, vy = Proj(world, scale, k.origin + k.rowStep * 3)
 ux, uy, vx, vy = ux - ox, uy - oy, vx - ox, vy - oy
 local det = ux * vy - uy * vx
 cursorU, cursorV = nil, nil
 if v1 and math.abs(det) > 1e-3 then
  local dx, dy = cursorX - ox, cursorY - oy
  cursorU = math.Clamp((dx * vy - dy * vx) / det, -0.4, 1.4)
  cursorV = math.Clamp((ux * dy - uy * dx) / det, -0.4, 1.4)
 end
 return best
end

hook.Add("Think", "ZCPhone_MouseInteraction", function()
 local right = input.IsMouseDown(MOUSE_RIGHT)
 local left = input.IsMouseDown(MOUSE_LEFT)
 if Blocked() then
  Stop()
 else
  if right and not rightDown then Toggle() end
  if active then
   if left and not leftDown and ZCPhone.HoverKey then
    pressedAt = CurTime()
    ZCPhone.Press(ZCPhone.HoverKey)
   end
  end
 end
 if leftDown and not left then ZCPhone.TapEnd() end
 rightDown, leftDown = right, left
end)

hook.Add("HUDPaint", "ZCPhone_InteractionCursor", function()
 if not active then return end
 -- ScreenToVector uses the real rendered projection, including its FOV and aspect ratio.
 local wp = LocalPlayer().zcPhoneWorld
 if wp and wp.frame >= FrameNumber() - 3 then
  ZCPhone.HoverKey = Compute(wp)
 else
  ZCPhone.HoverKey, cursorU, cursorV = nil, nil, nil
 end
 local key = ZCPhone.HoverKey
 local color = key and Color(255, 215, 60) or Color(230, 235, 240)
 if CurTime() - pressedAt < 0.15 then color = Color(100, 255, 130) end
 surface.SetDrawColor(color)
 surface.DrawLine(cursorX - 7, cursorY, cursorX + 7, cursorY)
 surface.DrawLine(cursorX, cursorY - 7, cursorX, cursorY + 7)
 surface.DrawOutlinedRect(cursorX - 3, cursorY - 3, 7, 7)
 if key then
  draw.SimpleText(key, "DermaDefaultBold", cursorX + 12, cursorY + 9, color)
 end
end)

hook.Add("PostDrawTranslucentRenderables", "ZCPhone_HoverZone", function(depth, sky)
 if depth or sky or not active or not ZCPhone.HoverKey then return end
 local ply = LocalPlayer()
 local world = IsValid(ply) and ply.zcPhoneWorld
 if not world or world.frame < FrameNumber() - 2 then return end
 local cfg = ZCPhone.Config
 local scale = math.max(0.01, cfg.Scale)
 local half = (cfg.Keys.boxSize or Vector(0.35, 0.7, 0.6)) * (scale * 0.5)
 local pos = LocalToWorld(ZCPhone.KeyLocal(ZCPhone.HoverKey) * scale, angle_zero, world.pos, world.ang)
 local _, ang = LocalToWorld(vector_origin, cfg.Keys.boxAng or angle_zero, world.pos, world.ang)
 render.DrawWireframeBox(pos, ang, -half, half, Color(255, 215, 60), false)
end)

hook.Add("ShutDown", "ZCPhone_InteractionCleanup", Stop)
