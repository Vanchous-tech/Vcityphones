-- Only the pose is networked: no photo/video content or input actions.
util.AddNetworkString("ZCPhone_ButtonPose")
local function finite(n) return isnumber(n) and n == n and math.abs(n) < 10000 end
net.Receive("ZCPhone_ButtonPose", function(_, ply)
    if not IsValid(ply) or not ply:Alive() or not ply:GetNWBool("ZCPhone_Out", false) then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= ZCPhone.WeaponClass then return end
    if (ply.zcPhoneNextPose or 0) > CurTime() then return end
    ply.zcPhoneNextPose = CurTime() + 0.09
    local p, a = net.ReadVector(), net.ReadAngle()
    if not finite(p.x) or not finite(p.y) or not finite(p.z) or not finite(a.p) or not finite(a.y) or not finite(a.r) then return end
    ply:SetNWVector("ZCPhone_ButtonOffset", Vector(math.Clamp(p.x,-12,12),math.Clamp(p.y,-12,12),math.Clamp(p.z,-12,12)))
    ply:SetNWAngle("ZCPhone_ButtonRotation", Angle(math.NormalizeAngle(a.p),math.NormalizeAngle(a.y),math.NormalizeAngle(a.r)))
end)
