ZCPhone.MergeConfig(ZCPhone.Config, {
	["Curl"] = {
		3.0928,
		40.0000,
		40.0000
	},
	["Hand"] = {
		["ang"] = Angle(180.00, 0.93, 0.00),
		["pos"] = Vector(3.990, -0.851, -1.778)
	},
	["Keys"] = {
		["boxAng"] = Angle(2.78, 90.00, 0.00),
		["boxSize"] = Vector(0.121, 0.610, 0.427),
		["colStep"] = Vector(0.598, 0.000, 0.000),
		["origin"] = Vector(-0.567, -0.464, -1.392),
		["rowStep"] = Vector(0.000, 0.000, -0.227),
		["special"] = {
			["green"] = Vector(0.567, -0.464, -0.670),
			["menu"] = Vector(-0.567, -0.464, -0.979),
			["ok"] = Vector(0.567, -0.464, -0.979),
			["red"] = Vector(-0.567, -0.464, -0.670)
		}
	},
	["Model"] = "models/ivancorn/gtaiv/electrical/phones/cellphone_whiz_highspeed.mdl",
	["Pose"] = {
		["handAng"] = Angle(3.55, 79.80, -158.66),
		["show"] = Vector(12.931, -5.345, 1.552),
		["time"] = 0.8000
	},
	["Scale"] = 1.2137,
	["Screen"] = {
		["ang"] = Angle(0.00, 0.00, 90.00),
		["enabled"] = true,
		["h"] = 2.7377,
		["pos"] = Vector(-0.851, -0.390, 2.217),
		["w"] = 1.7180
	},
	["Skin"] = 0.0000,
	["Thumb"] = {
		["corners"] = {
			["bl"] = {
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00)
			},
			["br"] = {
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00)
			},
			["tl"] = {
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00)
			},
			["tr"] = {
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00),
				Angle(0.00, 0.00, 0.00)
			}
		},
		["depth"] = 0.1000,
		["idle"] = {
			0.5000,
			0.6500
		},
		["lift"] = 0.5000,
		["maxStep"] = 25.0000,
		["press"] = {
			Angle(0.00, 0.00, 0.00),
			Angle(0.00, 0.00, 0.00),
			Angle(0.00, 0.00, 0.00)
		},
		["pressTime"] = 0.1600,
		["speed"] = 14.0000,
		["tipLen"] = 1.2000,
		["useIK"] = true
	}
})
