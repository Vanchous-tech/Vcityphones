-- Experimental local WebM capture. The engine writer captures the current
-- framebuffer; some GMod builds may ignore the offscreen render target.
local writer, name, started, lastFrame, frames, soundStarted
local MAX_SECONDS = 60
-- GoPro-inspired microphone coloration. Source DSP is a client-wide effect,
-- not a per-video audio filter; it also changes what the recorder hears.
local dspEnabled = CreateClientConVar("zcphone_video_dsp", "1", true, false,
    "Use GoPro-like low-fidelity DSP during phone video recording", 0, 1)
local audio = {active=false, unavailable=false, previous=nil, external=nil, last=nil, clipUntil=0, recoveryUntil=0}
local DSP_BASE, DSP_SHOT, DSP_RECOVERY = 56, 38, 32
local includeShot = {"gunshot", "firearm", "weapon_fire", "weapons/", ".single", "_single",
    "shoot", "shotgun", "pistol", "rifle", "smg", "sniper", "revolver", "explode", "explosion", "grenade"}
local excludeShot = {"reload", "deploy", "holster", "empty", "dryfire", "mag", "bolt",
    "cock", "pump", "shell", "equip", "draw", "pickup", "drop", "distant", "distance", "_dist", "/dist", "far", "tail", "echo", "reflect", "reverb"}
local function currentDSP()
    local cvar = GetConVar("dsp_player")
    if not cvar then return nil end
    return tonumber(cvar:GetString())
end
-- V-City's organism effect calls Player:SetDSP on every render frame. While
-- recording, intercept only requests for the local player and remember the
-- latest external request, instead of fighting over DSP on alternate frames.
-- The existing method (including other addons' wrappers) is always preserved.
local guard
local function installDSPGuard(ply)
    if type(FindMetaTable) ~= "function" then return false end
    local meta = FindMetaTable("Player")
    if type(meta) ~= "table" or type(meta.SetDSP) ~= "function" then return false end
    local upstream = meta.SetDSP
    local function wrapper(self, effect, fast, ...)
        if audio.active and self == audio.owner and not audio.setting then
            -- The Z-City SWARM wrapper may replay the phone's own DSP. Do not
            -- mistake that value for the game's actual state on restoration.
            if type(effect) == "number" and effect == effect and effect ~= audio.last then
                audio.external = effect
            end
            return
        end
        return upstream(self, effect, fast, ...)
    end
    guard = {meta=meta, upstream=upstream, wrapper=wrapper}
    meta.SetDSP = wrapper
    return true
end
local function removeDSPGuard()
    if not guard then return end
    -- Do not remove a wrapper installed later by another addon. Our wrapper
    -- becomes inert once audio.active is false and forwards to its upstream.
    if guard.meta.SetDSP == guard.wrapper then guard.meta.SetDSP = guard.upstream end
    guard = nil
end
local function setDSP(ply, value, fast)
    if not IsValid(ply) or type(ply.SetDSP) ~= "function" then return false end
    audio.setting = true
    local ok, err = pcall(ply.SetDSP, ply, value, fast == true)
    audio.setting = false
    if not ok then print("[ZCPhone Video] SetDSP: " .. tostring(err)) end
    return ok
end
local function stopAudioDSP()
    if not audio.active then removeDSPGuard() return end
    local current, last = currentDSP(), audio.last
    local restore = audio.external or audio.previous or 1
    -- Disable interception first, then detach only our own top-level wrapper.
    audio.active = false
    removeDSPGuard()
    if current ~= nil and last ~= nil and current == last then
        setDSP(LocalPlayer(), restore, true)
    end
    audio.previous, audio.external, audio.last, audio.owner = nil, nil, nil, nil
    audio.clipUntil, audio.recoveryUntil = 0, 0
end
local function startAudioDSP()
    if audio.active or audio.unavailable or not dspEnabled:GetBool() then return end
    local previous = currentDSP()
    local ply = LocalPlayer()
    if previous == nil or not IsValid(ply) or type(ply.SetDSP) ~= "function" then
        audio.unavailable = true
        print("[ZCPhone Video] DSP недоступен; запись продолжится без фильтра.")
        return
    end
    audio.active, audio.previous, audio.external, audio.last = true, previous, previous, nil
    audio.owner = ply
    if not installDSPGuard(ply) then
        print("[ZCPhone Video] Защита DSP недоступна; другие аддоны могут перебивать эффект.")
    end
    audio.clipUntil, audio.recoveryUntil = 0, 0
end
local function updateAudioDSP()
    if not writer or not soundStarted then stopAudioDSP() return end
    if not dspEnabled:GetBool() then stopAudioDSP() return end
    if not audio.active then startAudioDSP() end
    if not audio.active then return end
    local current = currentDSP()
    if current == nil then stopAudioDSP() audio.unavailable = true return end
    -- A cached native method, engine, or another addon can bypass the guard.
    -- Preserve that change for cleanup, then reapply the recording effect.
    if audio.last ~= nil and current ~= audio.last then audio.external = current end
    local now = RealTime()
    local target = now < audio.clipUntil and DSP_SHOT or (now < audio.recoveryUntil and DSP_RECOVERY or DSP_BASE)
    if current ~= target or audio.last ~= target then
        if setDSP(LocalPlayer(), target, false) then audio.last = target
        else stopAudioDSP() audio.unavailable = true end
    end
end
local function likelyShot(data)
    local soundName = string.lower(tostring(data.OriginalSoundName or data.SoundName or ""))
    if soundName == "" then return false end
    for _, pattern in ipairs(excludeShot) do if string.find(soundName, pattern, 1, true) then return false end end
    for _, pattern in ipairs(includeShot) do if string.find(soundName, pattern, 1, true) then return true end end
    local ent = data.Entity
    return IsValid(ent) and ent.IsWeapon and ent:IsWeapon() and data.Channel == CHAN_WEAPON
end
hook.Add("EntityEmitSound", "ZCPhone_VideoMicOverload", function(data)
    if not writer or not soundStarted or not dspEnabled:GetBool() or not likelyShot(data) then return end
    local name = string.lower(tostring(data.OriginalSoundName or data.SoundName or ""))
    local explosion = string.find(name, "explo", 1, true) ~= nil
    local origin = data.Pos
    if not isvector(origin) and IsValid(data.Entity) then origin = data.Entity:GetPos() end
    local camera = ZCPhone.CamWorld
    local listener = camera and camera.pos or EyePos()
    local distance = explosion and 1400 or 900
    if isvector(origin) and isvector(listener) and origin:DistToSqr(listener) > distance * distance then return end
    local now = RealTime()
    audio.clipUntil = math.max(audio.clipUntil, now + (explosion and 0.14 or 0.075))
    audio.recoveryUntil = math.max(audio.recoveryUntil, now + (explosion and 0.62 or 0.30))
    -- Change DSP before the sound starts. Returning nil does not suppress it.
    updateAudioDSP()
end)
local function sensitive(ply)
    return gui.IsGameUIVisible() or (gui.IsConsoleVisible and gui.IsConsoleVisible()) or ply:IsTyping()
        or (vgui and ((vgui.CursorVisible and vgui.CursorVisible()) or (vgui.GetKeyboardFocus and IsValid(vgui.GetKeyboardFocus()))))
end
function ZCPhone.IsVideoRecording() return writer ~= nil end
function ZCPhone.StopVideo(reason, failed)
    if not writer then stopAudioDSP() audio.unavailable = false return end
    local w, fileName, count, hadSound = writer, name, frames or 0, soundStarted
    writer, name, started, lastFrame, frames, soundStarted = nil, nil, nil, nil, nil, nil
    if hadSound then pcall(function() w:SetRecordSound(false) end) end
    stopAudioDSP()
    audio.unavailable = false
    local ok, err = pcall(function() w:Finish() end)
    if not ok then
        ZCPhone.Notice("Ошибка завершения видео", 4)
        print("[ZCPhone Video] Finish: " .. tostring(err))
    else
        ZCPhone.Notice((failed or count == 0) and "Видео не подтверждено" or "Запись завершена — проверьте файл", 4)
        print("[ZCPhone Video] " .. tostring(reason or "Остановка") .. "; кадров: " .. count .. "; ожидаемый файл: garrysmod/videos/" .. fileName .. ".webm")
    end
end
function ZCPhone.VideoFrame(w,h)
    if not writer then return end
    local ply = LocalPlayer()
    if not IsValid(ply) or sensitive(ply) then ZCPhone.StopVideo("Открыт интерфейс или чат") return end
    if w ~= 384 or h ~= 288 then ZCPhone.StopVideo("Неверный размер кадра", true) return end
    local now = RealTime()
    local dt = lastFrame and math.max(now-lastFrame, 1/240) or 1/15
    lastFrame = now
    local ok, err = pcall(function()
        if not soundStarted then writer:SetRecordSound(true) soundStarted = true end
        updateAudioDSP()
        writer:AddFrame(dt, false)
    end)
    if not ok then
        print("[ZCPhone Video] AddFrame: " .. tostring(err))
        ZCPhone.StopVideo("Ошибка записи кадра", true)
        return
    end
    frames = frames + 1
end
local function beginRecording()
    if writer then return end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ZCPhone.IsOut(ply) or ZCPhone.UI.screen ~= "camera" or not ZCPhone.VideoMode
        or ZCPhone.State.call.state ~= "idle" or ZCPhone.State.ir.state ~= "idle" or sensitive(ply) then
        return ZCPhone.Notice("Запись отменена: телефон или камера недоступны", 3)
    end
    if not ZCPhone.GetButtonCameraView or not ZCPhone.GetButtonCameraView() then return ZCPhone.Notice("Подождите: камера телефона не готова", 3) end
    if not video or not isfunction(video.Record) then return ZCPhone.Notice("video.Record недоступен в этой версии GMod", 4) end
    local n
    for i = 1, 10 do
        local candidate = string.format("zcphone_%d_%06d", os.time(), math.random(0,999999))
        if not file.Exists("videos/" .. candidate .. ".webm", "GAME") and not file.Exists("videos/" .. candidate .. ".raw", "GAME") then n = candidate break end
    end
    if not n then return ZCPhone.Notice("Не удалось выбрать имя видео", 4) end
    local ok, result, err = pcall(video.Record, {container="webm", video="vp8", audio="vorbis", quality=0.7,
        bitrate=80000, fps=15, lockfps=false, name=n, width=384, height=288})
    if not ok or not result then
        ZCPhone.Notice("Ошибка создания видео", 4)
        print("[ZCPhone Video] video.Record: " .. tostring(ok and err or result))
        return
    end
    writer, name, started, lastFrame, frames, soundStarted = result, n, RealTime(), nil, 0, false
    ZCPhone.Notice("Тестовая запись видео со звуком", 3)
end
function ZCPhone.RequestVideo()
    if writer then ZCPhone.StopVideo("Остановка пользователем") return end
    Derma_Query("Эксперимент: может записаться часть игрового экрана вместо камеры, а также игровой звук и голоса других игроков. DSP временно изменяет и звук, который слышите вы. Собственный микрофон не гарантирован. Возможен вылет нативного кодека GMod. Локальная запись до 60 секунд; проверьте файл перед показом. Начать?",
        "Кнопочный телефон — запись", "Начать", function() timer.Simple(0, beginRecording) end, "Отмена", function() end)
end
hook.Add("Think", "ZCPhone_ButtonVideoLifetime", function()
    if not writer then return end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ZCPhone.IsOut(ply) or ZCPhone.UI.screen ~= "camera" or not ZCPhone.VideoMode then ZCPhone.StopVideo("Камера закрыта") return end
    if ZCPhone.State.call.state ~= "idle" or ZCPhone.State.ir.state ~= "idle" then ZCPhone.StopVideo("Вызов или ИК") return end
    if sensitive(ply) then ZCPhone.StopVideo("Открыт интерфейс или чат") return end
    if not ply.zcPhoneWorld or not ply.zcPhoneWorld.frame or ply.zcPhoneWorld.frame < FrameNumber()-3 then ZCPhone.StopVideo("Потеряна камера") return end
    if RealTime()-started >= MAX_SECONDS then ZCPhone.StopVideo("Лимит 60 секунд") return end
    updateAudioDSP()
end)
hook.Add("ShutDown", "ZCPhone_ButtonVideoStop", function() ZCPhone.StopVideo("Выход") end)
concommand.Add("zcphone_stopvideo", function() ZCPhone.StopVideo("Аварийная остановка") end)
