-- Local-only playback of phone recordings. No server transfer and no remote URL.
-- DHTML support for asset:// WebM depends on the client's GMod browser branch.
local Z=ZCPhone
local playback = {status="idle"}
local MAX_BYTES=32*1024*1024

function Z.IsGalleryVideoName(name)
    return type(name)=="string" and #name<=48 and name:match("^zcphone_%d+_%d%d%d%d%d%d%.webm$")~=nil
end

function Z.StopGalleryVideo()
    local old=playback.panel
    playback={status="idle"}
    if IsValid(old) then
        -- Remove also terminates media audio; don't leave it playing in the background.
        old:Remove()
    end
end

function Z.GalleryVideoState(name)
    if playback.name~=name then return "idle" end
    return playback.status
end

function Z.GalleryVideoMaterial(name)
    if playback.name~=name or not IsValid(playback.panel) then return nil end
    local ok,mat=pcall(playback.panel.GetHTMLMaterial,playback.panel)
    if ok and mat and not mat:IsError() then
        -- HTML textures can be rounded up to power-of-two dimensions.
        local sizeOk,tw,th=pcall(function() return mat:Width(),mat:Height() end)
        if sizeOk and tw and th and tw>=384 and th>=288 then
            return mat,384/tw,288/th
        end
        return mat,1,1
    end
end

local HTML=[=[<!DOCTYPE html><html><head><meta charset="utf-8"><style>
html,body { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#000; }
video { width:100%; height:100%; object-fit:contain; background:#000; }
</style></head><body><video id="v" playsinline preload="auto"></video><script>
(function() {
 var v=document.getElementById('v');
 function report(s) { if (window.zcphone && window.zcphone.state) window.zcphone.state(s); }
 function play() {
   try { var p=v.play(); if (p && p.catch) p.catch(function(){ report('blocked'); }); }
   catch(e) { report('blocked'); }
 }
 v.addEventListener('playing',function(){report('playing');});
 v.addEventListener('pause',function(){if(!v.ended) report('paused');});
 v.addEventListener('ended',function(){report('ended');});
 v.addEventListener('error',function(){report('error');});
 window.zcStart=function(url) { v.src=url; v.load(); play(); };
 window.zcToggle=function() {
   if(v.ended) { try {v.currentTime=0;} catch(e) {} play(); }
   else if(v.paused) play(); else v.pause();
 };
})();
</script></body></html>]=]

function Z.ToggleGalleryVideo(name)
    if not Z.IsGalleryVideoName(name) then return Z.Notice("Неверное имя видео",3) end
    if Z.IsVideoRecording and Z.IsVideoRecording() then return Z.Notice("Сначала останови запись",3) end
    if playback.name==name and IsValid(playback.panel) then
        if playback.status=="error" or playback.status=="blocked" then Z.StopGalleryVideo()
        else playback.panel:QueueJavascript("if(window.zcToggle) window.zcToggle();") return end
    end
    local path="videos/"..name
    if not file.Exists(path,"MOD") then return Z.Notice("Видео не найдено в garrysmod/videos",4) end
    local size=file.Size(path,"MOD")
    if not size or size<=0 then return Z.Notice("Видео пустое или недоступно",4) end
    if size>MAX_BYTES then return Z.Notice("Видео больше 32 МиБ — открой вне игры",4) end
    Z.StopGalleryVideo()
    if not vgui or not vgui.Create then return Z.Notice("Встроенный видеоплеер недоступен",4) end
    local ok,panel=pcall(vgui.Create,"DHTML")
    if not ok or not IsValid(panel) then return Z.Notice("Не удалось создать видеоплеер",4) end
    playback={name=name,panel=panel,status="loading",started=RealTime()}
    panel:SetSize(384,288)
    panel:SetPos(0,0)
    panel:SetAlpha(0) -- visible to VGUI/Think, but never drawn as a desktop window
    panel:SetMouseInputEnabled(false)
    panel:SetKeyboardInputEnabled(false)
    panel:SetAllowLua(false)
    panel.OnDocumentReady=function(self)
        if playback.panel~=self or playback.name~=name then return end
        self:AddFunction("zcphone","state",function(status)
            if playback.panel~=self then return end
            if status=="playing" or status=="paused" or status=="ended" or status=="error" or status=="blocked" then
                playback.status=status
                if status=="error" or status=="blocked" then
                    print("[ZCPhone Gallery] Video "..status.."; local WebM could not be played by DHTML. Check Chromium and the file in garrysmod/videos.")
                end
            end
        end)
        -- Only a strict local filename can reach JS. Never allow a supplied URL.
        self:QueueJavascript("if(window.zcStart) window.zcStart('asset://garrysmod/videos/"..name.."');")
    end
    panel:SetHTML(HTML)
end

hook.Add("PreRender","ZCPhone_GalleryVideoTexture",function()
    local panel=playback.panel
    if IsValid(panel) and panel.UpdateHTMLTexture then pcall(panel.UpdateHTMLTexture,panel) end
end)
hook.Add("Think","ZCPhone_GalleryVideoLifetime",function()
    if not IsValid(playback.panel) then return end
    local st=Z.State
    if not Z.IsOut() or Z.UI.screen~="gallery" or not st or st.call.state~="idle" or st.ir.state~="idle"
        or (Z.GallerySelectedName and Z.GallerySelectedName()~=playback.name) then
        Z.StopGalleryVideo()
        return
    end
    if playback.status=="loading" and RealTime()-playback.started>15 then
        playback.status="error"
        print("[ZCPhone Gallery] Video load timeout. Check Chromium and the file in garrysmod/videos.")
    end
end)
hook.Add("ShutDown","ZCPhone_GalleryVideoShutdown",Z.StopGalleryVideo)
