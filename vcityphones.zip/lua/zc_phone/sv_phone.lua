ZCPhone = ZCPhone or {}
local S = ZCPhone.Settings

util.AddNetworkString("ZCPhone_Act")
util.AddNetworkString("ZCPhone_Sync")
util.AddNetworkString("ZCPhone_Evt")
util.AddNetworkString("ZCPhone_IRData")

local NW = "ZCPhone_Out"
local calls = {}
local numToSid = {}

sql.Query("CREATE TABLE IF NOT EXISTS zcphone_numbers (sid TEXT PRIMARY KEY, num INTEGER UNIQUE)")
sql.Query("CREATE TABLE IF NOT EXISTS zcphone_contacts (sid TEXT, num INTEGER, name TEXT, PRIMARY KEY (sid, num))")
sql.Query("CREATE TABLE IF NOT EXISTS zcphone_settings (sid TEXT PRIMARY KEY, ring TEXT, silent INTEGER)")
sql.Query("CREATE TABLE IF NOT EXISTS zcphone_msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, to_num INTEGER, from_num INTEGER, body TEXT, ts INTEGER)")

local function Q(s) return sql.SQLStr(tostring(s)) end

local function CleanText(value, limit)
 local text = tostring(value or "")
 local length = utf8.len(text)
 if not length then return "" end
 if length > limit then
  local chars, n = {}, 0
  for ch in string.gmatch(text, utf8.charpattern) do
   n = n + 1
   if n > limit then break end
   chars[n] = ch
  end
  text = table.concat(chars)
 end
 return string.Trim(text)
end

local function NumberExists(n)
	local r = sql.Query("SELECT sid FROM zcphone_numbers WHERE num = " .. tonumber(n))
	return r and r[1] ~= nil
end

local function GetNumber(ply)
	local sid = ply:SteamID64() or ply:SteamID()
	local r = sql.Query("SELECT num FROM zcphone_numbers WHERE sid = " .. Q(sid))
	if r and r[1] then return tonumber(r[1].num) end
	local lo, hi = 10 ^ (S.NumberDigits - 1), 10 ^ S.NumberDigits - 1
	for _ = 1, 200 do
		local n = math.random(lo, hi)
		if not NumberExists(n) then
			sql.Query("INSERT INTO zcphone_numbers (sid, num) VALUES (" .. Q(sid) .. ", " .. n .. ")")
			return n
		end
	end
	for n = lo, hi do
		if not NumberExists(n) then
			sql.Query("INSERT INTO zcphone_numbers (sid, num) VALUES (" .. Q(sid) .. ", " .. n .. ")")
			return n
		end
	end
end

local function PlayerByNumber(n)
	for _, p in ipairs(player.GetAll()) do
		if p.zcPhoneNumber == n then return p end
	end
end

local function LoadContacts(ply)
	local out, have = {}, {}
	local r = sql.Query("SELECT num, name FROM zcphone_contacts WHERE sid = " .. Q(ply:SteamID64() or ply:SteamID()) .. " ORDER BY name")
	for _, row in ipairs(r or {}) do
		local num = tonumber(row.num)
		out[#out + 1] = { num = num, name = row.name }
		have[num] = true
	end
	-- служебные контакты (не хранятся в базе, не считаются в лимит): Штаб и то, что вернул хук режима
	local function auto(num, name)
		num = tonumber(num)
		if not num or have[num] or num == ply.zcPhoneNumber then return end
		have[num] = true
		out[#out + 1] = { num = num, name = CleanText(name, S.MaxNameLength), auto = true }
	end
	auto(ZCPhone.SystemNumber, ZCPhone.SystemName)
	local extra = hook.Run("ZCPhone_ExtraContacts", ply)
	if istable(extra) then
		for _, e in ipairs(extra) do auto(e.num, e.name) end
	end
	return out
end

local function UserContactCount(ply)
	local n = 0
	for _, c in ipairs(ply.zcPhoneContacts or {}) do
		if not c.auto then n = n + 1 end
	end
	return n
end

local function HasContact(ply, n)
	for _, c in ipairs(ply.zcPhoneContacts or {}) do
		if c.num == n then return c end
	end
end

local function LoadMessages(ply)
	local out = {}
	local r = sql.Query("SELECT from_num, body, ts FROM zcphone_msgs WHERE to_num = " .. ply.zcPhoneNumber .. " ORDER BY id DESC LIMIT " .. S.MaxMessages)
	for _, row in ipairs(r or {}) do out[#out + 1] = { from = tonumber(row.from_num), text = row.body, ts = tonumber(row.ts) } end
	return out
end

local function LoadSettings(ply)
	local r = sql.Query("SELECT ring, silent FROM zcphone_settings WHERE sid = " .. Q(ply:SteamID64() or ply:SteamID()))
	local row = r and r[1]
	ply.zcPhoneRing = row and row.ring or ""
	ply.zcPhoneSilent = row and tonumber(row.silent) == 1 or false
end

local function Sync(ply)
	net.Start("ZCPhone_Sync")
	net.WriteUInt(ply.zcPhoneNumber or 0, 16)
	net.WriteTable(ply.zcPhoneContacts or {})
	net.WriteTable(LoadMessages(ply))
	net.WriteString(ply.zcPhoneRing or "")
	net.WriteBool(ply.zcPhoneSilent or false)
	net.Send(ply)
end

local function Evt(ply, kind, a, b)
	if not IsValid(ply) then return end
	net.Start("ZCPhone_Evt")
	net.WriteString(kind)
	net.WriteString(tostring(a or ""))
	net.WriteString(tostring(b or ""))
	net.Send(ply)
end

local function Notice(ply, text) Evt(ply, "notice", text) end

local function PeerLabel(viewer, other)
	local c = HasContact(viewer, other.zcPhoneNumber)
	return c and c.name or tostring(other.zcPhoneNumber)
end

local function StopRing(ply)
	if not IsValid(ply) then return end
	local c = calls[ply]
	if c and c.path then
		ply:StopSound(c.path) -- exactly what this call started (the list may have changed since)
		c.path = nil
		return
	end
	for _, r in ipairs(ZCPhone.Sounds.rings) do ply:StopSound(r.path) end
	ply:StopSound(S.RingSound)
end

local function EndCall(ply, reason)
	local c = calls[ply]
	if not c then return end
	StopRing(ply)
	local peer = c.peer
	calls[ply] = nil
	if IsValid(peer) and calls[peer] and calls[peer].peer == ply then calls[peer] = nil end
	Evt(ply, "call", "idle", reason or "")
	if IsValid(peer) then Evt(peer, "call", "idle", reason or "") end
end

local function Alive(ply) return IsValid(ply) and ply:IsPlayer() and ply:Alive() end

local cvNet = CreateConVar("zcphone_network", "1", FCVAR_ARCHIVE + FCVAR_NOTIFY, "Network mode: 0 = down, 1 = normal, 2 = degraded")
local SIG_NW = "ZCPhone_Signal"

local function JamLevel(pos)
	local best = 0
	for _, j in ipairs(ents.FindByClass("zc_fpv_jammer")) do
		if IsValid(j) and j.GetJamStrength then
			best = math.max(best, j:GetJamStrength(pos) or 0)
		end
	end
	return best
end

local horiz = {}
for i = 0, 7 do
	local a = math.rad(i * 45)
	horiz[#horiz + 1] = Vector(math.cos(a), math.sin(a), 0)
end

local function IndoorPenalty(ply)
	local eye = ply:EyePos()
	local pen = 0
	local up = util.TraceLine({ start = eye, endpos = eye + Vector(0, 0, 700), mask = MASK_SOLID, filter = function() return false end })
	local roof = up.Hit and not up.HitSky
	if roof then pen = pen + 0.22 end
	local blocked = 0
	for _, d in ipairs(horiz) do
		local tr = util.TraceLine({ start = eye, endpos = eye + d * 600, mask = MASK_SOLID, filter = function() return false end })
		if tr.Hit and not tr.HitSky then blocked = blocked + 1 end
	end
	pen = pen + (blocked / 8) * 0.18
	if roof and blocked >= 6 then pen = pen + 0.05 end
	return pen
end

local function SignalAt(pos)
	local mode = cvNet:GetInt()
	if mode <= 0 then return 0 end
	local sig = 1
	local jam = JamLevel(pos)
	if jam > 0 then sig = sig * (1 - math.Clamp(jam / 0.4, 0, 1)) end
	if ZCPhone.TowerCoverage then sig = sig * ZCPhone.TowerCoverage(pos) end
	if mode >= 2 then sig = sig * 0.5 end
	return math.Clamp(sig, 0, 1)
end

local function ComputeSignal(ply)
	local base = SignalAt(ply:GetPos())
	if base <= 0 then return 0 end
	return math.Clamp((1 - IndoorPenalty(ply)) * base, 0, 1)
end

local function BarsOf(sig)
	if sig < 0.08 then return 0 end
	if sig <= 0.25 then return 1 end
	if sig <= 0.5 then return 2 end
	if sig <= 0.75 then return 3 end
	return 4
end

local function HasSignal(ply) return IsValid(ply) and (ply.zcPhoneBars or 0) >= 1 end

local function UpdateSignal(ply)
	local raw = ComputeSignal(ply)
	local prev = ply.zcPhoneSig or raw
	local sig = prev + (raw - prev) * 0.6
	if raw == 0 then sig = 0 end
	ply.zcPhoneSig = sig
	local bars = BarsOf(sig)
	local old = ply.zcPhoneBars
	ply.zcPhoneBars = bars
	if old ~= bars then ply:SetNWInt(SIG_NW, bars) end
	if (old or 0) == 0 and bars >= 1 and ply.zcPhonePending then
		ply.zcPhonePending = nil
		Sync(ply)
		Notice(ply, "Связь восстановлена")
		if not ply.zcPhoneSilent then ply:EmitSound(ZCPhone.Sounds.sms or S.MessageSound, 65, 100, 1) end
	end
end

timer.Create("ZCPhone_Signal", 1, 0, function()
	for _, ply in ipairs(player.GetAll()) do
		if ply.zcPhoneNumber then
			if ply:Alive() then UpdateSignal(ply) else ply.zcPhoneBars = 0 ply:SetNWInt(SIG_NW, 0) end
		end
	end
end)

cvars.AddChangeCallback("zcphone_network", function(_, _, new)
	local text = tonumber(new) == 0 and "Сотовая связь отключена" or tonumber(new) == 2 and "Связь работает с перебоями" or "Связь восстановлена"
	for _, ply in ipairs(player.GetAll()) do
		if ply.zcPhoneNumber then Notice(ply, text) end
	end
end, "ZCPhone_NetNotify")

concommand.Add("zcphone_net", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	local n = tonumber(args[1])
	if n == nil or n < 0 or n > 2 then return print("[ZCPhone] zcphone_net <0 нет сети | 1 норма | 2 помехи>") end
	RunConsoleCommand("zcphone_network", tostring(math.floor(n)))
end)

local bombNum = {}
local AddContact

local function BombPos(wep)
	if not IsValid(wep) then return end
	if IsValid(wep.HaveTheBomb) then return wep.HaveTheBomb:GetPos() end
	if wep.PlantedOnSelf and IsValid(wep:GetOwner()) then return wep:GetOwner():GetPos() end
end

local function TriggerBomb(wep)
	if not IsValid(wep) or wep.KABOOM or not wep.Planted then return end
	if (wep.nextattackhuy or 0) > CurTime() then return end
	wep:PrimaryAttack()
end

local function CallBomb(ply, wep)
	local pos = BombPos(wep)
	if not pos or wep.KABOOM then return Notice(ply, "Номер не обслуживается") end
	if SignalAt(pos) < 0.08 then return Notice(ply, "Абонент вне зоны сети") end
	Notice(ply, "Соединение...")
	timer.Simple(1.2, function()
		local p2 = BombPos(wep)
		if p2 and SignalAt(p2) >= 0.08 then TriggerBomb(wep) end
	end)
end

local function SmsBomb(ply, wep, text)
	local pos = BombPos(wep)
	if not pos or wep.KABOOM then return Notice(ply, "Номер не обслуживается") end
	if SignalAt(pos) < 0.08 then return Notice(ply, "Абонент вне зоны сети") end
	local t = string.lower(string.Trim(text))
	local sec = string.match(t, "^t(%d+)$")
	if t == "boom" or t == "бум" or t == "взрыв" then
		Notice(ply, "Принято")
		timer.Simple(1, function() if BombPos(wep) and SignalAt(BombPos(wep)) >= 0.08 then TriggerBomb(wep) end end)
	elseif sec then
		sec = math.Clamp(tonumber(sec), 1, 300)
		Notice(ply, "Таймер " .. sec .. " с")
		timer.Simple(sec, function() if BombPos(wep) and SignalAt(BombPos(wep)) >= 0.08 then TriggerBomb(wep) end end)
	else
		Notice(ply, "Команда не распознана")
	end
end

local function AssignBombNumber(ply, wep)
	local lo, hi = 10 ^ (S.NumberDigits - 1), 10 ^ S.NumberDigits - 1
	for _ = 1, 100 do
		local n = math.random(lo, hi)
		if not NumberExists(n) and not bombNum[n] then
			bombNum[n] = wep
			wep.bombNumber = n
			AddContact(ply, "IED", n)
			Notice(ply, "Детонатор: №" .. n)
			return
		end
	end
end

timer.Create("ZCPhone_Bombs", 1, 0, function()
	for n, wep in pairs(bombNum) do
		if not IsValid(wep) or wep.KABOOM then bombNum[n] = nil end
	end
	for _, ply in ipairs(player.GetAll()) do
		if ply.zcPhoneNumber and ply:Alive() then
			local wep = ply:GetWeapon("weapon_traitor_ied")
			if IsValid(wep) and wep.Planted and not wep.KABOOM and not wep.bombNumber then AssignBombNumber(ply, wep) end
		end
	end
end)

local function CanEnc(p)
	return IsValid(p) and hook.Run("ZCPhone_CanEncrypt", p) ~= false
end

local function StartCall(ply, n)
	if calls[ply] then return Notice(ply, "Вы уже в вызове") end
	if not HasContact(ply, n) then return Notice(ply, "Нет в контактах") end
	if not HasSignal(ply) then return Notice(ply, "Нет сети") end
	if bombNum[n] then return CallBomb(ply, bombNum[n]) end
	if n == ZCPhone.SystemNumber then return Notice(ply, "Штаб отвечает только по SMS") end
	if n == ply.zcPhoneNumber then return Notice(ply, "Это ваш номер") end
	local target = PlayerByNumber(n)
	if not Alive(target) then return Notice(ply, "Абонент недоступен") end
	if not HasSignal(target) then return Notice(ply, "Абонент вне зоны сети") end
	if calls[target] then return Notice(ply, "Абонент занят") end
	local enc = false
	if ply.zcPhoneEnc and CanEnc(ply) then
		if CanEnc(target) then
			enc = true
		else
			Notice(ply, "У абонента нет шифра: открытый канал")
		end
	end
	local c = { peer = target, state = "ring", t = CurTime(), out = true, last = 0, enc = enc }
	local c2 = { peer = ply, state = "ring", t = CurTime(), out = false, last = 0, enc = enc }
	calls[ply], calls[target] = c, c2
	ply:SetNWBool("ZCPhone_EncCall", enc)
	target:SetNWBool("ZCPhone_EncCall", enc)
	Evt(ply, "call", "out", PeerLabel(ply, target))
	Evt(target, "call", "in", PeerLabel(target, ply))
end

local function Answer(ply)
	local c = calls[ply]
	if not c or c.state ~= "ring" or c.out then return end
	local peer = c.peer
	if not IsValid(peer) or not calls[peer] then return EndCall(ply) end
	StopRing(ply)
	local t = CurTime()
	c.state, c.t = "active", t
	calls[peer].state, calls[peer].t = "active", t
	Evt(ply, "call", "active", PeerLabel(ply, peer))
	Evt(peer, "call", "active", PeerLabel(peer, ply))
end

local function SendSMS(ply, n, text)
	if not HasContact(ply, n) then return Notice(ply, "Нет в контактах") end
	text = CleanText(text, S.MaxMessageLength)
	if text == "" then return end
	if not HasSignal(ply) then return Notice(ply, "Нет сети") end
	if bombNum[n] then return SmsBomb(ply, bombNum[n], text) end
	if n == ZCPhone.SystemNumber then
		if ZCPhone.SystemSms then ZCPhone.SystemSms(ply, text) end
		return
	end
	if not NumberExists(n) then return Notice(ply, "Номер не существует") end
	local amount = tonumber(text:match("^перевод%s+(%d+)$") or text:match("^Перевод%s+(%d+)$") or text:lower():match("^pay%s+(%d+)$") or "")
	if amount and amount > 9999999 then return Notice(ply, "Слишком большая сумма") end
	if amount then
		local to = PlayerByNumber(n)
		if not IsValid(to) then return Notice(ply, "Получатель не в сети") end
		local ok, msg = hook.Run("ZCPhone_Transfer", ply, to, amount)
		if ok == nil then return Notice(ply, "Переводы недоступны") end
		if not ok then return Notice(ply, msg or "Перевод отклонён") end
		text = "Перевод +" .. amount
		ply.zcPhoneLastTransfer = CurTime()
	end
	ply.zcPhoneSmsAt = CurTime()
	sql.Query(string.format("INSERT INTO zcphone_msgs (to_num, from_num, body, ts) VALUES (%d, %d, %s, %d)", n, ply.zcPhoneNumber, Q(text), os.time()))
	sql.Query("DELETE FROM zcphone_msgs WHERE to_num = " .. n .. " AND id NOT IN (SELECT id FROM zcphone_msgs WHERE to_num = " .. n .. " ORDER BY id DESC LIMIT " .. S.MaxMessages .. ")")
	local target = PlayerByNumber(n)
	if IsValid(target) and not HasSignal(target) then
		target.zcPhonePending = true
		return Notice(ply, "Отправлено, доставка при связи")
	end
	Notice(ply, "Отправлено")
	if IsValid(target) then
		Evt(target, "sms", ply.zcPhoneNumber, text)
		if not target.zcPhoneSilent then
			target:EmitSound(ZCPhone.Sounds.sms or S.MessageSound, 65, 100, 1)
		end
	end
end

function AddContact(ply, name, n)
	n = tonumber(n)
	if not n or n < 10 ^ (S.NumberDigits - 1) or n > 10 ^ S.NumberDigits - 1 then return Notice(ply, "Неверный номер") end
	if n == ply.zcPhoneNumber then return Notice(ply, "Это ваш номер") end
	name = CleanText(name, S.MaxNameLength)
	if name == "" then name = tostring(n) end
	if not HasContact(ply, n) and UserContactCount(ply) >= S.MaxContacts then return Notice(ply, "Книга контактов полна") end
	sql.Query(string.format("INSERT OR REPLACE INTO zcphone_contacts (sid, num, name) VALUES (%s, %d, %s)", Q(ply:SteamID64() or ply:SteamID()), n, Q(name)))
	ply.zcPhoneContacts = LoadContacts(ply)
	Sync(ply)
	Notice(ply, "Контакт сохранён")
end

local function DelContact(ply, n)
	local existing = HasContact(ply, n)
	if existing and existing.auto then return Notice(ply, "Служебный контакт") end
	sql.Query(string.format("DELETE FROM zcphone_contacts WHERE sid = %s AND num = %d", Q(ply:SteamID64() or ply:SteamID()), n))
	ply.zcPhoneContacts = LoadContacts(ply)
	Sync(ply)
	Notice(ply, "Контакт удалён")
end

local IR_RANGE, IR_ACQ, IR_TIME, IR_OFFER = 220, 0.9, 8, 10
local IR_BYTES = 768 -- backwards-compatible legacy four-shade photo
local ir, irOf = {}, {}
local photo = ZCPhone.Photo
local nextPhotoID = 0
util.AddNetworkString("ZCPhone_IRStart2")
util.AddNetworkString("ZCPhone_IRChunk2")
util.AddNetworkString("ZCPhone_IRStream2")
util.AddNetworkString("ZCPhone_IRResult2")
util.AddNetworkString("ZCPhone_Shutter")

local function IRStream(player, op, id, write)
    if not IsValid(player) then return end
    net.Start("ZCPhone_IRStream2")
    net.WriteUInt(op, 3)
    net.WriteUInt(id, 32)
    if write then write() end
    net.Send(player)
end

local function IRStop(sender, reason)
    local t = ir[sender]
    if not t then return end
    ir[sender] = nil
    irOf[t.target] = nil
    if t.photoID then
        IRStream(sender, 3, t.photoID)
        IRStream(t.target, 3, t.photoID)
    end
    Evt(sender, "ir", "idle", reason or "")
    if IsValid(t.target) then Evt(t.target, "ir", "idle", reason or "") end
end

local function IRLink(a, b, minA, minB)
    local ea, eb = a:EyePos(), b:EyePos()
    local d = eb - ea
    local dist = d:Length()
    if dist > IR_RANGE * 1.3 or dist < 1 then return false end
    d:Normalize()
    if a:GetAimVector():Dot(d) < minA or b:GetAimVector():Dot(-d) < minB then return false end
    local tr = util.TraceLine({ start = ea, endpos = eb, filter = { a, b }, mask = MASK_SOLID_BRUSHONLY })
    return not tr.Hit
end

local function IRStart(ply, data, meta)
    if calls[ply] or ir[ply] or irOf[ply] then return Notice(ply, "ИК-порт занят") end
    if meta then
        local count = 0
        for _, x in pairs(ir) do if x.photoID then count = count + 1 end end
        if count >= photo.MaxSessions then return Notice(ply, "ИК-порты заняты, попробуйте позже") end
    end
    local eye, aim = ply:EyePos(), ply:GetAimVector()
    local best, bestDot
    for _, p in ipairs(player.GetAll()) do
        if p ~= ply and Alive(p) and p:GetNWBool(NW, false) and not ir[p] and not irOf[p] and not calls[p] and p.zcPhoneNumber then
            local d = p:EyePos() - eye
            if d:Length() < IR_RANGE then
                d:Normalize()
                local dot = aim:Dot(d)
                if dot > IR_ACQ and (not bestDot or dot > bestDot) then
                    local tr = util.TraceLine({ start = eye, endpos = p:EyePos(), filter = { ply, p }, mask = MASK_SOLID_BRUSHONLY })
                    if not tr.Hit then best, bestDot = p, dot end
                end
            end
        end
    end
    if not best then return Notice(ply, "Нет цели для ИК") end
    local t = { target = best, state = "offer", t = CurTime(), data = data, bad = 0 }
    if meta then
        nextPhotoID = nextPhotoID % 4294967295 + 1
        t.photoID, t.size, t.crc = nextPhotoID, meta.size, meta.crc
    end
    ir[ply] = t
    irOf[best] = ply
    Evt(ply, "ir", "wait")
    Evt(best, "ir", "offer", PeerLabel(best, ply))
end

local function IRAccept(ply)
    local sender = irOf[ply]
    local t = sender and ir[sender]
    if not t or t.state ~= "offer" then return end
    if not Alive(sender) or not Alive(ply) or not sender:GetNWBool(NW, false) or not ply:GetNWBool(NW, false) then return IRStop(sender, "Связь потеряна") end
    t.state, t.t = "active", CurTime()
    Evt(sender, "ir", "active", IR_TIME)
    Evt(ply, "ir", "active", IR_TIME)
    if t.photoID then
        t.parts, t.received, t.index, t.nextChunk = {}, 0, 0, 0
        local function start(isSender)
            return function()
                net.WriteBool(isSender)
                net.WriteUInt(t.size, 22)
                net.WriteString(t.crc)
            end
        end
        IRStream(sender, 0, t.photoID, start(true))
        IRStream(ply, 0, t.photoID, start(false))
    end
end

local function IRCancel(ply)
    if ir[ply] then IRStop(ply, "Отменено") elseif irOf[ply] then IRStop(irOf[ply], "Отказано") end
end

-- No bytes are requested until the target has explicitly accepted the offer.
net.Receive("ZCPhone_IRStart2", function(_, ply)
    if not Alive(ply) or not ply.zcPhoneNumber then return end
    local w = ply:GetActiveWeapon()
    if not IsValid(w) or w:GetClass() ~= ZCPhone.WeaponClass or not ply:GetNWBool(NW, false) then return end
    if (ply.zcPhotoOfferNext or 0) > CurTime() then return end
    ply.zcPhotoOfferNext = CurTime() + 2
    local size, crc = net.ReadUInt(22), net.ReadString()
    if size < 32 or size > photo.MaxBytes or not crc:match("^%d+$") or #crc > 10 then return end
    IRStart(ply, nil, {size = size, crc = crc})
end)

net.Receive("ZCPhone_IRChunk2", function(bits, ply)
    local id, index, n = net.ReadUInt(32), net.ReadUInt(16), net.ReadUInt(14)
    local t = ir[ply]
    if not t or t.photoID ~= id or t.state ~= "active" or t.uploadDone then return end
    if not Alive(ply) or not Alive(t.target) or not ply:GetNWBool(NW, false) or not t.target:GetNWBool(NW, false) then return IRStop(ply, "Связь потеряна") end
    if not IRLink(ply, t.target, 0.7, 0.4) then return IRStop(ply, "Связь потеряна") end
    if CurTime() < t.nextChunk then return IRStop(ply, "Слишком быстрая передача") end
    local remaining = t.size - t.received
    local expected = math.min(photo.ChunkBytes, remaining)
    if index ~= t.index + 1 or n ~= expected or n < 1 or bits < 32 + 16 + 14 + n * 8 then return IRStop(ply, "Ошибка данных ИК") end
    local data = net.ReadData(n)
    if not isstring(data) or #data ~= n then return IRStop(ply, "Ошибка данных ИК") end
    t.nextChunk = CurTime() + 0.05
    t.index, t.received = index, t.received + n
    t.parts[index] = data
    t.lastData = CurTime()
    IRStream(t.target, 1, t.photoID, function()
        net.WriteUInt(index, 16)
        net.WriteUInt(n, 14)
        net.WriteData(data, n)
    end)
    if t.received == t.size then
        local full = table.concat(t.parts)
        t.parts = nil
        if util.CRC(full) ~= t.crc or not photo.ValidJPEG(full) then return IRStop(ply, "Повреждённое фото") end
        t.uploadDone = true
    end
    IRStream(ply, 1, t.photoID, function() net.WriteUInt(index, 16) end)
end)

net.Receive("ZCPhone_IRResult2", function(_, ply)
    local id, saved = net.ReadUInt(32), net.ReadBool()
    local sender = irOf[ply]
    local t = sender and ir[sender]
    if not t or t.photoID ~= id or t.target ~= ply or t.state ~= "confirm" then return end
    IRStop(sender, saved and "Фото передано" or "Не удалось сохранить фото")
end)

net.Receive("ZCPhone_Shutter", function(_, ply)
    if not Alive(ply) or (ply.zcPhotoShutterNext or 0) > CurTime() then return end
    local w = ply:GetActiveWeapon()
    if not IsValid(w) or w:GetClass() ~= ZCPhone.WeaponClass or not ply:GetNWBool(NW, false) then return end
    ply.zcPhotoShutterNext = CurTime() + 1
    ply:EmitSound("npc/scanner/scanner_photo1.wav", 65, 100, 0.9)
end)

timer.Create("ZCPhone_IR", 0.25, 0, function()
    local now = CurTime()
    for sender, t in pairs(ir) do
        local target = t.target
        if not IsValid(sender) or not IsValid(target) then
            IRStop(sender, "Связь потеряна")
        elseif t.state == "offer" then
            if now - t.t > IR_OFFER then IRStop(sender, "Нет ответа") end
        elseif not Alive(sender) or not Alive(target) or not sender:GetNWBool(NW, false) or not target:GetNWBool(NW, false) then
            IRStop(sender, "Связь потеряна")
        elseif t.state == "confirm" then
            if now - t.confirmAt > 15 then IRStop(sender, "Нет подтверждения сохранения") end
        elseif IRLink(sender, target, 0.7, 0.4) then
            t.bad = 0
            if t.photoID then
                if t.uploadDone and now - t.t >= IR_TIME then
                    t.state, t.confirmAt = "confirm", now
                    IRStream(target, 2, t.photoID)
                elseif now - (t.lastData or t.t) > 20 or now - t.t > 240 then
                    IRStop(sender, "Передача прервана")
                end
            elseif now - t.t >= IR_TIME then
                net.Start("ZCPhone_IRData")
                net.WriteData(t.data, IR_BYTES)
                net.Send(target)
                IRStop(sender, "Фото передано")
            end
        else
            t.bad = t.bad + 1
            if t.bad >= 3 then IRStop(sender, "Связь потеряна") end
        end
    end
end)

local function IRCleanup(ply)
    local sender = ir[ply] and ply or irOf[ply]
    if sender then IRStop(sender, "Связь потеряна") end
end
hook.Add("PlayerDeath", "ZCPhone_IRDeath", IRCleanup)
hook.Add("PlayerDisconnected", "ZCPhone_IRQuit", IRCleanup)

local cvIED = CreateConVar("zcphone_ied", "1", FCVAR_ARCHIVE, "Allow dialing 0000 to detonate a planted weapon_traitor_ied (1/0)")

local function Detonate(ply)
	if not cvIED:GetBool() then return Notice(ply, "Номер не обслуживается") end
	if not HasSignal(ply) then return Notice(ply, "Нет сети") end
	local wep = ply:GetWeapon("weapon_traitor_ied")
	if not IsValid(wep) or not wep.Planted or wep.KABOOM or not IsValid(wep.HaveTheBomb) and not wep.PlantedOnSelf then
		return Notice(ply, "Номер не обслуживается")
	end
	if (wep.nextattackhuy or 0) > CurTime() then return Notice(ply, "Подождите...") end
	local bpos = BombPos(wep)
	if not bpos or SignalAt(bpos) < 0.08 then return Notice(ply, "Абонент вне зоны сети") end
	Notice(ply, "Соединение...")
	wep:PrimaryAttack()
end

local cooldown = {}
net.Receive("ZCPhone_Act", function(_, ply)
	local now = CurTime()
	if (cooldown[ply] or 0) > now then return end
	cooldown[ply] = now + 0.1
	if not Alive(ply) or not ply.zcPhoneNumber then return end

	local act = net.ReadUInt(4)
	local wep = ply:GetActiveWeapon()
	if act ~= 7 and (not IsValid(wep) or wep:GetClass() ~= ZCPhone.WeaponClass or not ply:GetNWBool(NW, false)) then return end
	if act == 1 then
		local name, n = net.ReadString(), net.ReadUInt(16)
		AddContact(ply, name, n)
	elseif act == 2 then
		DelContact(ply, net.ReadUInt(16))
	elseif act == 3 then
		StartCall(ply, net.ReadUInt(16))
	elseif act == 4 then
		Answer(ply)
	elseif act == 5 then
		EndCall(ply, "Завершён")
	elseif act == 6 then
		local n, text = net.ReadUInt(16), net.ReadString()
		SendSMS(ply, n, text)
	elseif act == 7 then
		Sync(ply)
	elseif act == 13 then
		local on = net.ReadBool()
		ply.zcPhoneEnc = on and CanEnc(ply) or false
		ply:SetNWBool("ZCPhone_Enc", ply.zcPhoneEnc)
		Notice(ply, ply.zcPhoneEnc and "Шифр включён" or "Шифр выключен")
	elseif act == 12 then
		local n = net.ReadUInt(16)
		if n == 0 then Detonate(ply) else StartCall(ply, n) end
	elseif act == 9 then
		local len = net.ReadUInt(16)
		if len ~= IR_BYTES then return end
		IRStart(ply, net.ReadData(IR_BYTES))
	elseif act == 10 then
		IRAccept(ply)
	elseif act == 11 then
		IRCancel(ply)
	elseif act == 8 then
		local ring, silent = net.ReadString(), net.ReadBool()
		local valid = false
		for _, r in ipairs(ZCPhone.Sounds.rings) do if r.id == ring then valid = true end end
		if not valid then ring = ply.zcPhoneRing or "" end
		ply.zcPhoneRing, ply.zcPhoneSilent = ring, silent
		sql.Query(string.format("INSERT OR REPLACE INTO zcphone_settings (sid, ring, silent) VALUES (%s, %s, %d)", Q(ply:SteamID64() or ply:SteamID()), Q(ring), silent and 1 or 0))
	end
end)

local function Setup(ply)
	ply.zcPhoneNumber = GetNumber(ply)
	ply.zcPhoneContacts = LoadContacts(ply)
	LoadSettings(ply)
	UpdateSignal(ply)
	Sync(ply)
	if ZCPhone.CourseStart then timer.Simple(1, function() ZCPhone.CourseStart(ply) end) end
end

hook.Add("PlayerInitialSpawn", "ZCPhone_Setup", function(ply)
	timer.Simple(3, function() if IsValid(ply) then Setup(ply) end end)
end)

hook.Add("PlayerDisconnected", "ZCPhone_Quit", function(ply)
	EndCall(ply, "Абонент отключился")
	cooldown[ply] = nil
end)

hook.Add("PlayerDeath", "ZCPhone_Death", function(ply)
	EndCall(ply, "Абонент недоступен")
	ply:SetNWBool(NW, false)
end)

hook.Add("PlayerSpawn", "ZCPhone_Spawn", function(ply) ply:SetNWBool(NW, false) end)

local function PhoneVoice(listener, talker)
	if ZCPhone.ScannerHears and ZCPhone.ScannerHears(listener, talker) then return true, false end
	local c = calls[talker]
	if c and c.state == "active" and c.peer == listener then
		if c.muted then return false end
		return true, false
	end
end

-- Z-City calls this extension from RealisticVoice; do not race its base hook.
hook.Remove("PlayerCanHearPlayersVoice", "ZCPhone_Voice")
hook.Add("HG_PlayerCanHearPlayersVoice", "ZCPhone_Voice", PhoneVoice)

timer.Create("ZCPhone_Ring", 0.5, 0, function()
	local now = CurTime()
	for ply, c in pairs(calls) do
		if not IsValid(ply) then
			calls[ply] = nil
		elseif c.state == "ring" then
			if now - c.t > S.RingTime then
				if c.out then Notice(ply, "Нет ответа") end
				EndCall(ply, c.out and "Нет ответа" or "Пропущен")
			elseif not c.out and not ply.zcPhoneSilent and now - c.last >= (c.interval or 0) then
				local r = ZCPhone.RingByID(ply.zcPhoneRing)
				local path = r and r.path or S.RingSound
				local dur = SoundDuration(path) or 0
				local known = dur > 0
				if not known then dur = S.RingFallbackLength or 6 end -- .ogg / VBR .mp3 report 0
				c.interval = math.max(S.RingInterval, dur + 0.8)
				c.last = now
				-- A known-length sound has finished by now; stopping it first only races with the new one.
				-- An unknown length may still be playing: stop it so two copies never overlap.
				if not known then StopRing(ply) end
				c.path = path
				ply:EmitSound(path, 70, 100, 1)
			end
		elseif c.state == "active" then
			if not Alive(c.peer) or not Alive(ply) then
				EndCall(ply, "Связь потеряна")
			elseif not HasSignal(ply) or not HasSignal(c.peer) then
				c.lost = c.lost or now
				c.muted = true
				if now - c.lost > 2 then EndCall(ply, "Нет сети") end
			else
				c.lost = nil
				local m = math.min(ply.zcPhoneSig or 1, c.peer.zcPhoneSig or 1)
				c.muted = m < 0.4 and math.random() > m * 2.2
			end
		end
	end
end)

local function SetOut(ply, state)
	if ply:GetNWBool(NW, false) == state then return end
	ply:SetNWBool(NW, state)
	ply:EmitSound(state and "physics/plastic/plastic_box_impact_soft2.wav" or "physics/plastic/plastic_box_impact_soft4.wav", 50, 130, 0.4)
end

concommand.Add("zcphone", function(ply)
	if not Alive(ply) then return end
	local cls = ZCPhone.WeaponClass
	local active = ply:GetActiveWeapon()
	if IsValid(active) and active:GetClass() == cls then
		local prev = ply.zcPhonePrev
		if prev and prev ~= cls and ply:HasWeapon(prev) then
			ply:SelectWeapon(prev)
		else
			SetOut(ply, not ply:GetNWBool(NW, false))
		end
		return
	end
	if IsValid(active) then ply.zcPhonePrev = active:GetClass() end
	if not ply:HasWeapon(cls) then ply:Give(cls) end
	ply:SelectWeapon(cls)
end)

concommand.Add("zcphone_setnumber", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	local target = IsValid(ply) and ply or nil
	local n = tonumber(args[2] or args[1])
	local name = args[2] and args[1]
	if name then
		for _, p in ipairs(player.GetAll()) do
			if string.find(string.lower(p:Nick()), string.lower(name), 1, true) then target = p break end
		end
	end
	if not IsValid(target) or not n or n ~= math.floor(n) or n < 10 ^ (S.NumberDigits - 1) or n > math.min(65535, 10 ^ S.NumberDigits - 1) or NumberExists(n) then return print("[ZCPhone] zcphone_setnumber <ник> <номер>") end
	EndCall(target, "Номер изменён")
	sql.Query("UPDATE zcphone_numbers SET num = " .. math.floor(n) .. " WHERE sid = " .. Q(target:SteamID64() or target:SteamID()))
	Setup(target)
end)

hook.Add("PlayerSay", "ZCPhone_ChatCmd", function(ply, text)
	if string.lower(text) == "!phone" or string.lower(text) == "!телефон" then
		ply:ConCommand("zcphone")
		return ""
	end
end)


local cvAuto = CreateConVar("zcphone_autogive", "1", FCVAR_ARCHIVE, "Give weapon_zc_phone to players on spawn (1/0)")

local function AutoGive(ply)
	if not cvAuto:GetBool() or not IsValid(ply) or not ply:Alive() then return end
	if ply:HasWeapon(ZCPhone.WeaponClass) then return end
	local active = ply:GetActiveWeapon()
	local prev = IsValid(active) and active:GetClass()
	ply:Give(ZCPhone.WeaponClass, true)
	if prev and ply:HasWeapon(prev) then ply:SelectWeapon(prev) end
end

hook.Add("PlayerSpawn", "ZCPhone_AutoGive", function(ply)
	timer.Simple(1.5, function() AutoGive(ply) end)
end)

hook.Add("RP_RoleLoadout", "ZCPhone_AutoGiveRP", function(ply)
	timer.Simple(0.5, function() AutoGive(ply) end)
end)


-- Раз в 15 с пересчитываем служебные контакты (например, список своей стороны у связиста-сержанта).
timer.Create("ZCPhone_AutoContacts", 15, 0, function()
	for _, p in ipairs(player.GetAll()) do
		if p.zcPhoneNumber then
			local list = LoadContacts(p)
			local sig = {}
			for _, c in ipairs(list) do
				if c.auto then sig[#sig + 1] = c.num end
			end
			sig = table.concat(sig, ",")
			if sig ~= p.zcPhoneAutoSig then
				p.zcPhoneAutoSig = sig
				p.zcPhoneContacts = list
				Sync(p)
			end
		end
	end
end)

timer.Create("ZCPhone_EncState", 1, 0, function()
	for _, p in ipairs(player.GetAll()) do
		local can = CanEnc(p)
		if not can and p.zcPhoneEnc then p.zcPhoneEnc = false end
		p:SetNWBool("ZCPhone_CanEnc", can)
		p:SetNWBool("ZCPhone_Enc", p.zcPhoneEnc or false)
		local c = calls[p]
		p:SetNWBool("ZCPhone_EncCall", c ~= nil and c.enc or false)
	end
end)

ZCPhone.Calls = calls
ZCPhone.HasSignal = HasSignal
ZCPhone.SignalAt = SignalAt
ZCPhone.Notice = Notice
ZCPhone.Evt = Evt
ZCPhone.LoadMessagesFor = LoadMessages
ZCPhone.SyncPlayer = Sync
