-- 1 MP colour camera. New photos are real JPEG files in the player's DATA;
-- the old 64x48 four-colour .txt photos and their IR exchange still work.
ZCPhone = ZCPhone or {}
local ui, st, P = ZCPhone.UI, ZCPhone.State, ZCPhone.Photo
local PHOTO_DIR = "zc_phone/photos"
local OLD_W, OLD_H = 64, 48
local PREVIEW_W, PREVIEW_H, PREVIEW_TEX = 256, 192, 256
local W_PHOTO, H_PHOTO = P.Width, P.Height
local SHUTTER, FPS = 0.7, 6
local PAL = { Color(28, 40, 22), Color(72, 98, 56), Color(116, 146, 88), Color(166, 196, 130) }

-- The scene is only rendered in full resolution when a picture is taken.
-- Power-of-two targets are reused; the capture crops the 1152x864 viewport.
local rtPreview = GetRenderTarget("zcphone_colour_preview_v2", PREVIEW_TEX, PREVIEW_TEX)
local rtShot = GetRenderTargetEx("zcphone_colour_photo_v2", 2048, 1024, RT_SIZE_LITERAL, MATERIAL_RT_DEPTH_SEPARATE, bit.bor(2, 256), 0, IMAGE_FORMAT_BGRA8888)
local VIDEO_W, VIDEO_H = 384, 288
local rtVideo = GetRenderTargetEx("zcphone_button_video_v1", 512, 512, RT_SIZE_LITERAL, MATERIAL_RT_DEPTH_SEPARATE, bit.bor(2, 256), 0, IMAGE_FORMAT_BGRA8888)
local rtLegacy = GetRenderTarget("zcphone_legacy_gallery_v2", 64, 64)
local function RTMat(name, rt, point)
    return CreateMaterial(name, "UnlitGeneric", {
        ["$basetexture"] = rt:GetName(), ["$pointsample"] = point and 1 or 0,
        ["$nolod"] = 1, ["$vertexcolor"] = 1, ["$vertexalpha"] = 0,
    })
end
local matPreview = RTMat("zcphone_colour_preview_mat_v2", rtPreview, false)
local matVideo = RTMat("zcphone_button_video_mat_v1", rtVideo, false)
local matLegacy = RTMat("zcphone_legacy_gallery_mat_v2", rtLegacy, true)
local photos, photoPix, photoMaterial, photoIsLegacy = {}, nil, nil, false
local nextFrame, nextVideoFrame, snapAt, flashUntil, lastScreen = 0, 0, nil, nil, nil
local lastOverlayFrame = -1
ZCPhone.VideoMode = false
local deleteName, deleteUntil, rendering = nil, 0, false

local function PrepareDirs()
    file.CreateDir("zc_phone")
    file.CreateDir(PHOTO_DIR)
end

local function RefreshList()
    PrepareDirs()
    local list = {}
    for _, ext in ipairs({"jpg", "txt"}) do
        local files = file.Find(PHOTO_DIR .. "/*." .. ext, "DATA", "nameasc") or {}
        for _, name in ipairs(files) do
            if name:match("^[%w_%-%.]+$") then list[#list + 1] = name end
        end
    end
    -- Only recordings produced by this phone, never arbitrary files or paths.
    local videos = file.Find("videos/zcphone_*.webm", "MOD", "nameasc") or {}
    for _, name in ipairs(videos) do
        if ZCPhone.IsGalleryVideoName and ZCPhone.IsGalleryVideoName(name) then list[#list + 1] = name end
    end
    local function timestamp(name)
        return tonumber(name:match("^zcphone_(%d+)_") or name:match("^(%d%d%d%d%d%d%d%d%d%d)")) or 0
    end
    table.sort(list, function(a, b)
        local ta,tb=timestamp(a),timestamp(b)
        if ta~=tb then return ta>tb end
        return a>b
    end)
    photos = list
end

local function NewPath(ext)
    PrepareDirs()
    local stamp = os.time()
    local first = math.random(0, 999)
    for i = 0, 999 do
        local name = string.format("%s/%d%03d.%s", PHOTO_DIR, stamp, (first + i) % 1000, ext)
        if not file.Exists(name, "DATA") then return name end
    end
end

function ZCPhone.SaveJPEG(data)
    if not P.ValidJPEG(data) then return false, "Некорректный JPEG" end
    local path = NewPath("jpg")
    if not path then return false, "Нет свободного имени" end
    if not file.Write(path, data) or file.Read(path, "DATA") ~= data then
        -- This path was just reserved by us; don't leave a partial JPEG behind.
        if file.Exists(path, "DATA") then file.Delete(path) end
        return false, "Ошибка записи файла"
    end
    RefreshList()
    return true, path
end

local function SaveLegacy(pix)
    local path = NewPath("txt")
    if not path then return false end
    local parts = {}
    for i = 1, OLD_W * OLD_H do parts[i] = tostring(pix[i] or 0) end
    local content = table.concat(parts)
    if not file.Write(path, content) or file.Read(path, "DATA") ~= content then return false end
    RefreshList()
    return true
end

local function BlitLegacy(pix)
    render.PushRenderTarget(rtLegacy)
    render.Clear(PAL[1].r, PAL[1].g, PAL[1].b, 255, true, true)
    cam.Start2D()
    local ok, err = pcall(function()
        for y = 0, OLD_H - 1 do
            for x = 0, OLD_W - 1 do
                local c = PAL[(pix[y * OLD_W + x + 1] or 0) + 1]
                surface.SetDrawColor(c.r, c.g, c.b, 255)
                surface.DrawRect(x, y, 1, 1)
            end
        end
    end)
    cam.End2D()
    render.PopRenderTarget()
    if not ok then print("[ZCPhone] Ошибка старого фото: " .. tostring(err)) end
end

local legacyDirty = false
local function LoadPhoto(idx)
    if ZCPhone.StopGalleryVideo then ZCPhone.StopGalleryVideo() end
    photoPix, photoMaterial, photoIsLegacy, legacyDirty = nil, nil, false, false
    local name = photos[idx]
    if not name then return end
    local path = PHOTO_DIR .. "/" .. name
    if name:sub(-4) == ".txt" then
        local data = file.Read(path, "DATA")
        if not data or #data ~= OLD_W * OLD_H or data:find("[^0-3]") then return end
        local pix = {}
        for i = 1, #data do pix[i] = tonumber(data:sub(i, i)) end
        photoPix, photoIsLegacy, legacyDirty = pix, true, true
    elseif name:sub(-4) == ".jpg" then
        -- Cache once per gallery selection, never construct a material per frame.
        local mat = Material("data/" .. path, "smooth")
        if mat and not mat:IsError() then photoMaterial = mat end
    end
end

-- The transform is published by the actual hand/model draw in the MAIN view.
-- DrawOverlay runs after that draw, avoiding the previous PreRender frame lag.
-- No fallback to the player's eyes: that would silently film the wrong view.
function ZCPhone.ResolveLensLocal(c, mins, maxs)
    if not c or not c.pos or not c.ang then return nil end
    local localPos, localAng = c.pos, c.ang
    -- Old 1 MP config has (0,0,0) as an unconfigured lens, inside the phone.
    -- The button/screen surface of the supplied model faces local -Y, so its
    -- reverse face is +Y. A manually tuned Camera overrides this estimate.
    local unconfigured = c.pos.x == 0 and c.pos.y == 0 and c.pos.z == 0
        and c.ang.p == 0 and c.ang.y == 0 and c.ang.r == 0
    if unconfigured and (not mins or not maxs) then return nil end
    if unconfigured then
        localPos = Vector((mins.x+maxs.x)*0.5, maxs.y+0.15,
            maxs.z-(maxs.z-mins.z)*0.15)
        localAng = Angle(0,90,0)
    end
    return localPos, localAng
end

local function GetView()
    local ply = LocalPlayer()
    local w = IsValid(ply) and ply.zcPhoneWorld
    local c = ZCPhone.Config.Camera
    if not w or not c or not w.frame or w.frame < FrameNumber() - 1 then
        ZCPhone.CamWorld = nil
        return nil, false
    end
    local scale = math.max(0.01, ZCPhone.Config.Scale)
    local localPos, localAng = ZCPhone.ResolveLensLocal(c, w.mins, w.maxs)
    if not localPos then ZCPhone.CamWorld = nil return nil, false end
    local pos, ang = LocalToWorld(localPos * scale, localAng, w.pos, w.ang)
    ZCPhone.CamWorld = { pos = pos, ang = ang, frame = w.frame }
    return {origin = pos, angles = ang, fov = c.fov}, true
end
ZCPhone.GetButtonCameraView = GetView

local function RenderSceneTo(target, width, height, capture, videoFrame)
    local view, phoneView = GetView()
    if not view then return false, "Нет вида камеры" end
    if target:Width() < width or target:Height() < height then return false, "Размер render target меньше размера фото" end
    render.PushRenderTarget(target, 0, 0, width, height)
    rendering, ZCPhone.RenderingCamera = true, true
    -- Z-City's RenderScene hook can replace nested views with the player's
    -- eyes. Suspend only that named hook during our sub-render; always restore.
    local hooks = hook.GetTable and hook.GetTable()
    local sceneHook = hooks and hooks.RenderScene and hooks.RenderScene.jopa
    if isfunction(sceneHook) then hook.Remove("RenderScene", "jopa") end
    local ok, result = pcall(function()
        render.Clear(0, 0, 0, 255, true, true)
        render.RenderView({
            origin = view.origin, angles = view.angles, fov = view.fov,
            x = 0, y = 0, w = width, h = height, aspectratio = width / height,
            drawviewmodel = false, drawhud = false, drawmonitors = false, dopostprocess = false, znear = 1,
        })
        -- RenderView may change the viewport; restore the capture dimensions
        -- before reading pixels. PopRenderTarget restores the previous viewport.
        render.SetViewPort(0, 0, width, height)
        if videoFrame and ZCPhone.VideoFrame then ZCPhone.VideoFrame(width, height) end
        if capture then
            return render.Capture({format = "jpeg", quality = 90, x = 0, y = 0, w = width, h = height})
        end
        return true
    end)
    if isfunction(sceneHook) then
        local current = hook.GetTable and hook.GetTable()
        if not current or not current.RenderScene or not current.RenderScene.jopa then hook.Add("RenderScene", "jopa", sceneHook) end
    end
    render.PopRenderTarget()
    rendering, ZCPhone.RenderingCamera = false, false
    if not ok then return false, tostring(result) end
    if capture and not P.ValidJPEG(result) then return false, "Не удалось получить JPEG 1 МП" end
    ZCPhone.CamStatus = phoneView and "камера на телефоне" or "вид: глаза"
    return true, result
end

hook.Add("DrawOverlay", "ZCPhone_CamProcess", function()
    if rendering or not ZCPhone.IsOut() then return end
    if lastOverlayFrame == FrameNumber() then return end
    lastOverlayFrame = FrameNumber()
    if ui.screen == "camera" then
        if snapAt and CurTime() >= snapAt then
            snapAt = nil
            local ok, data = RenderSceneTo(rtShot, W_PHOTO, H_PHOTO, true)
            if ok then
                local saved, result = ZCPhone.SaveJPEG(data)
                if saved then
                    flashUntil = CurTime() + 0.2
                    ZCPhone.Notice("Фото сохранено на компьютер", 2)
                    net.Start("ZCPhone_Shutter") net.SendToServer()
                else
                    ZCPhone.Notice("Ошибка сохранения фото", 3)
                    print("[ZCPhone] " .. tostring(result))
                end
            else
                ZCPhone.Notice("Камера телефона недоступна: фото не сделано", 3)
                print("[ZCPhone] " .. tostring(data))
            end
        end
        local recording = ZCPhone.IsVideoRecording and ZCPhone.IsVideoRecording()
        if recording and RealTime() >= nextVideoFrame then
            nextVideoFrame = RealTime() + 1/15
            local ok, err = RenderSceneTo(rtVideo, VIDEO_W, VIDEO_H, false, true)
            if not ok and ZCPhone.StopVideo then ZCPhone.StopVideo("Ошибка кадра камеры: " .. tostring(err), true) end
        elseif not recording and CurTime() >= nextFrame then
            nextFrame = CurTime() + 1 / FPS
            local ok, err = RenderSceneTo(rtPreview, PREVIEW_W, PREVIEW_H, false)
            if not ok then ZCPhone.CamStatus = "камера не готова" end
        end
    elseif ui.screen == "gallery" and legacyDirty and photoPix then
        legacyDirty = false
        BlitLegacy(photoPix)
    end
end)

hook.Add("Think", "ZCPhone_CamThink", function()
    if not ZCPhone.IsOut() then snapAt = nil end
    if ui.screen ~= lastScreen then
        deleteName = nil
        if ui.screen == "gallery" then RefreshList() ui.sel = 1 LoadPhoto(1) end
        if ui.screen ~= "camera" then snapAt = nil end
        lastScreen = ui.screen
    end
end)

function ZCPhone.CameraKey(key)
    if key == "2" and not (ZCPhone.IsVideoRecording and ZCPhone.IsVideoRecording()) then
        snapAt = nil
        ZCPhone.VideoMode = not ZCPhone.VideoMode
        ZCPhone.Notice(ZCPhone.VideoMode and "Режим видео" or "Режим фото", 2)
    elseif key == "ok" and ZCPhone.VideoMode then
        if ZCPhone.RequestVideo then ZCPhone.RequestVideo() end
    elseif key == "ok" and not snapAt then snapAt = CurTime() + SHUTTER end
end

function ZCPhone.GallerySelectedName() return photos[ui.sel] end

function ZCPhone.GalleryKey(key)
    if #photos == 0 then return end
    if key == "4" then
        ui.sel = (ui.sel - 2) % #photos + 1
        deleteName = nil
        LoadPhoto(ui.sel)
    elseif key == "6" then
        ui.sel = ui.sel % #photos + 1
        deleteName = nil
        LoadPhoto(ui.sel)
    elseif key == "ok" then
        if st.call.state ~= "idle" then return ZCPhone.Notice("Идёт вызов") end
        local selected = photos[ui.sel]
        if ZCPhone.IsGalleryVideoName and ZCPhone.IsGalleryVideoName(selected) then
            if ZCPhone.ToggleGalleryVideo then ZCPhone.ToggleGalleryVideo(selected) end
            return
        end
        if photoIsLegacy and photoPix then
            local bytes = {}
            for i = 1, OLD_W * OLD_H, 4 do
                bytes[#bytes + 1] = string.char(photoPix[i] + photoPix[i + 1] * 4 + photoPix[i + 2] * 16 + photoPix[i + 3] * 64)
            end
            local data = table.concat(bytes)
            net.Start("ZCPhone_Act") net.WriteUInt(9, 4) net.WriteUInt(#data, 16) net.WriteData(data, #data) net.SendToServer()
        else
            local name = photos[ui.sel]
            if not name or name:sub(-4) ~= ".jpg" then return ZCPhone.Notice("Не удалось открыть фото") end
            local data = file.Read(PHOTO_DIR .. "/" .. name, "DATA")
            if not P.ValidJPEG(data) then return ZCPhone.Notice("Некорректный файл фото") end
            if isfunction(ZCPhone.BeginJPEGTransfer) then ZCPhone.BeginJPEGTransfer(data) end
        end
    elseif key == "8" then
        local name = photos[ui.sel]
        if not name then return end
        if ZCPhone.IsGalleryVideoName and ZCPhone.IsGalleryVideoName(name) then
            return ZCPhone.Notice("Удаляй видео из папки garrysmod/videos", 4)
        end
        if deleteName ~= name or CurTime() > deleteUntil then
            deleteName, deleteUntil = name, CurTime() + 5
            return ZCPhone.Notice("Нажми 8 ещё раз: удалить файл", 3)
        end
        file.Delete(PHOTO_DIR .. "/" .. name)
        deleteName = nil
        RefreshList()
        ui.sel = math.Clamp(ui.sel, 1, math.max(1, #photos))
        LoadPhoto(ui.sel)
        ZCPhone.Notice("Файл удалён", 1)
    end
end

local FG, BG = Color(28, 40, 22), Color(150, 182, 118)
local function Header(W, left, right)
    surface.SetDrawColor(FG) surface.DrawRect(0, 0, W, 18)
    draw.SimpleText(left, "ZCPhone_M", 4, 2, BG)
    if right then draw.SimpleText(right, "ZCPhone_M", W - 4, 2, BG, TEXT_ALIGN_RIGHT) end
end

function ZCPhone.DrawCamera(W, H)
    -- Never draw the live preview texture into itself during the scene pass.
    if ZCPhone.RenderingCamera then return end
    local recording = ZCPhone.IsVideoRecording and ZCPhone.IsVideoRecording()
    Header(W, "Камера", recording and "REC" or (ZCPhone.VideoMode and "ВИДЕО" or "1 МП"))
    local w, h = W - 8, (W - 8) * 3 / 4
    if GetView() then
        surface.SetMaterial(recording and matVideo or matPreview) surface.SetDrawColor(255, 255, 255, 255)
        if recording then surface.DrawTexturedRectUV(4, 22, w, h, 0, 0, VIDEO_W/512, VIDEO_H/512)
        else surface.DrawTexturedRectUV(4, 22, w, h, 0, 0, 1, PREVIEW_H / PREVIEW_TEX) end
    else
        draw.SimpleText("Камера не готова", "ZCPhone_S", W/2, 22+h/2, FG, TEXT_ALIGN_CENTER)
    end
    surface.SetDrawColor(FG) surface.DrawOutlinedRect(3, 21, w + 2, h + 2)
    local cx, cy = 4 + w / 2, 22 + h / 2
    surface.DrawLine(cx - 6, cy, cx + 6, cy) surface.DrawLine(cx, cy - 6, cx, cy + 6)
    if ZCPhone.CamStatus then draw.SimpleText(ZCPhone.CamStatus, "ZCPhone_S", W / 2, H - 12, FG, TEXT_ALIGN_CENTER) end
    local hint = recording and "OK - стоп" or (ZCPhone.VideoMode and "OK - запись" or (snapAt and "Снимаю..." or "OK - фото"))
    draw.SimpleText(hint, "ZCPhone_M", W / 2, 26 + h, FG, TEXT_ALIGN_CENTER)
    draw.SimpleText("2 - фото/видео", "ZCPhone_S", W / 2, 40 + h, FG, TEXT_ALIGN_CENTER)
    if flashUntil and CurTime() < flashUntil then surface.SetDrawColor(235, 245, 220, 255) surface.DrawRect(0, 0, W, H) end
end

function ZCPhone.DrawGallery(W, H)
    local name=photos[ui.sel]
    local isVideo=ZCPhone.IsGalleryVideoName and ZCPhone.IsGalleryVideoName(name)
    Header(W, isVideo and "Видео" or "Галерея", #photos > 0 and (ui.sel .. "/" .. #photos) or nil)
    if #photos == 0 then draw.SimpleText("Нет фото и видео", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) return end
    local w, h = W - 8, (W - 8) * 3 / 4
    if isVideo then
        local status=ZCPhone.GalleryVideoState and ZCPhone.GalleryVideoState(name) or "idle"
        local mat,u,v
        if ZCPhone.GalleryVideoMaterial then mat,u,v=ZCPhone.GalleryVideoMaterial(name) end
        if mat and (status=="playing" or status=="paused" or status=="ended") then
            surface.SetMaterial(mat);surface.SetDrawColor(255,255,255,255);surface.DrawTexturedRectUV(4,22,w,h,0,0,u or 1,v or 1)
        else
            local labels={idle="Видео",loading="Загрузка...",error="Видео недоступно",blocked="Воспроизведение отклонено"}
            draw.SimpleText(labels[status] or "Видео", "ZCPhone_S", W/2, 22+h/2, FG, TEXT_ALIGN_CENTER)
        end
        surface.SetDrawColor(FG);surface.DrawOutlinedRect(3,21,w+2,h+2)
        local stamp=tonumber(name:match("^zcphone_(%d+)_"))
        if stamp then draw.SimpleText(os.date("%d.%m.%Y %H:%M",stamp),"ZCPhone_S",W/2,26+h,FG,TEXT_ALIGN_CENTER) end
        draw.SimpleText("4/6 лист. OK пуск/пауза", "ZCPhone_S", W/2, H-12, FG, TEXT_ALIGN_CENTER)
        return
    end
    local mat = photoIsLegacy and matLegacy or photoMaterial
    if mat then
        surface.SetMaterial(mat) surface.SetDrawColor(255, 255, 255, 255)
        if photoIsLegacy then surface.DrawTexturedRectUV(4, 22, w, h, 0, 0, 1, OLD_H / 64)
        else surface.DrawTexturedRect(4, 22, w, h) end
    else
        draw.SimpleText("Не удалось открыть фото", "ZCPhone_S", W / 2, 22 + h / 2, FG, TEXT_ALIGN_CENTER)
    end
    surface.SetDrawColor(FG) surface.DrawOutlinedRect(3, 21, w + 2, h + 2)
    local ts = tonumber(string.sub(string.StripExtension(name or ""), 1, -4))
    if ts then draw.SimpleText(os.date("%d.%m.%Y %H:%M", ts), "ZCPhone_S", W / 2, 26 + h, FG, TEXT_ALIGN_CENTER) end
    draw.SimpleText("4/6 лист. 8 удал. OK ИК", "ZCPhone_S", W / 2, H - 12, FG, TEXT_ALIGN_CENTER)
end

net.Receive("ZCPhone_IRData", function()
    local data = net.ReadData(768)
    if not data or #data ~= 768 then return end
    local pix, i = {}, 1
    for n = 1, 768 do
        local b = string.byte(data, n)
        for k = 0, 3 do pix[i] = bit.band(bit.rshift(b, k * 2), 3) i = i + 1 end
    end
    if not SaveLegacy(pix) then return ZCPhone.Notice("Не удалось сохранить фото", 3) end
    ZCPhone.Notice("Получено старое фото по ИК", 3)
    local ply = LocalPlayer()
    if IsValid(ply) then ply:EmitSound("buttons/blip1.wav", 55, 120, 0.6) end
end)

function ZCPhone.DrawIR(W, H)
    local ir = st.ir
    Header(W, "ИК-порт")
    local function C(text, font, y) draw.SimpleText(text, font, W / 2, y, FG, TEXT_ALIGN_CENTER) end
    if ir.state == "wait" then
        C("Ожидание...", "ZCPhone_L", H / 2 - 30) C("Ждём подтверждения", "ZCPhone_M", H / 2 - 4) C("Красная - отмена", "ZCPhone_S", H - 14)
    elseif ir.state == "offer" then
        C("Фото по ИК от", "ZCPhone_M", H / 2 - 40) C(ir.label, "ZCPhone_L", H / 2 - 22)
        C("Принять?", "ZCPhone_L", H / 2 + 6) C("Зелёная - да   Красная - нет", "ZCPhone_S", H - 14)
    else
        local p = ir.progress or math.Clamp((CurTime() - ir.t0) / math.max(0.1, ir.dur or 8), 0, 1)
        p = math.Clamp(p, 0, 1)
        C("Передача", "ZCPhone_L", H / 2 - 40)
        surface.SetDrawColor(FG) surface.DrawOutlinedRect(10, H / 2 - 10, W - 20, 16)
        surface.DrawRect(12, H / 2 - 8, (W - 24) * p, 12)
        C(math.floor(p * 100) .. "%", "ZCPhone_M", H / 2 + 12)
        C("Держите телефоны друг напротив друга", "ZCPhone_S", H - 26)
        C("Красная - отмена", "ZCPhone_S", H - 14)
    end
end
