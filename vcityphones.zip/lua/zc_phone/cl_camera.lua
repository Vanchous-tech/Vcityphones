ZCPhone = ZCPhone or {}
local ui, st = ZCPhone.UI, ZCPhone.State

local SW, SH = 64, 48
local PHOTO_DIR = "zc_phone/photos"
local MAX_PHOTOS = 24
local FPS = 6
local SHUTTER = 0.7

local PAL = { Color(28, 40, 22), Color(72, 98, 56), Color(116, 146, 88), Color(166, 196, 130) }
local BAYER = { 0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5 }

local rtScene = GetRenderTarget("zcphone_cam_scene", SW, SH)
local rtDisp = GetRenderTarget("zcphone_cam_disp", SW, SH)
local rtPhoto = GetRenderTarget("zcphone_cam_photo", SW, SH)

local function RTMat(name, rt)
	return CreateMaterial(name, "UnlitGeneric", {
		["$basetexture"] = rt:GetName(),
		["$pointsample"] = 1,
		["$nolod"] = 1,
		["$vertexcolor"] = 1,
		["$vertexalpha"] = 0,
	})
end
local matDisp = RTMat("zcphone_cam_disp_mat", rtDisp)
local matPhoto = RTMat("zcphone_cam_photo_mat", rtPhoto)

local camView
local latest
local nextFrame = 0
local snapAt, flashUntil
local photos, photoPix, photoDirty = {}, nil, false
local lastScreen

local function Blit(rt, pix)
	render.PushRenderTarget(rt)
	render.Clear(PAL[1].r, PAL[1].g, PAL[1].b, 255, true, true)
	cam.Start2D()
	local i = 1
	for y = 0, SH - 1 do
		for x = 0, SW - 1 do
			local c = PAL[pix[i] + 1]
			surface.SetDrawColor(c.r, c.g, c.b, 255)
			surface.DrawRect(x, y, 1, 1)
			i = i + 1
		end
	end
	cam.End2D()
	render.PopRenderTarget()
end

local function GetView()
	local ply = LocalPlayer()
	local w = IsValid(ply) and ply.zcPhoneWorld
	local c = ZCPhone.Config.Camera
	if w and c and w.frame and w.frame >= FrameNumber() - 5 then
		local scale = math.max(0.01, ZCPhone.Config.Scale)
		local pos, ang = LocalToWorld(c.pos * scale, c.ang, w.pos, w.ang)
		ZCPhone.CamWorld = { pos = pos, ang = ang }
		return { origin = pos, angles = ang, fov = c.fov }, true
	end
	ZCPhone.CamWorld = nil
	return camView
end

local function Shoot()
	local view = GetView()
	if not view then error("нет вида") end
	render.PushRenderTarget(rtScene)
	render.Clear(0, 0, 0, 255, true, true)
	render.RenderView({
		origin = view.origin, angles = view.angles, fov = view.fov,
		x = 0, y = 0, w = SW, h = SH, aspectratio = SW / SH,
		drawviewmodel = false, drawhud = false, drawmonitors = false, dopostprocess = false,
	})
	render.CapturePixels()
	render.PopRenderTarget()

	local pix, i = {}, 1
	for y = 0, SH - 1 do
		for x = 0, SW - 1 do
			local r, g, b = render.ReadPixel(x, y)
			local lum = (r * 0.3 + g * 0.59 + b * 0.11) / 255
			lum = (lum - 0.5) * 1.5 + 0.5 + (math.random() - 0.5) * 0.18
			if math.random() < 0.012 then lum = math.random() end
			local d = (BAYER[(y % 4) * 4 + (x % 4) + 1] / 16 - 0.5) * 0.45
			local v = math.floor(math.Clamp(lum * 3 + d + 0.5, 0, 3))
			pix[i] = v
			i = i + 1
		end
	end
	return pix
end

local function RefreshList()
	local files = file.Find(PHOTO_DIR .. "/*.txt", "DATA", "nameasc")
	photos = {}
	for i = #files, 1, -1 do photos[#photos + 1] = files[i] end
end

local function LoadPhoto(idx)
	local name = photos[idx]
	photoPix = nil
	if not name then return end
	local data = file.Read(PHOTO_DIR .. "/" .. name, "DATA")
	if not data or #data < SW * SH then return end
	photoPix = {}
	for i = 1, SW * SH do photoPix[i] = tonumber(string.sub(data, i, i)) or 0 end
	photoDirty = true
end

local function SavePhoto(pix)
	file.CreateDir("zc_phone")
	file.CreateDir(PHOTO_DIR)
	local parts = {}
	for i = 1, #pix do parts[i] = pix[i] end
	file.Write(string.format("%s/%d%03d.txt", PHOTO_DIR, os.time(), math.random(0, 999)), table.concat(parts))
	RefreshList()
	while #photos > MAX_PHOTOS do
		file.Delete(PHOTO_DIR .. "/" .. table.remove(photos))
	end
end

hook.Add("PreDrawOpaqueRenderables", "ZCPhone_CamView", function(depth, sky)
	if depth or sky or ui.screen ~= "camera" then return end
	local v = render.GetViewSetup()
	if v and v.origin then camView = { origin = Vector(v.origin), angles = Angle(v.angles), fov = v.fov or 90 } end
end)

hook.Add("PreRender", "ZCPhone_CamProcess", function()
	if not ZCPhone.IsOut() then return end
	if ui.screen == "camera" and CurTime() >= nextFrame then
		nextFrame = CurTime() + 1 / FPS
		if not camView then
			local ply = LocalPlayer()
			camView = { origin = ply:EyePos(), angles = ply:EyeAngles(), fov = 90 }
			ZCPhone.CamStatus = "вид: запасной"
		else
			ZCPhone.CamStatus = ZCPhone.CamWorld and "камера на телефоне" or "вид: глаза"
		end
		local ok, res = pcall(Shoot)
		if ok then
			latest = res
			local ok2, err2 = pcall(Blit, rtDisp, latest)
			if not ok2 then ZCPhone.CamStatus = "blit: " .. tostring(err2) end
		else
			ZCPhone.CamStatus = "ошибка: " .. tostring(res)
			if not ZCPhone.CamErrPrinted then ZCPhone.CamErrPrinted = true print("[ZCPhone] camera error: " .. tostring(res)) end
		end
	elseif ui.screen == "gallery" and photoDirty and photoPix then
		photoDirty = false
		Blit(rtPhoto, photoPix)
	end
end)

hook.Add("Think", "ZCPhone_CamThink", function()
	if ui.screen ~= lastScreen then
		if ui.screen == "gallery" then RefreshList() LoadPhoto(1) end
		if ui.screen == "camera" then snapAt = nil end
		lastScreen = ui.screen
	end
	if snapAt and CurTime() >= snapAt then
		snapAt = nil
		if latest then
			SavePhoto(latest)
			flashUntil = CurTime() + 0.2
			ZCPhone.Notice("Сохранено (" .. #photos .. "/" .. MAX_PHOTOS .. ")", 1.2)
			local ply = LocalPlayer()
			if IsValid(ply) then ply:EmitSound("npc/scanner/scanner_photo1.wav", 55, 140, 0.6) end
		end
	end
end)

function ZCPhone.CameraKey(key)
	if key == "ok" and not snapAt then snapAt = CurTime() + SHUTTER end
end

function ZCPhone.GalleryKey(key)
	if #photos == 0 then return end
	if key == "4" then
		ui.sel = (ui.sel - 2) % #photos + 1
		LoadPhoto(ui.sel)
	elseif key == "6" then
		ui.sel = ui.sel % #photos + 1
		LoadPhoto(ui.sel)
	elseif key == "ok" then
		if not photoPix then return end
		if st.call.state ~= "idle" then return ZCPhone.Notice("Идёт вызов") end
		local bytes = {}
		for i = 1, SW * SH, 4 do
			bytes[#bytes + 1] = string.char((photoPix[i] or 0) + (photoPix[i + 1] or 0) * 4 + (photoPix[i + 2] or 0) * 16 + (photoPix[i + 3] or 0) * 64)
		end
		local data = table.concat(bytes)
		net.Start("ZCPhone_Act")
		net.WriteUInt(9, 4)
		net.WriteUInt(#data, 16)
		net.WriteData(data, #data)
		net.SendToServer()
	elseif key == "8" then
		local name = photos[ui.sel]
		if name then file.Delete(PHOTO_DIR .. "/" .. name) end
		RefreshList()
		ui.sel = math.Clamp(ui.sel, 1, math.max(1, #photos))
		LoadPhoto(ui.sel)
		ZCPhone.Notice("Удалено", 1)
	end
end

local FG, BG = Color(28, 40, 22), Color(150, 182, 118)

local function Header(W, left, right)
	surface.SetDrawColor(FG)
	surface.DrawRect(0, 0, W, 18)
	draw.SimpleText(left, "ZCPhone_M", 4, 2, BG)
	if right then draw.SimpleText(right, "ZCPhone_M", W - 4, 2, BG, TEXT_ALIGN_RIGHT) end
end

function ZCPhone.DrawCamera(W, H)
	Header(W, "Камера", "0.003 МП")
	local w = W - 8
	local h = w * SH / SW
	surface.SetMaterial(matDisp)
	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawTexturedRect(4, 22, w, h)
	surface.SetDrawColor(FG)
	surface.DrawOutlinedRect(3, 21, w + 2, h + 2)
	local cx, cy = 4 + w / 2, 22 + h / 2
	surface.DrawLine(cx - 6, cy, cx + 6, cy)
	surface.DrawLine(cx, cy - 6, cx, cy + 6)
	if ZCPhone.CamStatus then
		draw.SimpleText(string.sub(ZCPhone.CamStatus, 1, 34), "ZCPhone_S", W / 2, H - 12, FG, TEXT_ALIGN_CENTER)
	end
	if snapAt then
		draw.SimpleText("Снимаю...", "ZCPhone_L", W / 2, 26 + h, FG, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText("OK - снять", "ZCPhone_M", W / 2, 26 + h, FG, TEXT_ALIGN_CENTER)
	end
	if flashUntil and CurTime() < flashUntil then
		surface.SetDrawColor(235, 245, 220, 255)
		surface.DrawRect(0, 0, W, H)
	end
end

function ZCPhone.DrawGallery(W, H)
	Header(W, "Галерея", #photos > 0 and (ui.sel .. "/" .. #photos) or nil)
	if #photos == 0 then
		draw.SimpleText("Нет фото", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER)
		return
	end
	local w = W - 8
	local h = w * SH / SW
	surface.SetMaterial(matPhoto)
	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawTexturedRect(4, 22, w, h)
	surface.SetDrawColor(FG)
	surface.DrawOutlinedRect(3, 21, w + 2, h + 2)
	local ts = tonumber(string.sub(string.StripExtension(photos[ui.sel] or ""), 1, -4))
	if ts then draw.SimpleText(os.date("%d.%m.%Y %H:%M", ts), "ZCPhone_S", W / 2, 26 + h, FG, TEXT_ALIGN_CENTER) end
	draw.SimpleText("4/6 лист. 8 удал. OK ИК", "ZCPhone_S", W / 2, H - 12, FG, TEXT_ALIGN_CENTER)
end


net.Receive("ZCPhone_IRData", function()
	local data = net.ReadData(768)
	if not data or #data ~= 768 then return end
	local pix, i = {}, 1
	for n = 1, 768 do
		local b = string.byte(data, n)
		for k = 0, 3 do
			pix[i] = bit.band(bit.rshift(b, k * 2), 3)
			i = i + 1
		end
	end
	SavePhoto(pix)
	ZCPhone.Notice("Получено фото по ИК", 3)
	local ply = LocalPlayer()
	if IsValid(ply) then ply:EmitSound("buttons/blip1.wav", 55, 120, 0.6) end
end)

function ZCPhone.DrawIR(W, H)
	local ir = st.ir
	Header(W, "ИК-порт")
	local function C(text, font, y) draw.SimpleText(text, font, W / 2, y, FG, TEXT_ALIGN_CENTER) end
	if ir.state == "wait" then
		C("Ожидание...", "ZCPhone_L", H / 2 - 30)
		C("Ждём подтверждения", "ZCPhone_M", H / 2 - 4)
		C("Красная - отмена", "ZCPhone_S", H - 14)
	elseif ir.state == "offer" then
		C("Фото по ИК от", "ZCPhone_M", H / 2 - 40)
		C(ir.label, "ZCPhone_L", H / 2 - 22)
		C("Принять?", "ZCPhone_L", H / 2 + 6)
		C("Зелёная - да   Красная - нет", "ZCPhone_S", H - 14)
	else
		local p = math.Clamp((CurTime() - ir.t0) / math.max(0.1, ir.dur), 0, 1)
		C("Передача", "ZCPhone_L", H / 2 - 40)
		surface.SetDrawColor(FG)
		surface.DrawOutlinedRect(10, H / 2 - 10, W - 20, 16)
		surface.DrawRect(12, H / 2 - 8, (W - 24) * p, 12)
		C(math.floor(p * 100) .. "%", "ZCPhone_M", H / 2 + 12)
		C("Держите телефоны друг напротив друга", "ZCPhone_S", H - 26)
		C("Красная - отмена", "ZCPhone_S", H - 14)
	end
end
