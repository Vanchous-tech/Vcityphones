-- Сканер связи: перехват и пеленг. Эмиттер = игрок в звонке или недавно отправивший SMS.
util.AddNetworkString("ZCPhone_Scan")
util.AddNetworkString("ZCPhone_DF")

local S = ZCPhone.Settings
local CLASS = "weapon_zc_scanner"
local SMS_WINDOW = 20

local function Azimuth(from, to)
	local d = to - from
	return (math.deg(math.atan2(-d.y, d.x))) % 360
end

local function Emitting(p)
	if not IsValid(p) or not p:Alive() or not p.zcPhoneNumber then return false end
	local c = ZCPhone.Calls[p]
	if c then return true, "call", c end
	if p.zcPhoneSmsAt and CurTime() - p.zcPhoneSmsAt < SMS_WINDOW then return true, "sms" end
	return false
end

local function Holding(p)
	local w = p:GetActiveWeapon()
	return IsValid(w) and w:GetClass() == CLASS and hook.Run("ZCPhone_CanScan", p) ~= false
end

local function Noise(dist, locked)
	if locked then return math.Rand(-2, 2) end
	local f = math.Clamp(dist / S.ScannerRange, 0, 1)
	return math.Rand(-1, 1) * (4 + f * 14)
end

local function SendFix(owner, pos, az)
	net.Start("ZCPhone_DF")
	net.WriteVector(pos)
	net.WriteFloat(az)
	net.Send(owner)
end

local function Tick()
	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() or not Holding(ply) then
			ply.zcScanLock = nil
			ply.zcScanProg = nil
		else
			local pos = ply:GetPos()
			local eye = ply:EyeAngles().y
			local list = {}
			local best, bestDiff
			for _, p in ipairs(player.GetAll()) do
				if p ~= ply then
					local ok, kind = Emitting(p)
					if ok then
						local dist = pos:Distance(p:GetPos())
						if dist <= S.ScannerRange then
							local az = Azimuth(pos, p:GetPos())
							local lockedNow = ply.zcScanLock and ply.zcScanLock.target == p
							local c0 = ZCPhone.Calls[p]
							local enc = c0 and c0.enc or false
							local entry = { az = (az + Noise(dist, lockedNow)) % 360, kind = kind, dist = math.floor(dist / 50) * 50, locked = lockedNow or false, id = p:EntIndex(), enc = enc }
							if lockedNow and not enc then
								entry.nums = { p.zcPhoneNumber }
								local c = ZCPhone.Calls[p]
								if c and IsValid(c.peer) and c.peer.zcPhoneNumber then entry.nums[2] = c.peer.zcPhoneNumber end
							end
							list[#list + 1] = entry
							-- прицеливание: угол между взглядом (yaw) и пеленгом
							local want = (math.deg(math.atan2(p:GetPos().y - pos.y, p:GetPos().x - pos.x))) % 360
							local diff = math.abs(math.AngleDifference(eye, want))
							if diff < 12 and (not bestDiff or diff < bestDiff) then best, bestDiff = p, diff end
						end
					end
				end
			end
			-- захват
			if ply.zcScanLock and not Emitting(ply.zcScanLock.target) then ply.zcScanLock = nil end
			if best and not (ply.zcScanLock and ply.zcScanLock.target == best) then
				if ply.zcScanProg and ply.zcScanProg.target == best then
					ply.zcScanProg.t = ply.zcScanProg.t + 0.5
					if ply.zcScanProg.t >= S.ScannerLockTime then
						ply.zcScanLock = { target = best }
						ply.zcScanProg = nil
						local c1 = ZCPhone.Calls[best]
						if c1 and c1.enc then
							ZCPhone.Notice(ply, "Захват цели. Канал зашифрован: слышен только пеленг")
						else
							ZCPhone.Notice(ply, "Захват цели. Перехват активен")
						end
						hook.Run("ZCPhone_Intel", ply, "lock", best)
					end
				else
					ply.zcScanProg = { target = best, t = 0 }
				end
			elseif not best then
				ply.zcScanProg = nil
			end
			net.Start("ZCPhone_Scan")
			net.WriteTable(list)
			net.WriteFloat(ply.zcScanProg and (ply.zcScanProg.t / S.ScannerLockTime) or 0)
			net.Send(ply)
			-- пеленги на карту
			for _, e in ipairs(list) do
				SendFix(ply, pos, e.az)
			end
		end
	end
end
timer.Create("ZCPhone_Scanner", 0.5, 0, Tick)

function ZCPhone.ScannerHears(listener, talker)
	local lock = listener.zcScanLock
	if not lock or not IsValid(lock.target) or not Holding(listener) then return false end
	if talker ~= lock.target then
		local c = ZCPhone.Calls[lock.target]
		if not c or c.peer ~= talker then return false end
	end
	local c = ZCPhone.Calls[talker]
	return c ~= nil and c.state == "active" and not c.enc
end
