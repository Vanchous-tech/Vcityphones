ZCPhone = ZCPhone or {}
local S = ZCPhone.Settings
local st, ui = ZCPhone.State, ZCPhone.UI

surface.CreateFont("ZCPhone_L", { font = "Arial", size = 18, weight = 700, extended = true })
surface.CreateFont("ZCPhone_M", { font = "Arial", size = 14, weight = 600, extended = true })
surface.CreateFont("ZCPhone_S", { font = "Arial", size = 11, weight = 600, extended = true })
surface.CreateFont("ZCPhone_XL", { font = "Arial", size = 30, weight = 800, extended = true })

local BG = Color(150, 182, 118)
local FG = Color(28, 40, 22)
local DIM = Color(28, 40, 22, 110)
local SELBG = Color(40, 56, 32)

local cvHud = CreateClientConVar("zcphone_hud", "0", true, false, "Show phone screen copy on HUD (0 by default)")
local cvHudScale = CreateClientConVar("zcphone_hud_scale", "2.2", true, false)

-- Одноразовая миграция: у всех, кто сохранил прежнее значение 1, копия экрана выключается.
-- Метка zcphone_hud_mig хранится у игрока, поэтому повторно значение не трогается:
-- кто включит zcphone_hud 1 после миграции, останется с 1.
local cvHudMig = CreateClientConVar("zcphone_hud_mig", "0", true, false)
hook.Add("InitPostEntity", "ZCPhone_HudMigrate", function()
	timer.Simple(2, function()
		if cvHudMig:GetInt() >= 1 then return end
		RunConsoleCommand("zcphone_hud", "0")
		RunConsoleCommand("zcphone_hud_mig", "1")
	end)
end)

local function T(text, font, x, y, col, ax, ay)
	draw.SimpleText(text, font, x, y, col or FG, ax or TEXT_ALIGN_LEFT, ay or TEXT_ALIGN_TOP)
end

local function Clip(text, font, maxw)
	surface.SetFont(font)
	if surface.GetTextSize(text) <= maxw then return text end
	local chars = {}
	for ch in string.gmatch(text, utf8.charpattern) do chars[#chars + 1] = ch end
	while #chars > 1 do
		chars[#chars] = nil
		local try = table.concat(chars) .. "…"
		if surface.GetTextSize(try) <= maxw then return try end
	end
	return table.concat(chars) .. "…"
end

local function Wrap(text, font, maxw)
	surface.SetFont(font)
	local lines, line = {}, ""
	for word in string.gmatch(text, "%S+") do
		local try = line == "" and word or (line .. " " .. word)
		if surface.GetTextSize(try) > maxw and line ~= "" then
			lines[#lines + 1] = line
			line = word
		else
			line = try
		end
	end
	if line ~= "" then lines[#lines + 1] = line end
	return lines
end

local function Bars(x, y)
	local ply = LocalPlayer()
	local n = IsValid(ply) and ply:GetNWInt("ZCPhone_Signal", 4) or 0
	for i = 1, 4 do
		local h = 2 + i * 2
		surface.SetDrawColor(BG.r, BG.g, BG.b, i <= n and 255 or 70)
		surface.DrawRect(x + (i - 1) * 4, y + 12 - h, 3, h)
	end
	if n == 0 then T("x", "ZCPhone_S", x + 18, y, BG) end
end
ZCPhone.DrawBars = Bars

local function Header(W, title)
	surface.SetDrawColor(FG)
	surface.DrawRect(0, 0, W, 18)
	T(title, "ZCPhone_M", 4, 2, BG)
	local time = os.date("%H:%M")
	T(time, "ZCPhone_M", W - 4, 2, BG, TEXT_ALIGN_RIGHT)
	surface.SetFont("ZCPhone_M")
	local tw = surface.GetTextSize(time)
	Bars(W - 4 - tw - 30, 3)
end

local function List(W, H, items, hint)
	local rows = 6
	local rh = math.floor((H - 18 - 16) / rows)
	for i = 1, rows do
		local idx = ui.scroll + i
		local it = items[idx]
		if not it then break end
		local y = 20 + (i - 1) * rh
		local sel = idx == ui.sel
		if sel then
			surface.SetDrawColor(SELBG)
			surface.DrawRect(2, y, W - 4, rh - 1)
		end
		T(Clip(it, "ZCPhone_L", W - 14), "ZCPhone_L", 6, y + (rh - 18) / 2, sel and BG or FG)
	end
	if #items > rows then
		local bh = (H - 36) * rows / #items
		surface.SetDrawColor(DIM)
		surface.DrawRect(W - 3, 20 + (H - 36 - bh) * (ui.scroll / (#items - rows)), 2, bh)
	end
	if hint then T(hint, "ZCPhone_S", 4, H - 12, DIM) end
end

local function Call(W, H)
	local c = st.call
	surface.SetDrawColor(FG)
	surface.DrawRect(0, 0, W, 18)
	local title = c.state == "in" and "Входящий" or c.state == "out" and "Вызов..." or "Разговор"
	T(title, "ZCPhone_M", W / 2, 2, BG, TEXT_ALIGN_CENTER)
	if IsValid(LocalPlayer()) and LocalPlayer():GetNWBool("ZCPhone_EncCall", false) then T("ШИФР", "ZCPhone_S", W - 4, 4, BG, TEXT_ALIGN_RIGHT) end
	T(Clip(c.peer, "ZCPhone_XL", W - 8), "ZCPhone_XL", W / 2, H / 2 - 30, FG, TEXT_ALIGN_CENTER)
	if c.state == "active" then
		local s = math.floor(CurTime() - c.t)
		T(string.format("%02d:%02d", s / 60, s % 60), "ZCPhone_L", W / 2, H / 2 + 10, FG, TEXT_ALIGN_CENTER)
	else
		local dots = string.rep(".", math.floor(CurTime() * 2) % 4)
		T(dots, "ZCPhone_L", W / 2, H / 2 + 10, FG, TEXT_ALIGN_CENTER)
	end
	if c.state == "in" then
		T("Принять", "ZCPhone_M", 4, H - 16, FG)
		T("Сбросить", "ZCPhone_M", W - 4, H - 16, FG, TEXT_ALIGN_RIGHT)
	else
		T("Завершить", "ZCPhone_M", W / 2, H - 16, FG, TEXT_ALIGN_CENTER)
	end
end

local function Entry(W, H, title, hint)
	Header(W, title)
	local buf = ui.buf
	local pending = ZCPhone.IsPending() and #buf > 0
	local blink = math.floor(CurTime() * 2) % 2 == 0
	local text = table.concat(buf)
	local lines = Wrap(text, "ZCPhone_L", W - 12)
	if #lines == 0 then lines[1] = "" end
	local start = math.max(1, #lines - 4)
	for i = start, #lines do
		T(lines[i], "ZCPhone_L", 6, 22 + (i - start) * 20)
	end
	local last = lines[#lines]
	surface.SetFont("ZCPhone_L")
	local lw = surface.GetTextSize(last)
	local ly = 22 + (#lines - start) * 20
	if pending then
		local ch = buf[#buf]
		local cw = surface.GetTextSize(ch)
		surface.SetDrawColor(FG)
		surface.DrawRect(6 + lw - cw, ly + 18, cw, 2)
	elseif blink then
		surface.SetDrawColor(FG)
		surface.DrawRect(7 + lw, ly + 1, 2, 17)
	end
	if hint then T(hint, "ZCPhone_S", 4, H - 12, DIM) end
	if ui.screen == "compose" or ui.screen == "add_name" then
		T(ui.caseMode .. " " .. (ui.layout == "ru" and "РУС" or "ENG"), "ZCPhone_S", W / 2, H - 12, DIM, TEXT_ALIGN_CENTER)
		if ui.screen == "compose" then T(#buf .. "/" .. S.MaxMessageLength, "ZCPhone_S", W - 4, H - 12, DIM, TEXT_ALIGN_RIGHT) end
	end
end

function ZCPhone.DrawScreen(W, H)
	surface.SetDrawColor(BG)
	surface.DrawRect(0, 0, W, H)

	if st.call.state ~= "idle" then
		Call(W, H)
	elseif st.ir.state ~= "idle" then
		ZCPhone.DrawIR(W, H)
	else
		local s = ui.screen
		if s == "home" then
			Header(W, "ZC")
			T(os.date("%H:%M"), "ZCPhone_XL", W / 2, H / 2 - 36, FG, TEXT_ALIGN_CENTER)
			T(os.date("%d.%m.%Y"), "ZCPhone_M", W / 2, H / 2 - 2, FG, TEXT_ALIGN_CENTER)
			T("№ " .. st.number, "ZCPhone_L", W / 2, H / 2 + 20, FG, TEXT_ALIGN_CENTER)
			if IsValid(LocalPlayer()) and LocalPlayer():GetNWInt("ZCPhone_Signal", 4) == 0 then
				T("Нет сети", "ZCPhone_M", W / 2, H / 2 + 68, FG, TEXT_ALIGN_CENTER)
			end
			local unread = 0
			for _, m in ipairs(st.messages) do if not m.read then unread = unread + 1 end end
			if unread > 0 then T("Новых СМС: " .. unread, "ZCPhone_M", W / 2, H / 2 + 46, FG, TEXT_ALIGN_CENTER) end
			T("OK - меню", "ZCPhone_M", W / 2, H - 16, FG, TEXT_ALIGN_CENTER)
		elseif s == "menu" then
			Header(W, "Меню")
			local items = {}
			for i, it in ipairs(ZCPhone.MenuItems) do items[i] = it[1] end
			List(W, H, items, "2/8 выбор  OK ввод")
		elseif s == "contacts" then
			Header(W, ui.mode == "call" and "Позвонить" or ui.mode == "write" and "Написать" or "Контакты")
			local items = {}
			if ui.mode == "browse" then items[1] = "[+ Добавить]" end
			for _, c in ipairs(st.contacts) do items[#items + 1] = c.name .. " " .. c.num end
			if #items == 0 then T("Пусто", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) end
			List(W, H, items)
		elseif s == "contact_menu" then
			Header(W, ui.target and ui.target.name or "")
			List(W, H, { "Позвонить", "Написать", "Удалить" })
		elseif s == "add_number" then
			Entry(W, H, "Номер (" .. S.NumberDigits .. " цифры)", "OK далее  красная стереть")
		elseif s == "dial" then
			Entry(W, H, "Набрать номер", "OK/зелёная - вызов")
			local n = tonumber(ZCPhone.BufText())
			local c = #ui.buf == S.NumberDigits and n and ZCPhone.FindContact(n)
			if c then T(c.name, "ZCPhone_M", W / 2, H - 28, FG, TEXT_ALIGN_CENTER) end
		elseif s == "add_name" then
			Entry(W, H, "Имя " .. (ui.newNumber or ""), "OK сохр. *язык #Abc")
		elseif s == "compose" then
			Entry(W, H, "→ " .. (ui.target and ui.target.name or ""), "OK отпр. *язык #Abc")
		elseif s == "inbox" then
			Header(W, "Сообщения")
			local items = {}
			for i, m in ipairs(st.messages) do items[i] = (m.read and "" or "* ") .. ZCPhone.NameOf(m.from) .. ": " .. m.text end
			if #items == 0 then T("Пусто", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) end
			List(W, H, items)
		elseif s == "loot" then
			Header(W, "Трофеи")
			local items = {}
			for i, d in ipairs(st.loot or {}) do items[i] = "Телефон " .. d.num end
			if #items == 0 then T("Пусто", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) end
			List(W, H, items)
		elseif s == "loot_dev" then
			Header(W, "№ " .. (ui.target and ui.target.num or ""))
			List(W, H, { "Контакты", "Сообщения" })
		elseif s == "loot_contacts" then
			Header(W, "Контакты " .. (ui.target and ui.target.num or ""))
			local items = {}
			for i, c in ipairs(ui.target and ui.target.contacts or {}) do items[i] = c.name .. " " .. c.num end
			if #items == 0 then T("Пусто", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) end
			List(W, H, items)
		elseif s == "loot_msgs" then
			Header(W, "СМС " .. (ui.target and ui.target.num or ""))
			local items = {}
			for i, m in ipairs(ui.target and ui.target.msgs or {}) do items[i] = m.from .. ": " .. m.text end
			if #items == 0 then T("Пусто", "ZCPhone_L", W / 2, H / 2, FG, TEXT_ALIGN_CENTER) end
			List(W, H, items)
		elseif s == "msg_view" then
			local m = ui.target
			Header(W, m and (m.loot and tostring(m.from) or ZCPhone.NameOf(m.from)) or "")
			if m then
				local lines = Wrap(m.text, "ZCPhone_M", W - 10)
				for i, l in ipairs(lines) do T(l, "ZCPhone_M", 5, 22 + (i - 1) * 15) end
				T(os.date("%d.%m %H:%M", m.ts), "ZCPhone_S", 4, H - 24, DIM)
				T(m.loot and "OK назад" or ZCPhone.FindContact(m.from) and "OK ответить" or "OK в контакты", "ZCPhone_S", 4, H - 12, DIM)
			end
		elseif s == "camera" then
			ZCPhone.DrawCamera(W, H)
		elseif s == "gallery" then
			ZCPhone.DrawGallery(W, H)
		elseif s == "snake" then
			ZCPhone.DrawSnake(W, H)
		elseif s == "mines" then
			ZCPhone.DrawMines(W, H)
		elseif s == "settings" then
			Header(W, "Настройки")
			local r = ZCPhone.RingByID(st.ring)
			local lp = LocalPlayer()
			local rows = {
				"Мелодия: " .. (r and r.name or "нет"),
				"Без звука: " .. (st.silent and "да" or "нет"),
				"Звук клавиш: " .. (GetConVar("zcphone_keysound"):GetBool() and "да" or "нет"),
			}
			if IsValid(lp) and lp:GetNWBool("ZCPhone_CanEnc", false) then
				rows[4] = "Шифр: " .. (lp:GetNWBool("ZCPhone_Enc", false) and "да" or "нет")
			end
			List(W, H, rows)
		elseif s == "ringtones" then
			Header(W, "Мелодия")
			local items = {}
			for i, r in ipairs(ZCPhone.Sounds.rings) do items[i] = (r.id == st.ring and "* " or "") .. r.name end
			if #items == 0 then items[1] = "(нет файлов)" end
			List(W, H, items, "OK выбрать/прослушать")
		elseif s == "mynumber" then
			Header(W, "Мой номер")
			T(tostring(st.number), "ZCPhone_XL", W / 2, H / 2 - 20, FG, TEXT_ALIGN_CENTER)
		end
	end

	if st.noticeUntil > CurTime() then
		surface.SetDrawColor(FG)
		surface.DrawRect(6, H / 2 - 14, W - 12, 28)
		T(Clip(st.notice, "ZCPhone_M", W - 20), "ZCPhone_M", W / 2, H / 2 - 8, BG, TEXT_ALIGN_CENTER)
	end
end

function ZCPhone.ScreenSize()
	local sc = ZCPhone.Config.Screen
	local scale = math.max(0.01, sc.w) / 160
	return 160, math.max(40, sc.h / scale), scale
end

ZCPhone.ScreenXform = ZCPhone.ScreenXform or {}

hook.Add("PostDrawTranslucentRenderables", "ZCPhone_Screen3D2D", function(depth, sky)
	if depth or sky then return end
	local lp = LocalPlayer()
	for ply, x in pairs(ZCPhone.ScreenXform) do
		if not IsValid(ply) or x.frame < FrameNumber() - 3 then
			ZCPhone.ScreenXform[ply] = nil
        elseif ZCPhone.Config.Screen.enabled and not (ZCPhone.RenderingCamera and ply == lp) then
			local W, H, scale = ZCPhone.ScreenSize()
			cam.Start3D2D(x.pos, x.ang, scale * ZCPhone.Config.Scale)
			if ply == lp then
				ZCPhone.DrawScreen(W, H)
			else
				surface.SetDrawColor(BG)
				surface.DrawRect(0, 0, W, H)
				T(os.date("%H:%M"), "ZCPhone_XL", W / 2, H / 2 - 15, FG, TEXT_ALIGN_CENTER)
			end
			cam.End3D2D()
		end
	end
end)

hook.Add("HUDPaint", "ZCPhone_HudMirror", function()
	if not cvHud:GetBool() or not ZCPhone.IsOut() then return end
	local W, H = ZCPhone.ScreenSize()
	local sc = cvHudScale:GetFloat()
	local pw, ph = W * sc, H * sc
	local x, y = ScrW() - pw - 30, ScrH() - ph - 30
	surface.SetDrawColor(20, 20, 20, 240)
	surface.DrawRect(x - 8, y - 8, pw + 16, ph + 16)
	local m = Matrix()
	m:Translate(Vector(x, y, 0))
	m:Scale(Vector(sc, sc, 1))
	cam.PushModelMatrix(m)
	ZCPhone.DrawScreen(W, H)
	cam.PopModelMatrix()
end)
