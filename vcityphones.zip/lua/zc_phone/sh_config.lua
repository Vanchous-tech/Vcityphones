ZCPhone = ZCPhone or {}

ZCPhone.WeaponClass = "weapon_zc_phone"

-- Служебный контакт «Штаб»: присылает учебный курс по SMS. Номер вне диапазона обычных (4 цифры).
ZCPhone.SystemNumber = 100
ZCPhone.SystemName = "Штаб"

ZCPhone.Settings = {
	NumberDigits = 4,
	MaxContacts = 30,
	MaxMessages = 30,
	MaxMessageLength = 120,
	MaxNameLength = 14,
	RingTime = 25,
	RingInterval = 3,
	-- SoundDuration() returns 0 for .ogg and VBR .mp3. Then this many seconds are assumed, otherwise
	-- the melody was cut and restarted every RingInterval seconds.
	RingFallbackLength = 6,
	RingSound = "ambient/alarms/warningbell1.wav",
	RingVolume = 55,
	MessageSound = "buttons/blip1.wav",
	TowerRange = 7000,
	TowerHealth = 800,
	TowerRepairTime = 10,
	TowerModel = "models/props_c17/utilitypole01a.mdl",
	ScannerRange = 4000,
	ScannerLockTime = 3,
	DropModel = "models/ivancorn/gtaiv/electrical/phones/cellphone_whiz_highspeed.mdl",
	DropLifetime = 900,
}

ZCPhone.Binds = {
	menu = { KEY_M },
	ok = { KEY_ENTER, KEY_PAD_ENTER },
	green = { KEY_G, KEY_PAD_PLUS },
	red = { KEY_BACKSPACE, KEY_PAD_MINUS },
}

ZCPhone.KeyOrder = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#", "menu", "ok", "red", "green" }

function ZCPhone.DefaultConfig()
	return {
		Model = "models/ivancorn/gtaiv/electrical/phones/cellphone_whiz_highspeed.mdl",
		Skin = 0,
		Scale = 1,
		Hand = { pos = Vector(3, 0, 0), ang = Angle(0, 0, 0) },
		Pose = { show = Vector(14, -5, -3), handAng = Angle(0, 0, 0), time = 0.8 },
		Curl = { 15, 40, 40 },
		Camera = { pos = Vector(0, 0, 0), ang = Angle(0, 0, 0), fov = 55 },
		Screen = { pos = Vector(0.5, 0, 1), ang = Angle(0, 0, 0), w = 4, h = 5.2, enabled = true },
		Keys = {
			origin = Vector(0, 1, -1.5),
			boxSize = Vector(0.35, 0.7, 0.6),
			boxAng = Angle(0, 0, 0),
			colStep = Vector(0, -1, 0),
			rowStep = Vector(0, 0, -0.9),
			special = {
				menu = Vector(0, 1, 0.2),
				ok = Vector(0, 0, 0.5),
				red = Vector(0, -1.4, 0.6),
				green = Vector(0, 1.4, 0.6),
			},
		},
		Thumb = {
			idle = { 0.5, 0.65 },
			useIK = true,
			tipLen = 1.2,
			maxStep = 25,
			lift = 0.5,
			depth = 0.1,
			speed = 14,
			pressTime = 0.16,
			corners = {
				tl = { Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0) },
				tr = { Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0) },
				bl = { Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0) },
				br = { Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0) },
			},
			press = { Angle(0, 0, 0), Angle(0, 0, 0), Angle(0, 0, 0) },
		},
	}
end

ZCPhone.Config = ZCPhone.Config or ZCPhone.DefaultConfig()

function ZCPhone.MergeConfig(dst, src)
	for k, v in pairs(src) do
		if istable(v) and not isvector(v) and not isangle(v) and istable(dst[k]) then
			ZCPhone.MergeConfig(dst[k], v)
		else
			dst[k] = v
		end
	end
	return dst
end

if CLIENT then
	if file.Exists("zc_phone/config_export.lua", "LUA") then
		include("zc_phone/config_export.lua")
	end

	local dev = CreateClientConVar("zcphone_dev_config", "1", true, false, "Use data/zc_phone/config.txt for live tuning")
	if dev:GetBool() and file.Exists("zc_phone/config.txt", "DATA") then
		local fn = CompileString("return " .. file.Read("zc_phone/config.txt", "DATA"), "zc_phone_dev_config", false)
		if isfunction(fn) then
			local ok, res = pcall(fn)
			if ok and istable(res) then ZCPhone.MergeConfig(ZCPhone.Config, res) end
		end
	end
end

-- Apply the requested startup model AFTER exported and local settings.
-- Deliberately overrides only Model, preserving pose, keys, scale and screen.
if CLIENT then
 ZCPhone.Config.Model = "models/ivancorn/gtaiv/electrical/phones/cellphone_whiz_highspeed.mdl"
end

if CLIENT then
 function ZCPhone.ModelAvailable(path)
  return isstring(path) and path ~= "" and file.Exists(path, "GAME")
 end
end

if CLIENT then
 concommand.Add("zcphone_modelcheck", function()
  local path = ZCPhone.Config.Model or ""
  print("[ZCPhone] Активная модель: " .. path)
  print("[ZCPhone] Файл в GAME: " .. tostring(file.Exists(path, "GAME")))
  print("[ZCPhone] util.IsValidModel: " .. tostring(util.IsValidModel(path)))
  print("[ZCPhone] Локальный конфиг DATA: " .. tostring(file.Exists("zc_phone/config.txt", "DATA")))
  print("[ZCPhone] Экспорт LUA: " .. tostring(file.Exists("zc_phone/config_export.lua", "LUA")))
 end)
end


ZCPhone.SoundDir = "zc_phone/"
ZCPhone.SoundExt = { wav = true, mp3 = true, ogg = true }

function ZCPhone.ScanSounds()
	local out = { rings = {}, sms = nil, tapStart = nil, tapEnd = nil }
	local function Find(name)
		for ext in pairs(ZCPhone.SoundExt) do
			if file.Exists("sound/" .. ZCPhone.SoundDir .. name .. "." .. ext, "GAME") then return ZCPhone.SoundDir .. name .. "." .. ext end
		end
	end
	out.tapStart, out.tapEnd, out.sms = Find("tap_start"), Find("tap_end"), Find("sms")
	local files = file.Find("sound/" .. ZCPhone.SoundDir .. "ringtones/*", "GAME")
	table.sort(files)
	for _, f in ipairs(files) do
		local base, ext = string.match(f, "^(.*)%.(%w+)$")
		if base and ZCPhone.SoundExt[string.lower(ext)] then
			out.rings[#out.rings + 1] = { id = f, name = base, path = ZCPhone.SoundDir .. "ringtones/" .. f }
			-- Clients that cannot download a file stay silent while the server "plays" it.
			-- Non-ASCII names (e.g. Cyrillic) and capitals break resource.AddFile / FastDL.
			if SERVER and (f:find("[\128-\255]") or f:find("%u") or f:find("[^%w_%-%.]")) then
				print("[ZCPhone] ВНИМАНИЕ: рингтон «" .. f .. "» может не скачаться у части игроков (тихо у них): " ..
					"используйте только строчные латинские буквы, цифры, _ и - в имени файла.")
			end
		end
	end
	return out
end

ZCPhone.Sounds = ZCPhone.ScanSounds()

function ZCPhone.RingByID(id)
	for _, r in ipairs(ZCPhone.Sounds.rings) do
		if r.id == id then return r end
	end
	return ZCPhone.Sounds.rings[1]
end
