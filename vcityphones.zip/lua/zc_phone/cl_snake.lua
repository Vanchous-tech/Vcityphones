ZCPhone = ZCPhone or {}
local ui, st = ZCPhone.UI, ZCPhone.State

local CELL = 10
local cvBest = CreateClientConVar("zcphone_snake_best", "0", true, false)

local game

local function Dims()
	local W, H = ZCPhone.ScreenSize()
	local cols = math.floor((W - 8) / CELL)
	local rows = math.floor((H - 28) / CELL)
	return cols, rows, W, H
end

local function PlaceFood()
	local cols, rows = Dims()
	local taken = {}
	for _, p in ipairs(game.body) do taken[p.x .. "," .. p.y] = true end
	for _ = 1, 200 do
		local x, y = math.random(0, cols - 1), math.random(0, rows - 1)
		if not taken[x .. "," .. y] then game.food = { x = x, y = y } return end
	end
	game.food = nil
end

local function Reset()
	local cols, rows = Dims()
	local cx, cy = math.floor(cols / 2), math.floor(rows / 2)
	game = {
		body = { { x = cx, y = cy }, { x = cx - 1, y = cy }, { x = cx - 2, y = cy } },
		dir = { 1, 0 }, nextDir = { 1, 0 },
		score = 0, alive = true, paused = true, last = CurTime(),
	}
	PlaceFood()
end

local DIRS = { ["2"] = { 0, -1 }, ["8"] = { 0, 1 }, ["4"] = { -1, 0 }, ["6"] = { 1, 0 } }

function ZCPhone.SnakeKey(key)
	if not game then return end
	if key == "ok" then
		if not game.alive then Reset() game.paused = false return end
		game.paused = not game.paused
		return
	end
	local d = DIRS[key]
	if d and game.alive then
		if d[1] ~= -game.dir[1] or d[2] ~= -game.dir[2] then game.nextDir = d end
		game.paused = false
	end
end

local function Step()
	local cols, rows = Dims()
	game.dir = game.nextDir
	local head = game.body[1]
	local nx = (head.x + game.dir[1]) % cols
	local ny = (head.y + game.dir[2]) % rows
	local ate = game.food and nx == game.food.x and ny == game.food.y
	local n = #game.body
	for i = 1, ate and n or n - 1 do
		local p = game.body[i]
		if p.x == nx and p.y == ny then
			game.alive = false
			if game.score > cvBest:GetInt() then RunConsoleCommand("zcphone_snake_best", tostring(game.score)) end
			return
		end
	end
	table.insert(game.body, 1, { x = nx, y = ny })
	if ate then
		game.score = game.score + 1
		PlaceFood()
	else
		table.remove(game.body)
	end
end

hook.Add("Think", "ZCPhone_Snake", function()
	if ui.screen ~= "snake" then game = nil return end
	if not game then Reset() end
	if game.paused or not game.alive then game.last = CurTime() return end
	if st.call.state ~= "idle" then game.last = CurTime() return end
	local interval = math.max(0.07, 0.2 - game.score * 0.004)
	if CurTime() - game.last >= interval then
		game.last = CurTime()
		Step()
	end
end)

function ZCPhone.DrawSnake(W, H)
	if not game then return end
	local FG, BG = Color(28, 40, 22), Color(150, 182, 118)
	local cols, rows = Dims()
	surface.SetDrawColor(FG)
	surface.DrawRect(0, 0, W, 18)
	draw.SimpleText("Змейка", "ZCPhone_M", 4, 2, BG)
	draw.SimpleText(tostring(game.score), "ZCPhone_M", W - 4, 2, BG, TEXT_ALIGN_RIGHT)

	local ox, oy = 4, 22
	surface.DrawOutlinedRect(ox - 2, oy - 2, cols * CELL + 4, rows * CELL + 4)
	for i, p in ipairs(game.body) do
		surface.DrawRect(ox + p.x * CELL + 1, oy + p.y * CELL + 1, CELL - 2, CELL - 2)
		if i == 1 then
			surface.SetDrawColor(BG)
			surface.DrawRect(ox + p.x * CELL + 3, oy + p.y * CELL + 3, 2, 2)
			surface.SetDrawColor(FG)
		end
	end
	if game.food then
		local f = game.food
		surface.DrawRect(ox + f.x * CELL + 3, oy + f.y * CELL + 1, CELL - 6, CELL - 2)
		surface.DrawRect(ox + f.x * CELL + 1, oy + f.y * CELL + 3, CELL - 2, CELL - 6)
	end

	local msg, sub
	if not game.alive then
		msg, sub = "Конец игры", "Рекорд " .. cvBest:GetInt() .. "  OK - заново"
	elseif game.paused then
		msg, sub = "Пауза", "2/4/6/8 - ход, OK - пауза"
	end
	if msg then
		surface.SetDrawColor(FG)
		surface.DrawRect(6, H / 2 - 22, W - 12, 44)
		draw.SimpleText(msg, "ZCPhone_L", W / 2, H / 2 - 18, BG, TEXT_ALIGN_CENTER)
		draw.SimpleText(sub, "ZCPhone_S", W / 2, H / 2 + 6, BG, TEXT_ALIGN_CENTER)
	end
end
