ZCPhone = ZCPhone or {}

local function Walk(path)
	local node = ZCPhone.Config
	local parts = string.Explode(".", path)
	for i = 1, #parts - 1 do
		local k = tonumber(parts[i]) or parts[i]
		node = node[k]
		if node == nil then return end
	end
	return node, parts[#parts]
end

local function Get(path)
	local node, key = Walk(path)
	if node == nil then return 0 end
	if isvector(node) or isangle(node) then return node[key] end
	return node[tonumber(key) or key] or 0
end

local function Set(path, val)
	local node, key = Walk(path)
	if node == nil then return end
	if isvector(node) then node[key] = val return end
	if isangle(node) then node[key] = val return end
	node[tonumber(key) or key] = val
end

local function Ser(v, ind)
	ind = ind or ""
	if isvector(v) then return string.format("Vector(%.3f, %.3f, %.3f)", v.x, v.y, v.z) end
	if isangle(v) then return string.format("Angle(%.2f, %.2f, %.2f)", v.p, v.y, v.r) end
	if isstring(v) then return string.format("%q", v) end
	if isbool(v) then return tostring(v) end
	if isnumber(v) then return string.format("%.4f", v) end
	if istable(v) then
		local out, inner = {}, ind .. "\t"
		local seq = #v > 0
		if seq then
			for _, x in ipairs(v) do out[#out + 1] = inner .. Ser(x, inner) end
		else
			local keys = table.GetKeys(v)
			table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
			for _, k in ipairs(keys) do out[#out + 1] = inner .. "[" .. string.format("%q", k) .. "] = " .. Ser(v[k], inner) end
		end
		return "{\n" .. table.concat(out, ",\n") .. "\n" .. ind .. "}"
	end
	return "nil"
end

function ZCPhone.SaveConfig()
	file.CreateDir("zc_phone")
	file.Write("zc_phone/config.txt", Ser(ZCPhone.Config))
	print("[ZCPhone] сохранено: garrysmod/data/zc_phone/config.txt")
end

function ZCPhone.ExportConfig()
	file.CreateDir("zc_phone")
	file.Write("zc_phone/config_export.txt", "ZCPhone.MergeConfig(ZCPhone.Config, " .. Ser(ZCPhone.Config) .. ")\n")
	print("[ZCPhone] экспорт: garrysmod/data/zc_phone/config_export.txt (положить в lua/zc_phone/config_export.lua)")
end

local function Vec(path, label, lo, hi, axes)
	local out = {}
	for _, a in ipairs(axes or { "x", "y", "z" }) do
		out[#out + 1] = { path .. "." .. a, label .. " " .. a, lo, hi }
	end
	return out
end

local function Join(...)
	local out = {}
	for _, t in ipairs({ ... }) do for _, e in ipairs(t) do out[#out + 1] = e end end
	return out
end

local PYR = { "p", "y", "r" }

local function Corner(key, label)
	local out = {}
	for i = 1, 3 do
		out = Join(out, Vec("Thumb.corners." .. key .. "." .. i, label .. " кость " .. i, -90, 90, PYR))
	end
	return out
end

local function Press()
	local out = {}
	for i = 1, 3 do out = Join(out, Vec("Thumb.press." .. i, "Нажатие кость " .. i, -60, 60, PYR)) end
	return out
end

local SECTIONS = {
 { "Зоны кнопок (не хитбоксы тела)", Join(
  Vec("Keys.boxSize", "Размер зоны", 0.05, 4),
  Vec("Keys.boxAng", "Ориентация зоны", -180, 180, PYR)
 ) },
	{ "Телефон в руке", Join(
		Vec("Hand.pos", "Позиция", -15, 15),
		Vec("Hand.ang", "Угол", -180, 180, PYR),
		{ { "Scale", "Масштаб", 0.1, 3 } }
	) },
	{ "Поза руки", Join(
		Vec("Pose.show", "Рука вперёд/вправо/вверх", -30, 40),
		Vec("Pose.handAng", "Кисть", -180, 180, PYR),
		{ { "Pose.time", "Время подъёма", 0.2, 3 } }
	) },
	{ "Пальцы (сгиб)", {
		{ "Curl.1", "Сгиб: основание", -30, 90 },
		{ "Curl.2", "Сгиб: середина", -30, 120 },
		{ "Curl.3", "Сгиб: кончик", -30, 120 },
	} },
	{ "Объектив камеры", Join(
		Vec("Camera.pos", "Позиция", -15, 15),
		Vec("Camera.ang", "Угол", -180, 180, PYR),
		{ { "Camera.fov", "FOV", 20, 110 } }
	) },
	{ "Экран 3D2D", Join(
		Vec("Screen.pos", "Позиция", -15, 15),
		Vec("Screen.ang", "Угол", -180, 180, PYR),
		{ { "Screen.w", "Ширина", 0.5, 12 }, { "Screen.h", "Высота", 0.5, 12 } }
	) },
	{ "Клавиши (сетка 1-9,*,0,#)", Join(
		Vec("Keys.origin", "Клавиша 1", -10, 10),
		Vec("Keys.colStep", "Шаг по столбцу", -4, 4),
		Vec("Keys.rowStep", "Шаг по строке", -4, 4)
	) },
	{ "Спец. клавиши", Join(
		Vec("Keys.special.menu", "Menu", -10, 10),
		Vec("Keys.special.ok", "OK", -10, 10),
		Vec("Keys.special.red", "Красная", -10, 10),
		Vec("Keys.special.green", "Зелёная", -10, 10)
	) },
	{ "Большой палец: общее", {
		{ "Thumb.idle.1", "Покой U", -0.4, 1.4 },
		{ "Thumb.idle.2", "Покой V", -0.4, 1.4 },
		{ "Thumb.speed", "Скорость", 2, 40 },
		{ "Thumb.pressTime", "Время нажатия", 0.05, 0.6 },
		{ "Thumb.tipLen", "IK: длина кончика", 0, 4 },
		{ "Thumb.maxStep", "IK: макс. шаг (град)", 3, 60 },
		{ "Thumb.lift", "IK: высота над клавишей", -1, 3 },
		{ "Thumb.depth", "IK: вдавливание", 0, 1 },
	} },
	{ "Палец: верх-лево (клавиша 1)", Corner("tl", "TL") },
	{ "Палец: верх-право (клавиша 3)", Corner("tr", "TR") },
	{ "Палец: низ-лево (клавиша *)", Corner("bl", "BL") },
	{ "Палец: низ-право (клавиша #)", Corner("br", "BR") },
	{ "Палец: нажатие", Press() },
}

concommand.Add("zcphone_tune", function()
	if IsValid(ZCPhoneTune) then ZCPhoneTune:Remove() end
	local f = vgui.Create("DFrame")
	ZCPhoneTune = f
	f:SetTitle("ZC Phone: настройка макета")
	f:SetSize(math.min(1000, ScrW() - 40), math.min(ScrH() - 60, 800))
	f:SetPos(20, 30)
	f:MakePopup()
	f:SetKeyboardInputEnabled(true)
 f.OnRemove = function() ZCPhone.PreviewKey = nil end

 local preview = vgui.Create("DModelPanel", f)
 preview:Dock(RIGHT)
 preview:SetWide(math.max(200, f:GetWide() - 460))
 preview:SetFOV(35)
 if ZCPhone.ModelAvailable(ZCPhone.Config.Model) then preview:SetModel(ZCPhone.Config.Model) end
 preview.Think = function(panel)
  local path = ZCPhone.Config.Model
  panel.ZCMissing = not ZCPhone.ModelAvailable(path)
  if not panel.ZCMissing and (not IsValid(panel.Entity) or panel.Entity:GetModel() ~= string.lower(path)) then util.PrecacheModel(path) panel:SetModel(path) end
 end
 preview.PreDrawModel = function(panel) return panel.ZCMissing end
 preview.PaintOver = function(panel, w, h)
  if not panel.ZCMissing then return end
  draw.SimpleText("Модель не найдена / не загружена", "DermaDefaultBold", w / 2, h / 2, Color(255, 100, 70), TEXT_ALIGN_CENTER)
  draw.SimpleText("В консоли: zcphone_modelcheck", "DermaDefault", w / 2, h / 2 + 22, color_white, TEXT_ALIGN_CENTER)
 end
 preview:SetAmbientLight(Color(200, 200, 200))
 preview.LayoutEntity = function(panel, ent)
  local path = ZCPhone.Config.Model
  if not ZCPhone.ModelAvailable(path) then return end
  if ent:GetModel() ~= string.lower(path) then util.PrecacheModel(path) panel:SetModel(path) return end
  ent:SetSkin(ZCPhone.Config.Skin or 0)
  ent:SetModelScale(ZCPhone.Config.Scale, 0)
  local mins, maxs = ent:GetModelBounds()
  local center = (mins + maxs) * (0.5 * ZCPhone.Config.Scale)
  local radius = math.max(3, (maxs - mins):Length() * ZCPhone.Config.Scale * 0.5)
  local yaw = (panel.ZCYaw or 30)
  panel:SetLookAt(center)
  panel:SetCamPos(center + Angle(15, yaw, 0):Forward() * radius * 4)
 end
 preview.OnMouseWheeled = function(panel, delta)
  panel.ZCYaw = (panel.ZCYaw or 30) + delta * 15
  return true
 end
 preview.PostDrawModel = function(_, ent)
  ZCPhone.DrawDebug(ent:GetPos(), ent:GetAngles())
 end

	local top = vgui.Create("DPanel", f)
	top:Dock(TOP)
	top:SetTall(158)
	top.Paint = nil

	local model = vgui.Create("DTextEntry", top)
	model:Dock(TOP)
	model:SetText(ZCPhone.Config.Model)
	model.OnEnter = function(s) ZCPhone.Config.Model = s:GetValue() end

	local row = vgui.Create("DPanel", top)
	row:Dock(TOP)
	row:SetTall(24)
	row.Paint = nil
	local function Btn(text, fn, w)
		local b = vgui.Create("DButton", row)
		b:Dock(LEFT)
		b:SetWide(math.min(w or 80, 84))
		b:SetText(text)
		b.DoClick = fn
		return b
	end
	Btn("Модель OK", function() ZCPhone.Config.Model = model:GetValue() end, 80)
	Btn("Сохранить", function() ZCPhone.SaveConfig() end, 80)
	Btn("Экспорт", function() ZCPhone.ExportConfig() end, 70)
	Btn("Сброс", function() ZCPhone.Config = ZCPhone.DefaultConfig() f:Close() RunConsoleCommand("zcphone_tune") end, 60)
	Btn("Вид 3-го лица", function() RunConsoleCommand("zcphone_thirdperson", GetConVar("zcphone_thirdperson"):GetBool() and "0" or "1") end, 100)

	local toggle = vgui.Create("DCheckBoxLabel", top)
 toggle:Dock(TOP)
 toggle:SetTall(22)
 toggle:SetText("Зоны в мире (в предпросмотре видны всегда)")
 toggle:SetConVar("zcphone_debug")
 local xray = vgui.Create("DCheckBoxLabel", top)
 xray:Dock(TOP)
 xray:SetTall(22)
 xray:SetText("Зоны сквозь модель; колесо над моделью: поворот")
 xray:SetConVar("zcphone_debug_xray")
 local pv = vgui.Create("DPanel", top)
	pv:Dock(TOP)
	pv:SetTall(48)
	pv.Paint = nil
	row = pv
	local keys = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#", "menu", "ok", "red", "green" }
	for _, k in ipairs(keys) do
		local b = vgui.Create("DButton", pv)
		b:SetSize(48, 22)
		local i = table.KeyFromValue(keys, k) - 1
		b:SetPos((i % 8) * 49, math.floor(i / 8) * 23)
		b:SetText(k)
		b.DoClick = function() ZCPhone.PreviewKey = (ZCPhone.PreviewKey ~= k) and k or nil end
	end
	local clr = vgui.Create("DLabel", top)
	clr:Dock(TOP)
	clr:SetText("Кнопки внизу = предпросмотр пальца на клавише (повторный клик снимает). Возьмите телефон: bind к zcphone.")

	local scroll = vgui.Create("DScrollPanel", f)
	scroll:Dock(FILL)
	for _, sec in ipairs(SECTIONS) do
		local cat = vgui.Create("DCollapsibleCategory", scroll)
		cat:Dock(TOP)
		cat:SetLabel(sec[1])
		cat:SetExpanded(false)
		local list = vgui.Create("DPanelList", cat)
		list:SetAutoSize(true)
		cat:SetContents(list)
		for _, it in ipairs(sec[2]) do
			local s = vgui.Create("DNumSlider")
			s:SetText(it[2])
			s:SetMin(it[3])
			s:SetMax(it[4])
			s:SetDecimals(2)
			s:SetValue(Get(it[1]))
			s:SetTall(22)
			s.OnValueChanged = function(_, v) Set(it[1], v) end
			list:AddItem(s)
		end
	end
end)

hook.Add("HUDPaint", "ZCPhone_PreviewLabel", function()
	if ZCPhone.PreviewKey then
		draw.SimpleText("Предпросмотр клавиши: " .. ZCPhone.PreviewKey, "DermaDefaultBold", ScrW() / 2, 60, color_white, TEXT_ALIGN_CENTER)
	end
end)
