-- Shared limits and conservative JPEG framing checks for the IR photo stream.
ZCPhone = ZCPhone or {}
ZCPhone.Photo = ZCPhone.Photo or {}
local P = ZCPhone.Photo
P.Width, P.Height = 1152, 864 -- 995,328 real colour pixels, 4:3
P.MaxBytes = 2 * 1024 * 1024
P.ChunkBytes = 4096
P.MaxSessions = 4

-- Check the outer JPEG framing and the dimensions BEFORE loading an image
-- supplied by another player. This is not a full JPEG decoder or sandbox.
function P.ValidJPEG(data)
    if not isstring(data) or #data < 32 or #data > P.MaxBytes then return false end
    local n = #data
    if data:byte(1) ~= 255 or data:byte(2) ~= 216 or data:byte(n-1) ~= 255 or data:byte(n) ~= 217 then return false end
    local p, seen = 3, false
    while p < n - 1 do
        if data:byte(p) ~= 255 then return false end
        while p < n and data:byte(p) == 255 do p = p + 1 end
        local marker = data:byte(p)
        p = p + 1
        if not marker or marker == 0 or marker == 216 or marker == 217 then return false end
        if marker ~= 1 and not (marker >= 208 and marker <= 215) then
            if p + 1 > n then return false end
            local len = data:byte(p) * 256 + data:byte(p + 1)
            if len < 2 or p + len - 1 > n - 2 then return false end
            if marker == 192 or marker == 193 or marker == 194 then
                if seen or len < 8 then return false end
                local precision = data:byte(p + 2)
                local h = data:byte(p + 3) * 256 + data:byte(p + 4)
                local w = data:byte(p + 5) * 256 + data:byte(p + 6)
                local components = data:byte(p + 7)
                if precision ~= 8 or w ~= P.Width or h ~= P.Height or components ~= 3 or len < 8 + components * 3 then return false end
                seen = true
            elseif marker == 218 then
                return seen and len >= 6
            end
            p = p + len
        end
    end
    return false
end
