ZCPhone = ZCPhone or {}
local st, ui = ZCPhone.State, ZCPhone.UI

local R = "ValveBiped.Bip01_R_"
local THUMB = { R .. "Finger0", R .. "Finger01", R .. "Finger02" }
local FINGERS = {}
for n = 1, 4 do FINGERS[n] = { R .. "Finger" .. n, R .. "Finger" .. n .. "1", R .. "Finger" .. n .. "2" } end

local cvThird = CreateClientConVar("zcphone_thirdperson", "0", false, false, "Third person view for tuning the phone pose")

local function Cfg() return ZCPhone.Config end

local function KeyLocal(name)
	local k = Cfg().Keys
	local sp = k.special[name]
	if sp then return sp end
	local idx = ({ ["1"] = 0, ["2"] = 1, ["3"] = 2, ["4"] = 3, ["5"] = 4, ["6"] = 5, ["7"] = 6, ["8"] = 7, ["9"] = 8, ["*"] = 9, ["0"] = 10, ["#"] = 11 })[name]
	if not idx then return k.origin end
	local col, row = idx % 3, math.floor(idx / 3)
	return k.origin + k.colStep * col + k.rowStep * row
end
ZCPhone.KeyLocal = KeyLocal

local function PosUV(localPos)
	local k = Cfg().Keys
	local rel = localPos - k.origin
	local cs, rs = k.colStep, k.rowStep
	local u = cs:LengthSqr() > 0 and rel:Dot(cs) / cs:LengthSqr() / 2 or 0.5
	local v = rs:LengthSqr() > 0 and rel:Dot(rs) / rs:LengthSqr() / 3 or 0.5
	return math.Clamp(u, -0.4, 1.4), math.Clamp(v, -0.4, 1.4)
end
ZCPhone.PosUV = PosUV

local function KeyUV(name)
	local k = Cfg().Keys
	local rel = KeyLocal(name) - k.origin
	local cs, rs = k.colStep, k.rowStep
	local u = cs:LengthSqr() > 0 and rel:Dot(cs) / cs:LengthSqr() / 2 or 0.5
	local v = rs:LengthSqr() > 0 and rel:Dot(rs) / rs:LengthSqr() / 3 or 0.5
	return math.Clamp(u, -0.4, 1.4), math.Clamp(v, -0.4, 1.4)
end

local function Bilerp(c, u, v, i)
	local function mix(a, b, t) return Angle(a.p + (b.p - a.p) * t, a.y + (b.y - a.y) * t, a.r + (b.r - a.r) * t) end
	local top = mix(c.tl[i], c.tr[i], u)
	local bot = mix(c.bl[i], c.br[i], u)
	return mix(top, bot, v)
end

local function RotBone(ent, name, ang)
	local b = ent:LookupBone(name)
	if not b then return end
	local original = ent:GetBoneMatrix(b)
	local m = original and Matrix(original)
	if not m then return end
	m:Rotate(ang)
	hg.bone_apply_matrix(ent, b, m)
end

local function GetState(ply)
	local s = ply.zcPh
	if not s then
		s = { phase = 0, u = 0.5, v = 0.65, last = RealTime() }
		ply.zcPh = s
	end
	return s
end

local function Update(ply)
	local s = GetState(ply)
	local now = RealTime()
	local dt = math.Clamp(now - s.last, 0, 0.1)
	s.last = now
	local want = ZCPhone.IsOut(ply)
	if want and hg and hg.CanUseRightHand and not hg.CanUseRightHand(ply) then want = false end
	s.phase = math.Approach(s.phase, want and 1 or 0, dt / math.max(0.15, Cfg().Pose.time))

	local th = Cfg().Thumb
	local tu, tv = th.idle[1], th.idle[2]
	s.press = 0
	if ply == LocalPlayer() then
		local key = ZCPhone.PreviewKey
		local since = CurTime() - (ZCPhone.LastPressTime or -10)
		if key then
			tu, tv = KeyUV(key)
			s.press = 0.5 + 0.5 * math.sin(CurTime() * 6)
		elseif ZCPhone.IsInteracting and ZCPhone.IsInteracting() then
			local hk = ZCPhone.HoverKey
			if hk then
				tu, tv = KeyUV(hk)
			else
				local cu, cv = ZCPhone.CursorUV()
				if cu then tu, tv = cu, cv end
			end
			local x = since / math.max(0.05, th.pressTime)
			if x < 1 then s.press = math.sin(math.pi * x) end
		elseif since < 1.2 and ZCPhone.LastPressKey then
			tu, tv = KeyUV(ZCPhone.LastPressKey)
			local x = since / math.max(0.05, th.pressTime)
			if x < 1 then s.press = math.sin(math.pi * x) end
		end
	end
	local k = math.min(1, dt * th.speed)
	s.u = s.u + (tu - s.u) * k
	s.v = s.v + (tv - s.v) * k
	return s
end

local function ApplyHand(ply, ent, s)
	local rh = ent:LookupBone(R .. "Hand")
	local sp = ent:LookupBone("ValveBiped.Bip01_Spine4")
	if not rh or not sp then return false end
	local original, spm = ent:GetBoneMatrix(rh), ent:GetBoneMatrix(sp)
	local rhm = original and Matrix(original)
	if not rhm or not spm then return false end

	local cfg = Cfg().Pose
	local base = Angle(0, ply:EyeAngles().y, 0)
	local ease = math.ease and math.ease.InOutSine(s.phase) or s.phase
	local rest = LocalToWorld(Vector(4, -10, -26), angle_zero, spm:GetTranslation(), base)
	local show = LocalToWorld(cfg.show, angle_zero, spm:GetTranslation(), base)
	local _, ang = LocalToWorld(vector_origin, cfg.handAng, vector_origin, base)

	rhm:SetTranslation(LerpVector(ease, rhm:GetTranslation(), LerpVector(math.Clamp(ease * 1.4, 0, 1), rest, show)))
	rhm:SetAngles(LerpAngle(ease, rhm:GetAngles(), ang))
	hg.bone_apply_matrix(ent, rh, rhm)
	return true
end

local function PhoneWorld(ent)
	local rh = ent:LookupBone(R .. "Hand")
	local m = rh and ent:GetBoneMatrix(rh)
	if not m then return end
	local cfg = Cfg()
	return LocalToWorld(cfg.Hand.pos, cfg.Hand.ang, m:GetTranslation(), m:GetAngles())
end

local function SolveThumb(ent, s, target, weight)
	local th = Cfg().Thumb
	local ids = {}
	for i = 1, 3 do
		ids[i] = ent:LookupBone(THUMB[i])
		if not ids[i] then return end
	end
	local jw = { 0.45, 0.8, 1 }
	local tipLen = th.tipLen or 1.2
	local maxStep = th.maxStep or 25
	for _ = 1, 6 do
		for i = 3, 1, -1 do
			local mo = ent:GetBoneMatrix(ids[i])
			local m3 = ent:GetBoneMatrix(ids[3])
			if not mo or not m3 then return end
			local pos = mo:GetTranslation()
			local tip = m3:GetTranslation() + m3:GetForward() * tipLen
			local a, b = tip - pos, target - pos
			if a:LengthSqr() > 1e-6 and b:LengthSqr() > 1e-6 then
				a:Normalize()
				b:Normalize()
				local axis = a:Cross(b)
				if axis:LengthSqr() > 1e-8 then
					axis:Normalize()
					local deg = math.Clamp(math.deg(math.acos(math.Clamp(a:Dot(b), -1, 1))), 0, maxStep) * jw[i] * weight
					local mat = Matrix(mo)
					local an = mat:GetAngles()
					an:RotateAroundAxis(axis, deg)
					mat:SetAngles(an)
					hg.bone_apply_matrix(ent, ids[i], mat)
				end
			end
		end
	end
end

local function ApplyFingers(ent, s, wpos, wang)
	local cfg = Cfg()
	local w = math.Clamp(s.phase * 1.5, 0, 1)
	for n = 1, 4 do
		for i = 1, 3 do
			RotBone(ent, FINGERS[n][i], Angle(0, -cfg.Curl[i] * w, 0))
		end
	end
	local th = cfg.Thumb
	local pw = s.press or 0
	if th.useIK ~= false and wpos then
		local k = cfg.Keys
		local scale = math.max(0.01, cfg.Scale)
		local lp = k.origin + k.colStep * (2 * s.u) + k.rowStep * (3 * s.v)
		local key = LocalToWorld(lp * scale, angle_zero, wpos, wang)
		local n = k.colStep:Cross(k.rowStep)
		if n:LengthSqr() > 1e-8 then
			n:Normalize()
			local normal = LocalToWorld(n, angle_zero, vector_origin, wang)
			local eye = EyePos and EyePos() or wpos
			if normal:Dot(eye - key) < 0 then normal = -normal end
			local lift = (th.lift or 0.5) * (1 - pw) - (th.depth or 0.1) * pw
			key = key + normal * lift * scale
		end
		ZCPhone.ThumbTarget = key
		SolveThumb(ent, s, key, w)
	end
	for i = 1, 3 do
		local a = Bilerp(th.corners, s.u, s.v, i)
		local p = th.press[i]
		a = Angle(a.p + p.p * pw, a.y + p.y * pw, a.r + p.r * pw)
		RotBone(ent, THUMB[i], Angle(a.p * w, a.y * w, a.r * w))
	end
end

local warnedModel
local function GetModel(ply)
	local path = Cfg().Model
	if not ZCPhone.ModelAvailable(path) then
  if IsValid(ply.zcPhoneEnt) then ply.zcPhoneEnt:Remove() end
  ply.zcPhoneEnt = nil
  ply.zcPhoneWorld = nil
  ZCPhone.ScreenXform[ply] = nil
  if ply == LocalPlayer() and warnedModel ~= path then
   warnedModel = path
   local msg = "[ZCPhone] Модель недоступна: " .. tostring(path) .. ". Проверьте установленный контент; команда zcphone_modelcheck."
   print(msg)
   chat.AddText(Color(255, 100, 70), msg)
  end
  return
 end
 warnedModel = nil
	local e = ply.zcPhoneEnt
	if IsValid(e) and e:GetModel() == string.lower(path) then return e end
	if IsValid(e) then e:Remove() end
	util.PrecacheModel(path)
	e = ClientsideModel(path)
	if not IsValid(e) then return end
	e:SetNoDraw(true)
	ply.zcPhoneEnt = e
	return e
end

local function DrawPhone(ply, ent, s)
	local rh = ent:LookupBone(R .. "Hand")
	local m = rh and ent:GetBoneMatrix(rh)
	if not m then return end
	local mdl = GetModel(ply)
	if not IsValid(mdl) then return end
	local cfg = Cfg()
	local pos, ang = LocalToWorld(cfg.Hand.pos, cfg.Hand.ang, m:GetTranslation(), m:GetAngles())
	mdl:SetModelScale(cfg.Scale, 0)
	mdl:SetSkin(cfg.Skin or 0)
	mdl:SetPos(pos)
	mdl:SetAngles(ang)
	mdl:SetupBones()
	mdl:DrawModel()

	local sp, sa = LocalToWorld(cfg.Screen.pos * cfg.Scale, cfg.Screen.ang, pos, ang)
	ZCPhone.ScreenXform[ply] = { pos = sp, ang = sa, frame = FrameNumber() }
	ply.zcPhoneWorld = { pos = pos, ang = ang, frame = FrameNumber() }
end

local origDoTPIK
local function Wrapped(ply, ent, ...)
	if not IsValid(ply) or not ply:IsPlayer() or not IsValid(ent) then return origDoTPIK(ply, ent, ...) end

	local s = Update(ply)
	local active = s.phase > 0
	if active and ApplyHand(ply, ent, s) then
		local wep = ply:GetActiveWeapon()
		if IsValid(wep) then wep.rhandik = true end
		ply.lerp_rh = 1
	elseif not active and IsValid(ply.zcPhoneEnt) then
		ply.zcPhoneEnt:Remove()
		ply.zcPhoneEnt = nil
		ply.zcPhoneWorld = nil
		ZCPhone.ScreenXform[ply] = nil
	end

	-- cl_tpik.lua:1070 берёт segments[3], который появляется только при пересчёте; в первые кадры
	-- после входа игрока его нет. Заранее создаём недостающие сегменты руки.
	if not ply.segmentsr then ply.segmentsr = {} end
	ply.segmentsr[1] = ply.segmentsr[1] or { Pos = Vector(), Len = 0 }
	ply.segmentsr[2] = ply.segmentsr[2] or { Pos = Vector(), Len = 0 }
	ply.segmentsr[3] = ply.segmentsr[3] or { Pos = Vector(), Len = 12 }

	-- Ошибка внутри оригинального DoTPIK (например, рэгдолл ещё без костей сразу после входа)
	-- не должна заливать консоль каждый кадр: гасим и пишем один раз в 10 секунд.
	local ok, res = pcall(origDoTPIK, ply, ent, ...)
	if not ok then
		if (ZCPhone.NextTPIKError or 0) < CurTime() then
			ZCPhone.NextTPIKError = CurTime() + 10
			print("[ZC Phone] DoTPIK: ошибка оригинала подавлена: " .. tostring(res))
		end
		return
	end

	if active then
		local wpos, wang = PhoneWorld(ent)
		ApplyFingers(ent, s, wpos, wang)
		if s.phase > 0.2 then DrawPhone(ply, ent, s) end
	end
	return res
end

local installed = false
local function Install()
	if installed or not hg or not isfunction(hg.DoTPIK) or not isfunction(hg.bone_apply_matrix) or hg.DoTPIK == Wrapped then return end
	installed = true
	origDoTPIK = hg.DoTPIK
	hg.DoTPIK = Wrapped
	print("[ZC Phone] hg.DoTPIK обёрнут")
end
ZCPhone.Install = Install

hook.Add("InitPostEntity", "ZCPhone_Install", function() timer.Simple(1.5, Install) end)
timer.Simple(0, Install)
hook.Add("Think", "ZCPhone_Reinstall", function()
	if not installed then Install() end
end)

hook.Add("EntityRemoved", "ZCPhone_Cleanup", function(e)
	if e.zcPhoneEnt and IsValid(e.zcPhoneEnt) then e.zcPhoneEnt:Remove() end
end)

hook.Add("CalcView", "ZCPhone_ThirdPerson", function(ply, origin, angles, fov)
	if not cvThird:GetBool() or not ZCPhone.IsOut(ply) then return end
	local fwd, right = angles:Forward(), angles:Right()
	local pos = origin - fwd * 70 + right * 35 + Vector(0, 0, 8)
	local look = (origin + fwd * 14 - right * 4) - pos
	return { origin = pos, angles = look:Angle(), fov = fov, drawviewer = true }
end)
