-- Сапёр для телефона. 2/4/6/8 - курсор, OK - открыть, 5 - флажок, 0 - заново.
ZCPhone = ZCPhone or {}
local ui, st = ZCPhone.UI, ZCPhone.State

local CELL = 12
local cvBest = CreateClientConVar("zcphone_mines_best", "0", true, false) -- лучшее время, секунд (0 = нет)

local game

local function Dims()
	local W, H = ZCPhone.ScreenSize()
	local cols = math.floor((W - 8) / CELL)
	local rows = math.max(4, math.floor((H - 34) / CELL))
	return cols, rows, W, H
end

local function Reset()
	local cols, rows = Dims()
	game = {
		cols = cols, rows = rows,
		mines = math.max(5, math.floor(cols * rows * 0.15)),
		cells = {}, cx = math.floor(cols / 2), cy = math.floor(rows / 2),
		started = false, over = false, won = false, t0 = 0, tEnd = 0, opened = 0,
	}
	for i = 1, cols * rows do game.cells[i] = { mine = false, open = false, flag = false, n = 0 } end
end

local function Idx(x, y) return y * game.cols + x + 1 end

local function Neighbors(x, y)
	local out = {}
	for dy = -1, 1 do
		for dx = -1, 1 do
			if dx ~= 0 or dy ~= 0 then
				local nx, ny = x + dx, y + dy
				if nx >= 0 and ny >= 0 and nx < game.cols and ny < game.rows then out[#out + 1] = { nx, ny } end
			end
		end
	end
	return out
end

local function Plant(sx, sy)
	-- первая клетка и её соседи всегда пусты
	local safe = { [Idx(sx, sy)] = true }
	for _, p in ipairs(Neighbors(sx, sy)) do safe[Idx(p[1], p[2])] = true end
	local placed, total = 0, game.cols * game.rows
	local free = total - table.Count(safe)
	local want = math.min(game.mines, free)
	game.mines = want
	while placed < want do
		local i = math.random(1, total)
		if not safe[i] and not game.cells[i].mine then game.cells[i].mine = true placed = placed + 1 end
	end
	for y = 0, game.rows - 1 do
		for x = 0, game.cols - 1 do
			local n = 0
			for _, p in ipairs(Neighbors(x, y)) do
				if game.cells[Idx(p[1], p[2])].mine then n = n + 1 end
			end
			game.cells[Idx(x, y)].n = n
		end
	end
	game.started, game.t0 = true, CurTime()
end

local function Lose()
	game.over, game.won, game.tEnd = true, false, CurTime()
end

local function Win()
	game.over, game.won, game.tEnd = true, true, CurTime()
	local t = math.floor(game.tEnd - game.t0)
	local best = cvBest:GetInt()
	if best == 0 or t < best then RunConsoleCommand("zcphone_mines_best", tostring(math.max(1, t))) end
end

local function Open(x, y)
	local stack = { { x, y } }
	while #stack > 0 do
		local p = table.remove(stack)
		local c = game.cells[Idx(p[1], p[2])]
		if c and not c.open and not c.flag then
			c.open = true
			game.opened = game.opened + 1
			if c.n == 0 and not c.mine then
				for _, q in ipairs(Neighbors(p[1], p[2])) do stack[#stack + 1] = q end
			end
		end
	end
	if game.opened >= game.cols * game.rows - game.mines then Win() end
end

function ZCPhone.MinesKey(key)
	if not game then return end
	if key == "0" then return Reset() end
	if game.over then
		if key == "ok" then Reset() end
		return
	end
	if key == "2" then game.cy = (game.cy - 1) % game.rows
	elseif key == "8" then game.cy = (game.cy + 1) % game.rows
	elseif key == "4" then game.cx = (game.cx - 1) % game.cols
	elseif key == "6" then game.cx = (game.cx + 1) % game.cols
	elseif key == "5" then
		local c = game.cells[Idx(game.cx, game.cy)]
		if game.started and not c.open then c.flag = not c.flag end
	elseif key == "ok" then
		local c = game.cells[Idx(game.cx, game.cy)]
		if c.open or c.flag then return end
		if not game.started then Plant(game.cx, game.cy) end
		if c.mine then
			c.open = true
			return Lose()
		end
		Open(game.cx, game.cy)
	end
end

hook.Add("Think", "ZCPhone_Mines", function()
	if ui.screen ~= "mines" then game = nil end
end)

function ZCPhone.DrawMines(W, H)
	if not game then Reset() end
	local FG, BG = Color(28, 40, 22), Color(150, 182, 118)
	local cols, rows = game.cols, game.rows
	surface.SetDrawColor(FG)
	surface.DrawRect(0, 0, W, 18)
	draw.SimpleText("Сапёр", "ZCPhone_M", 4, 2, BG)
	local flags = 0
	for _, c in ipairs(game.cells) do if c.flag then flags = flags + 1 end end
	local secs = game.started and math.floor((game.over and game.tEnd or CurTime()) - game.t0) or 0
	draw.SimpleText(string.format("%d  %d:%02d", game.mines - flags, secs / 60, secs % 60), "ZCPhone_M", W - 4, 2, BG, TEXT_ALIGN_RIGHT)

	local ox, oy = math.floor((W - cols * CELL) / 2), 22
	surface.SetDrawColor(FG)
	surface.DrawOutlinedRect(ox - 2, oy - 2, cols * CELL + 4, rows * CELL + 4)
	for y = 0, rows - 1 do
		for x = 0, cols - 1 do
			local c = game.cells[Idx(x, y)]
			local px, py = ox + x * CELL, oy + y * CELL
			if c.open then
				if c.mine then
					surface.SetDrawColor(FG)
					surface.DrawRect(px + 3, py + 3, CELL - 6, CELL - 6)
					surface.DrawRect(px + 1, py + CELL / 2 - 1, CELL - 2, 2)
					surface.DrawRect(px + CELL / 2 - 1, py + 1, 2, CELL - 2)
				elseif c.n > 0 then
					draw.SimpleText(tostring(c.n), "ZCPhone_S", px + CELL / 2, py + 1, FG, TEXT_ALIGN_CENTER)
				end
			else
				surface.SetDrawColor(FG)
				surface.DrawRect(px + 1, py + 1, CELL - 2, CELL - 2)
				surface.SetDrawColor(BG)
				surface.DrawRect(px + 3, py + 3, CELL - 6, CELL - 6)
				if c.flag then
					surface.SetDrawColor(FG)
					surface.DrawRect(px + 5, py + 3, 2, CELL - 6)
					surface.DrawRect(px + 3, py + 3, 3, 3)
				elseif game.over and c.mine then
					surface.SetDrawColor(FG)
					surface.DrawRect(px + 4, py + 4, CELL - 8, CELL - 8)
				end
			end
		end
	end
	if not game.over then
		surface.SetDrawColor(FG)
		local px, py = ox + game.cx * CELL, oy + game.cy * CELL
		surface.DrawOutlinedRect(px, py, CELL, CELL)
		surface.DrawOutlinedRect(px + 1, py + 1, CELL - 2, CELL - 2)
	end

	local msg, sub
	if game.over then
		local best = cvBest:GetInt()
		msg = game.won and "Победа!" or "Подрыв"
		sub = (best > 0 and ("Рекорд " .. best .. " с  ") or "") .. "OK - заново"
	elseif not game.started then
		msg, sub = "Сапёр", "2/4/6/8 ход  OK открыть  5 флаг"
	end
	if msg then
		surface.SetDrawColor(FG)
		surface.DrawRect(6, H / 2 - 22, W - 12, 44)
		draw.SimpleText(msg, "ZCPhone_L", W / 2, H / 2 - 18, BG, TEXT_ALIGN_CENTER)
		draw.SimpleText(sub, "ZCPhone_S", W / 2, H / 2 + 6, BG, TEXT_ALIGN_CENTER)
	end
end
