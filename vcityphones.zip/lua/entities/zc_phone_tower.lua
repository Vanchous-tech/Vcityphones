AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Вышка связи"
ENT.Author = "ZC Phone"
ENT.Category = "ZC Phone"
ENT.Spawnable = true
ENT.AdminOnly = true

ZCPhone = ZCPhone or {}
ZCPhone.Towers = ZCPhone.Towers or {}

if SERVER then
	function ENT:Initialize()
		local S = ZCPhone.Settings
		local model = util.IsValidModel(S.TowerModel) and S.TowerModel or "models/props_c17/utilitypole01a.mdl"
		self:SetModel(model)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		local phys = self:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
		self:SetUseType(CONTINUOUS_USE)
		self:SetMaxHealth(S.TowerHealth)
		self:SetHealth(S.TowerHealth)
		ZCPhone.Towers[self] = true
		ZCPhone.HadTowers = true
	end

	function ENT:OnRemove()
		ZCPhone.Towers[self] = nil
	end

	function ENT:OnTakeDamage(dmg)
		if self.Dead then return end
		self:SetHealth(self:Health() - dmg:GetDamage())
		if self:Health() > 0 then return end
		self.Dead = true
		self:SetNWBool("ZCPhoneDead", true)
		self.Fix = 0
		local fx = EffectData()
		fx:SetOrigin(self:GetPos() + Vector(0, 0, 40))
		util.Effect("Explosion", fx, true, true)
		self:EmitSound("ambient/explosions/explode_" .. math.random(1, 4) .. ".wav", 90, 100, 1)
		ZCPhone.Towers[self] = nil
	end

	-- Ремонт: удерживать E рядом с разбитой вышкой. Право чинить задаёт хук ZCPhone_CanRepairTower.
	function ENT:Use(ply)
		if not self.Dead or not IsValid(ply) or not ply:IsPlayer() then return end
		if hook.Run("ZCPhone_CanRepairTower", ply) == false then
			if (ply.zcTowerMsg or 0) < CurTime() then
				ply.zcTowerMsg = CurTime() + 3
				if ZCPhone.Notice then ZCPhone.Notice(ply, "Вышку может починить только связист") end
			end
			return
		end
		local now = CurTime()
		local dt = math.Clamp(now - (self.LastUse or now), 0, 0.25)
		if now - (self.LastUse or 0) > 0.6 then self.Fix = 0 dt = 0 end
		self.LastUse = now
		self.Fix = (self.Fix or 0) + dt
		self:SetNWFloat("ZCPhoneFix", self.Fix / ZCPhone.Settings.TowerRepairTime)
		if self.Fix % 1.5 < dt then self:EmitSound("ambient/energy/spark" .. math.random(1, 6) .. ".wav", 60, 100, 0.6) end
		if self.Fix >= ZCPhone.Settings.TowerRepairTime then
			self.Dead = false
			self.Fix = 0
			self:SetNWBool("ZCPhoneDead", false)
			self:SetNWFloat("ZCPhoneFix", 0)
			self:SetHealth(self:GetMaxHealth())
			ZCPhone.Towers[self] = true
			ZCPhone.HadTowers = true
			if ZCPhone.Notice then ZCPhone.Notice(ply, "Вышка восстановлена") end
			hook.Run("ZCPhone_Intel", ply, "repair", self)
		end
	end

	function ENT:SpawnFunction(ply, tr, class)
		if not tr.Hit then return end
		local ent = ents.Create(class)
		ent:SetPos(tr.HitPos)
		ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
		ent:Spawn()
		ent:Activate()
		return ent
	end
else
	function ENT:Draw()
		if self:GetNWBool("ZCPhoneDead", false) then
			render.SetColorModulation(0.22, 0.2, 0.2)
			self:DrawModel()
			render.SetColorModulation(1, 1, 1)
		else
			self:DrawModel()
		end
	end

	hook.Add("HUDPaint", "ZCPhone_TowerRepairHUD", function()
		local ply = LocalPlayer()
		if not IsValid(ply) then return end
		local tr = ply:GetEyeTrace()
		local e = tr.Entity
		if not IsValid(e) or e:GetClass() ~= "zc_phone_tower" or not e:GetNWBool("ZCPhoneDead", false) then return end
		if ply:GetPos():DistToSqr(e:GetPos()) > 160 * 160 then return end
		local w, h = ScrW(), ScrH()
		draw.SimpleTextOutlined("Вышка разбита. Держите E для ремонта (связист)", "DermaDefaultBold", w / 2, h * 0.62, Color(255, 200, 90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		local f = math.Clamp(e:GetNWFloat("ZCPhoneFix", 0), 0, 1)
		if f > 0 then
			surface.SetDrawColor(0, 0, 0, 180) surface.DrawRect(w / 2 - 100, h * 0.62 + 14, 200, 8)
			surface.SetDrawColor(120, 255, 120, 255) surface.DrawRect(w / 2 - 100, h * 0.62 + 14, 200 * f, 8)
		end
	end)
end

if SERVER then
	local function Path() return "zc_phone/towers_" .. game.GetMap() .. ".json" end

	local function SpawnSaved()
		if not file.Exists(Path(), "DATA") then return end
		local t = util.JSONToTable(file.Read(Path(), "DATA") or "")
		if not istable(t) then return end
		for _, e in ipairs(ents.FindByClass("zc_phone_tower")) do e:Remove() end
		for _, d in ipairs(t) do
			local ent = ents.Create("zc_phone_tower")
			ent:SetPos(Vector(d[1], d[2], d[3]))
			ent:SetAngles(Angle(0, d[4] or 0, 0))
			ent:Spawn()
		end
	end

	hook.Add("InitPostEntity", "ZCPhone_SpawnTowers", function() timer.Simple(2, SpawnSaved) end)
	hook.Add("PostCleanupMap", "ZCPhone_SpawnTowers", function() timer.Simple(1, SpawnSaved) end)

	concommand.Add("zcphone_tower_save", function(ply)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		local out = {}
		for _, e in ipairs(ents.FindByClass("zc_phone_tower")) do
			local p = e:GetPos()
			out[#out + 1] = { math.floor(p.x), math.floor(p.y), math.floor(p.z), math.floor(e:GetAngles().y) }
		end
		file.CreateDir("zc_phone")
		file.Write(Path(), util.TableToJSON(out))
		print("[ZCPhone] вышек сохранено: " .. #out)
		if IsValid(ply) then ply:ChatPrint("Вышек сохранено: " .. #out) end
	end)

	concommand.Add("zcphone_tower_clear", function(ply)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		file.Delete(Path())
		for _, e in ipairs(ents.FindByClass("zc_phone_tower")) do e:Remove() end
		ZCPhone.Towers = {}
		ZCPhone.HadTowers = false
		print("[ZCPhone] вышки удалены")
	end)

	function ZCPhone.TowerCoverage(pos)
		if not ZCPhone.HadTowers then return 1 end
		local range = ZCPhone.Settings.TowerRange
		local best = 0
		for t in pairs(ZCPhone.Towers) do
			if IsValid(t) then
				local d = t:GetPos():Distance(pos)
				best = math.max(best, math.Clamp((1 - d / range) * 1.6, 0, 1))
			end
		end
		return best
	end
end
