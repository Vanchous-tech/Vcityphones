AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Трофейный телефон"
ENT.Category = "ZC Phone"
ENT.Spawnable = false

if SERVER then
	util.AddNetworkString("ZCPhone_Loot")

	function ENT:Initialize()
		local model = ZCPhone.Settings.DropModel
		if not util.IsValidModel(model) then model = "models/props_junk/garbage_metalcan001a.mdl" end
		self:SetModel(model)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local phys = self:GetPhysicsObject()
		if IsValid(phys) then phys:Wake() end
		SafeRemoveEntityDelayed(self, ZCPhone.Settings.DropLifetime)
	end

	function ENT:Use(ply)
		if not IsValid(ply) or not ply:IsPlayer() or not self.Data then return end
		ply.zcPhoneLoot = ply.zcPhoneLoot or {}
		for _, d in ipairs(ply.zcPhoneLoot) do
			if d.num == self.Data.num then self:Remove() return end
		end
		if #ply.zcPhoneLoot >= 4 then table.remove(ply.zcPhoneLoot, 1) end
		ply.zcPhoneLoot[#ply.zcPhoneLoot + 1] = self.Data
		net.Start("ZCPhone_Loot")
		net.WriteTable(ply.zcPhoneLoot)
		net.Send(ply)
		if ZCPhone.Notice then ZCPhone.Notice(ply, "Трофей: телефон №" .. self.Data.num) end
		ply:EmitSound("physics/plastic/plastic_box_impact_soft1.wav", 55, 120, 0.5)
		hook.Run("ZCPhone_Intel", ply, "loot", self.Data)
		self:Remove()
	end

	hook.Add("PlayerDeath", "ZCPhone_DropLoot", function(ply)
		if not ply.zcPhoneNumber or not ply:HasWeapon(ZCPhone.WeaponClass) then return end
		local ent = ents.Create("zc_phone_item")
		if not IsValid(ent) then return end
		ent:SetPos(ply:GetPos() + Vector(0, 0, 14))
		ent:SetAngles(Angle(0, math.random(0, 359), 0))
		ent:Spawn()
		local msgs = ZCPhone.LoadMessagesFor and ZCPhone.LoadMessagesFor(ply) or {}
		local contacts = {}
		for _, c in ipairs(ply.zcPhoneContacts or {}) do
			if not c.auto then contacts[#contacts + 1] = { num = c.num, name = c.name } end
		end
		ent.Data = { num = ply.zcPhoneNumber, contacts = contacts, msgs = msgs }
		ply.zcPhoneLoot = nil
	end)
else
	function ENT:Draw()
		self:DrawModel()
	end
end
