AddCSLuaFile()

SWEP.PrintName = "Кнопочный телефон"
SWEP.Author = "ZC Phone"
SWEP.Category = "ZC Phone"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.Slot = 5
SWEP.SlotPos = 20
SWEP.HoldType = "normal"
SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = ""
SWEP.UseHands = false
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary = SWEP.Primary

function SWEP:Initialize()
	self:SetHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then self:GetOwner():SetNWBool("ZCPhone_Out", true) end
	return true
end

function SWEP:Holster()
	if SERVER then
		local o = self:GetOwner()
		if IsValid(o) then o:SetNWBool("ZCPhone_Out", false) end
	end
	return true
end

function SWEP:OnRemove()
	if SERVER then
		local o = self:GetOwner()
		if IsValid(o) then o:SetNWBool("ZCPhone_Out", false) end
	end
end

function SWEP:OnDrop()
	if SERVER then
		local o = self:GetOwner()
		if IsValid(o) then o:SetNWBool("ZCPhone_Out", false) end
	end
end

function SWEP:PrimaryAttack() end
function SWEP:SecondaryAttack() end
function SWEP:Reload() end
function SWEP:ShouldDrawViewModel() return false end
function SWEP:PreDrawViewModel() return true end
function SWEP:DrawWorldModel() end
function SWEP:DrawWorldModelTranslucent() end
