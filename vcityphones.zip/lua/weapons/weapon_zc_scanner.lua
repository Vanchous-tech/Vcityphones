AddCSLuaFile()

SWEP.PrintName = "Сканер связи"
SWEP.Author = "ZC Phone"
SWEP.Category = "ZC Phone"
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.UseHands = false
SWEP.ViewModel = "models/weapons/v_hands.mdl"
SWEP.WorldModel = "models/props_lab/reciever01a.mdl"
SWEP.Slot = 5
SWEP.SlotPos = 5
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary = SWEP.Primary

function SWEP:Initialize() self:SetHoldType("slam") end
function SWEP:PrimaryAttack() end
function SWEP:SecondaryAttack() end
function SWEP:Reload() end
function SWEP:ShouldDrawViewModel() return false end
function SWEP:PreDrawViewModel() return true end
